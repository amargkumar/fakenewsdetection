# Flask Web App Startup Script
# Run this from the project root directory

Write-Host ""
Write-Host "=== Starting Health Misinformation Detection Web App ===" -ForegroundColor Cyan
Write-Host "Activating virtual environment..." -ForegroundColor Yellow

# Activate venv
& ".\venv\Scripts\Activate.ps1"

Write-Host "Virtual environment activated" -ForegroundColor Green
Write-Host ""
Write-Host "Starting Flask server..." -ForegroundColor Yellow
Write-Host "Loading BERT model (this may take 10-15 seconds)..." -ForegroundColor Yellow
Write-Host ""

# Run the Flask app
python web_app\run.py
