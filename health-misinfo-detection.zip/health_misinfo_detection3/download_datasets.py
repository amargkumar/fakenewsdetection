"""
Script to download real CoAID and HealthFact datasets
"""
import requests
import pandas as pd
from pathlib import Path
import zipfile
import io
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def download_coaid_dataset():
    """
    Download CoAID dataset from GitHub
    """
    logger.info("Downloading CoAID dataset...")
    
    base_path = Path('data/raw/coaid')
    base_path.mkdir(parents=True, exist_ok=True)
    
    # CoAID GitHub repository URLs
    urls = {
        'news_real': 'https://raw.githubusercontent.com/cuilimeng/CoAID/master/05-01-2020/NewsRealCOVID-19.csv',
        'news_fake': 'https://raw.githubusercontent.com/cuilimeng/CoAID/master/05-01-2020/NewsFakeCOVID-19.csv',
    }
    
    downloaded_files = []
    
    for name, url in urls.items():
        try:
            logger.info(f"  Downloading {name}...")
            response = requests.get(url, timeout=30)
            response.raise_for_status()
            
            # Save file
            file_path = base_path / f'{name}.csv'
            with open(file_path, 'wb') as f:
                f.write(response.content)
            
            # Verify it's a valid CSV
            df = pd.read_csv(file_path)
            logger.info(f"  ✓ {name}: {len(df)} records")
            downloaded_files.append(file_path)
            
        except Exception as e:
            logger.error(f"  ✗ Failed to download {name}: {e}")
    
    if downloaded_files:
        logger.info(f"\n✓ CoAID download complete: {len(downloaded_files)} files")
        return True
    else:
        logger.error("\n✗ CoAID download failed")
        return False


def download_healthfact_dataset():
    """
    Download HealthFact-like dataset
    Note: The original HealthFact dataset may require manual download
    This attempts to get publicly available health misinformation data
    """
    logger.info("\nDownloading HealthFact dataset...")
    
    base_path = Path('data/raw/healthfact')
    base_path.mkdir(parents=True, exist_ok=True)
    
    # Try PUBHEALTH dataset (publicly available health fact-checking)
    try:
        url = 'https://drive.google.com/uc?export=download&id=1eTtRs5cUlBP5dXsx-FTAlmXuB6JQi2qO'
        logger.info("  Attempting to download PUBHEALTH dataset...")
        logger.info("  Note: This is an alternative health fact-checking dataset")
        
        # For now, we'll create a placeholder and provide manual instructions
        logger.warning("  HealthFact dataset requires manual download")
        logger.info("\n  Manual download instructions:")
        logger.info("  1. Visit: https://github.com/neemakot/Health-Fact-Checking")
        logger.info("  2. Download the dataset CSV files")
        logger.info("  3. Place them in: data/raw/healthfact/")
        
        return False
        
    except Exception as e:
        logger.error(f"  ✗ Failed to download: {e}")
        return False


def combine_coaid_data():
    """
    Combine CoAID real and fake news into single dataset with labels
    """
    logger.info("\nCombining CoAID datasets...")
    
    base_path = Path('data/raw/coaid')
    
    try:
        # Load real news
        real_df = pd.read_csv(base_path / 'news_real.csv')
        real_df['label'] = 1  # Real = 1
        real_df['source'] = 'real_news'
        logger.info(f"  Real news: {len(real_df)} records")
        
        # Load fake news
        fake_df = pd.read_csv(base_path / 'news_fake.csv')
        fake_df['label'] = 0  # Fake = 0
        fake_df['source'] = 'fake_news'
        logger.info(f"  Fake news: {len(fake_df)} records")
        
        # Combine
        combined_df = pd.concat([real_df, fake_df], ignore_index=True)
        
        # Standardize column names - find text column
        text_columns = ['title', 'content', 'tweet', 'news_title', 'news_content']
        for col in text_columns:
            if col in combined_df.columns:
                combined_df['text'] = combined_df[col].fillna('')
                break
        
        # If still no text column, try combining title and content
        if 'text' not in combined_df.columns:
            if 'title' in combined_df.columns and 'content' in combined_df.columns:
                combined_df['text'] = combined_df['title'].fillna('') + ' ' + combined_df['content'].fillna('')
            elif 'title' in combined_df.columns:
                combined_df['text'] = combined_df['title']
        
        # Remove rows with empty text
        combined_df = combined_df[combined_df['text'].str.len() > 0]
        
        # Save combined dataset
        output_path = base_path / 'coaid_combined.csv'
        combined_df[['text', 'label', 'source']].to_csv(output_path, index=False)
        
        logger.info(f"\n✓ Combined dataset saved: {len(combined_df)} total records")
        logger.info(f"  Location: {output_path}")
        logger.info(f"  Label distribution:\n{combined_df['label'].value_counts()}")
        
        return True
        
    except Exception as e:
        logger.error(f"\n✗ Failed to combine datasets: {e}")
        return False


def verify_datasets():
    """
    Verify downloaded datasets are valid
    """
    logger.info("\n" + "="*60)
    logger.info("Verifying datasets...")
    logger.info("="*60)
    
    # Check CoAID
    coaid_path = Path('data/raw/coaid/coaid_combined.csv')
    if coaid_path.exists():
        df = pd.read_csv(coaid_path)
        logger.info(f"\n✓ CoAID dataset found:")
        logger.info(f"  Records: {len(df)}")
        logger.info(f"  Columns: {list(df.columns)}")
        logger.info(f"  Labels: {df['label'].value_counts().to_dict()}")
        logger.info(f"  Sample text: {df['text'].iloc[0][:100]}...")
    else:
        logger.warning("\n✗ CoAID combined dataset not found")
    
    # Check HealthFact
    healthfact_files = list(Path('data/raw/healthfact').glob('*.csv'))
    if healthfact_files:
        logger.info(f"\n✓ HealthFact files found: {len(healthfact_files)}")
        for file in healthfact_files:
            df = pd.read_csv(file)
            logger.info(f"  {file.name}: {len(df)} records")
    else:
        logger.warning("\n✗ No HealthFact data files found")
        logger.info("  Please download manually from:")
        logger.info("  https://github.com/neemakot/Health-Fact-Checking")


def main():
    """
    Main download script
    """
    logger.info("="*60)
    logger.info("DATASET DOWNLOAD SCRIPT")
    logger.info("="*60)
    
    # Download CoAID
    coaid_success = download_coaid_dataset()
    
    if coaid_success:
        # Combine CoAID data
        combine_coaid_data()
    
    # Download HealthFact (manual for now)
    download_healthfact_dataset()
    
    # Verify all datasets
    verify_datasets()
    
    logger.info("\n" + "="*60)
    logger.info("Download script complete!")
    logger.info("="*60)


if __name__ == '__main__':
    main()
