"""
Experiment Driver for Health Misinformation Detection
Runs 12 experiments across 6 model architectures with/without features
"""

import argparse
import json
import time
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, random_split
from pathlib import Path
import numpy as np
import pandas as pd
from datetime import datetime
import logging

from src.utils.config import setup_logging, set_seed
from src.data.loaders import load_coaid_dataset, load_healthfact_dataset
from src.data.preprocessors import clean_text, build_vocabulary, text_to_sequences, pad_sequences
from src.data.datasets import TextWithFeaturesDataset, TextOnlyDataset, TransformerDataset
from src.features.sentiment import batch_extract_sentiment_features
from src.features.linguistic import batch_extract_linguistic_features
from src.models.ffnn import FFNNClassifier, FFNNWithFeatures
from src.models.textcnn import TextCNN, TextCNNWithFeatures
from src.models.bilstm_attention import BiLSTMAttention, BiLSTMAttentionWithFeatures
from src.models.transformer_models import (
    BERTClassifier, BioBERTClassifier, PubMedBERTClassifier,
    BERTWithFeatures, BioBERTWithFeatures, PubMedBERTWithFeatures,
    get_transformer_tokenizer
)
from src.training.trainer import Trainer
from src.training.callbacks import EarlyStopping, ModelCheckpoint, MetricsLogger
from src.evaluation.metrics import evaluate_model


class ExperimentConfig:
    """Configuration for a single experiment"""
    def __init__(self, model_name, use_features, hyperparams):
        self.model_name = model_name
        self.use_features = use_features
        self.hyperparams = hyperparams
        self.full_model_name = f"{model_name}{'_features' if use_features else ''}"


def is_transformer_model(model_name):
    """Check if model is a transformer-based model."""
    return any(x in model_name for x in ['bert', 'biobert', 'pubmedbert'])


def prepare_data(dataset_name, max_vocab_size=10000, min_word_freq=2, max_length=200):
    """Load and preprocess data for non-transformer models."""
    # Load dataset
    if dataset_name == 'coaid':
        df = load_coaid_dataset(use_sample=False)
    else:
        df = load_healthfact_dataset(split='train', use_sample=False)

    # Clean text
    texts = [clean_text(text) for text in df['text'].tolist()]
    labels = df['label'].tolist()

    # Build vocabulary
    word_to_idx = build_vocabulary(texts, max_vocab_size=max_vocab_size, min_freq=min_word_freq)
    vocab_size = len(word_to_idx)

    # Convert text to sequences
    sequences = text_to_sequences(texts, word_to_idx)
    sequences = pad_sequences(sequences, max_length=max_length)

    return sequences, labels, vocab_size, texts


def prepare_transformer_data(model_name, dataset_name, max_length=200):
    """Load and preprocess data for transformer models."""
    # Load dataset
    if dataset_name == 'coaid':
        df = load_coaid_dataset(use_sample=False)
    else:
        df = load_healthfact_dataset(split='train', use_sample=False)

    # Clean text
    texts = [clean_text(text) for text in df['text'].tolist()]
    labels = df['label'].tolist()

    # Get tokenizer
    tokenizer = get_transformer_tokenizer(model_name)

    # Tokenize texts with attention masks
    encodings = tokenizer(
        texts,
        truncation=True,
        padding='max_length',
        max_length=max_length,
        return_tensors='pt',
        return_attention_mask=True
    )

    return encodings, labels, texts


def create_data_loaders(sequences, labels, features, batch_size, val_split=0.15):
    """Create train and validation data loaders for non-transformer models."""
    if features is not None:
        dataset = TextWithFeaturesDataset(sequences, features, labels)
    else:
        dataset = TextOnlyDataset(sequences, labels)

    val_size = int(val_split * len(dataset))
    train_size = len(dataset) - val_size
    train_dataset, val_dataset = random_split(dataset, [train_size, val_size])

    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, num_workers=0)
    val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False, num_workers=0)

    return train_loader, val_loader


def create_transformer_data_loaders(encodings, labels, features, batch_size, val_split=0.15):
    """Create train and validation data loaders for transformer models."""
    dataset = TransformerDataset(encodings, labels, features)

    val_size = int(val_split * len(dataset))
    train_size = len(dataset) - val_size
    train_dataset, val_dataset = random_split(dataset, [train_size, val_size])

    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, num_workers=0)
    val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False, num_workers=0)

    return train_loader, val_loader


def create_model(config, vocab_size, feature_dim):
    """Create model based on configuration."""
    model_name = config.model_name
    use_features = config.use_features
    hp = config.hyperparams

    # FFNN models
    if model_name == 'ffnn':
        if use_features:
            model = FFNNWithFeatures(
                vocab_size=vocab_size,
                embedding_dim=hp['embedding_dim'],
                hidden_dims=hp['hidden_dims'],
                feature_dim=feature_dim,
                dropout=hp['dropout']
            )
        else:
            model = FFNNClassifier(
                vocab_size=vocab_size,
                embedding_dim=hp['embedding_dim'],
                hidden_dims=hp['hidden_dims'],
                dropout=hp['dropout']
            )

    # TextCNN models
    elif model_name == 'textcnn':
        if use_features:
            model = TextCNNWithFeatures(
                vocab_size=vocab_size,
                embedding_dim=hp['embedding_dim'],
                num_filters=hp['num_filters'],
                filter_sizes=hp['filter_sizes'],
                feature_dim=feature_dim,
                dropout=hp['dropout']
            )
        else:
            model = TextCNN(
                vocab_size=vocab_size,
                embedding_dim=hp['embedding_dim'],
                num_filters=hp['num_filters'],
                filter_sizes=hp['filter_sizes'],
                dropout=hp['dropout']
            )

    # BiLSTM models
    elif model_name == 'bilstm':
        if use_features:
            model = BiLSTMAttentionWithFeatures(
                vocab_size=vocab_size,
                embedding_dim=hp['embedding_dim'],
                hidden_dim=hp['hidden_dim'],
                num_layers=hp['num_layers'],
                feature_dim=feature_dim,
                dropout=hp['dropout']
            )
        else:
            model = BiLSTMAttention(
                vocab_size=vocab_size,
                embedding_dim=hp['embedding_dim'],
                hidden_dim=hp['hidden_dim'],
                num_layers=hp['num_layers'],
                dropout=hp['dropout']
            )

    # BERT models
    elif model_name == 'bert':
        if use_features:
            model = BERTWithFeatures(feature_dim=feature_dim, dropout=hp['dropout'])
        else:
            model = BERTClassifier(dropout=hp['dropout'])

    # BioBERT models
    elif model_name == 'biobert':
        if use_features:
            model = BioBERTWithFeatures(feature_dim=feature_dim, dropout=hp['dropout'])
        else:
            model = BioBERTClassifier(dropout=hp['dropout'])

    # PubMedBERT models
    elif model_name == 'pubmedbert':
        if use_features:
            model = PubMedBERTWithFeatures(feature_dim=feature_dim, dropout=hp['dropout'])
        else:
            model = PubMedBERTClassifier(dropout=hp['dropout'])

    else:
        raise NotImplementedError(f"Model {model_name} not implemented")

    return model


def run_experiment(config, dataset_name, device, output_dir, logger):
    """Run a single experiment and return results."""
    logger.info("=" * 80)
    logger.info(f"Running experiment: {config.full_model_name}")
    logger.info("=" * 80)
    
    experiment_start_time = time.time()
    results = {
        'model': config.full_model_name,
        'base_model': config.model_name,
        'uses_features': config.use_features,
        'hyperparameters': config.hyperparams.copy()
    }

    try:
        # Prepare data
        if is_transformer_model(config.model_name):
            logger.info("Preparing transformer data with attention masks...")
            encodings, labels, texts = prepare_transformer_data(
                config.model_name, 
                dataset_name, 
                config.hyperparams['max_length']
            )
            
            # Extract features if needed
            features = None
            if config.use_features:
                logger.info("Extracting features...")
                sentiment_features = batch_extract_sentiment_features(texts)
                linguistic_features = batch_extract_linguistic_features(texts)
                features = np.hstack([sentiment_features, linguistic_features])
                logger.info(f"Feature shape: {features.shape}")
            
            train_loader, val_loader = create_transformer_data_loaders(
                encodings, labels, features, 
                config.hyperparams['batch_size']
            )
            vocab_size = None
        else:
            logger.info("Preparing standard data...")
            sequences, labels, vocab_size, texts = prepare_data(
                dataset_name,
                config.hyperparams['max_vocab_size'],
                config.hyperparams['min_word_freq'],
                config.hyperparams['max_length']
            )
            
            # Extract features if needed
            features = None
            if config.use_features:
                logger.info("Extracting features...")
                sentiment_features = batch_extract_sentiment_features(texts)
                linguistic_features = batch_extract_linguistic_features(texts)
                features = np.hstack([sentiment_features, linguistic_features])
                logger.info(f"Feature shape: {features.shape}")
            
            train_loader, val_loader = create_data_loaders(
                sequences, labels, features,
                config.hyperparams['batch_size']
            )

        # Create model
        feature_dim = features.shape[1] if features is not None else None
        model = create_model(config, vocab_size, feature_dim)
        num_params = model.count_parameters()
        results['num_parameters'] = num_params
        logger.info(f"Model created with {num_params:,} parameters")

        # Setup training
        if is_transformer_model(config.model_name):
            lr = config.hyperparams.get('lr', 2e-5)
        else:
            lr = config.hyperparams.get('lr', 0.001)
        
        results['learning_rate'] = lr
        
        optimizer = torch.optim.Adam(model.parameters(), lr=lr)
        
        # Compute class weights
        labels_array = np.array(labels)
        class_counts = np.bincount(labels_array)
        total_samples = len(labels_array)
        class_weights = total_samples / (len(class_counts) * class_counts)
        pos_weight = torch.tensor([class_weights[1] / class_weights[0]], device=device)
        
        logger.info(f"Class distribution: {dict(enumerate(class_counts))}")
        logger.info(f"Using pos_weight: {pos_weight.item():.4f}")
        
        criterion = nn.BCEWithLogitsLoss(pos_weight=pos_weight)

        # Setup callbacks
        checkpoint_dir = output_dir / "checkpoints"
        checkpoint_dir.mkdir(parents=True, exist_ok=True)
        
        callbacks = [
            EarlyStopping(monitor='val_loss', patience=5, mode='min', verbose=False),
            ModelCheckpoint(
                filepath=str(checkpoint_dir / f"{config.full_model_name}_best.pt"),
                monitor='val_loss',
                save_best_only=True,
                mode='min',
                verbose=False
            )
        ]

        # Train model
        trainer = Trainer(
            model=model,
            train_loader=train_loader,
            val_loader=val_loader,
            optimizer=optimizer,
            criterion=criterion,
            device=device,
            callbacks=callbacks,
            log_interval=50,
            checkpoint_dir=str(checkpoint_dir)
        )

        logger.info(f"Starting training for {config.hyperparams['epochs']} epochs...")
        training_start_time = time.time()
        
        history = trainer.train(num_epochs=config.hyperparams['epochs'])
        
        training_time = time.time() - training_start_time
        results['training_time_seconds'] = training_time
        results['training_time_formatted'] = f"{training_time/60:.2f} min"
        
        logger.info(f"Training completed in {training_time/60:.2f} minutes")

        # Evaluate on validation set
        logger.info("Evaluating on validation set...")
        metrics = evaluate_model(model, val_loader, device)
        
        # Store metrics
        results['val_accuracy'] = metrics['accuracy']
        results['precision'] = metrics['precision']
        results['recall'] = metrics['recall']
        results['f1'] = metrics['f1']
        results['roc_auc'] = metrics['roc_auc']
        results['avg_precision'] = metrics['avg_precision']
        results['true_positives'] = metrics['true_positives']
        results['true_negatives'] = metrics['true_negatives']
        results['false_positives'] = metrics['false_positives']
        results['false_negatives'] = metrics['false_negatives']
        results['specificity'] = metrics['specificity']
        results['sensitivity'] = metrics['sensitivity']
        
        # Store best metrics from training
        results['best_val_loss'] = trainer.best_val_loss
        results['best_val_acc'] = trainer.best_val_acc
        
        results['status'] = 'SUCCESS'
        
        logger.info(f"Val Accuracy: {metrics['accuracy']:.4f}")
        logger.info(f"Precision: {metrics['precision']:.4f}, Recall: {metrics['recall']:.4f}")
        logger.info(f"F1: {metrics['f1']:.4f}, ROC AUC: {metrics['roc_auc']:.4f}")
        
    except Exception as e:
        logger.error(f"Experiment failed: {str(e)}")
        results['status'] = 'FAILED'
        results['error'] = str(e)
    
    experiment_time = time.time() - experiment_start_time
    results['total_experiment_time_seconds'] = experiment_time
    results['total_experiment_time_formatted'] = f"{experiment_time/60:.2f} min"
    
    return results


def get_default_hyperparameters(model_name):
    """Get default hyperparameters for each model."""
    
    # Common hyperparameters
    common = {
        'max_length': 200,
        'batch_size': 16,
        'epochs': 10,
        'dropout': 0.3,
    }
    
    # Non-transformer models
    common_non_transformer = {
        **common,
        'max_vocab_size': 10000,
        'min_word_freq': 2,
        'embedding_dim': 128,
        'lr': 0.001,
    }
    
    # Transformer models
    common_transformer = {
        **common,
        'lr': 2e-5,
        'batch_size': 8,  # Smaller batch size for transformers
    }
    
    if model_name == 'ffnn':
        return {
            **common_non_transformer,
            'hidden_dims': [256, 128, 64],
        }
    elif model_name == 'textcnn':
        return {
            **common_non_transformer,
            'num_filters': 100,
            'filter_sizes': [3, 4, 5],
        }
    elif model_name == 'bilstm':
        return {
            **common_non_transformer,
            'hidden_dim': 128,
            'num_layers': 2,
        }
    elif model_name in ['bert', 'biobert', 'pubmedbert']:
        return common_transformer
    else:
        raise ValueError(f"Unknown model: {model_name}")


def create_summary_table(results_list, output_dir):
    """Create a summary table of all experiments."""
    
    # Create DataFrame
    summary_data = []
    for result in results_list:
        if result['status'] == 'SUCCESS':
            row = {
                'Model': result['model'],
                'Uses Features': 'Yes' if result['uses_features'] else 'No',
                'Parameters': f"{result['num_parameters']:,}",
                'Training Time': result['training_time_formatted'],
                'Val Accuracy': f"{result['val_accuracy']:.4f}",
                'Precision': f"{result['precision']:.4f}",
                'Recall': f"{result['recall']:.4f}",
                'F1 Score': f"{result['f1']:.4f}",
                'ROC AUC': f"{result['roc_auc']:.4f}",
                'TP': int(result['true_positives']),
                'TN': int(result['true_negatives']),
                'FP': int(result['false_positives']),
                'FN': int(result['false_negatives']),
            }
        else:
            row = {
                'Model': result['model'],
                'Uses Features': 'Yes' if result['uses_features'] else 'No',
                'Parameters': 'N/A',
                'Training Time': 'N/A',
                'Val Accuracy': 'FAILED',
                'Precision': 'FAILED',
                'Recall': 'FAILED',
                'F1 Score': 'FAILED',
                'ROC AUC': 'FAILED',
                'TP': 'N/A',
                'TN': 'N/A',
                'FP': 'N/A',
                'FN': 'N/A',
            }
        summary_data.append(row)
    
    df = pd.DataFrame(summary_data)
    
    # Save to CSV
    csv_path = output_dir / 'experiment_summary.csv'
    df.to_csv(csv_path, index=False)
    
    # Save detailed results to JSON
    json_path = output_dir / 'experiment_results_detailed.json'
    with open(json_path, 'w') as f:
        json.dump(results_list, f, indent=2)
    
    return df, csv_path, json_path


def main():
    parser = argparse.ArgumentParser(description='Run all experiments')
    parser.add_argument('--dataset', type=str, default='coaid',
                       choices=['coaid', 'healthfact'],
                       help='Dataset to use')
    parser.add_argument('--output-dir', type=str, default='experiment_results',
                       help='Output directory for results')
    parser.add_argument('--device', type=str, default='cpu',
                       choices=['cpu', 'cuda'],
                       help='Device to use for training')
    parser.add_argument('--seed', type=int, default=42,
                       help='Random seed')
    parser.add_argument('--epochs', type=int, default=10,
                       help='Number of epochs for each experiment')
    
    args = parser.parse_args()
    
    # Setup
    set_seed(args.seed)
    logger = setup_logging()
    device = torch.device(args.device)
    
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    logger.info("=" * 80)
    logger.info("HEALTH MISINFORMATION DETECTION - EXPERIMENT SUITE")
    logger.info("=" * 80)
    logger.info(f"Dataset: {args.dataset}")
    logger.info(f"Device: {device}")
    logger.info(f"Output directory: {output_dir}")
    logger.info(f"Random seed: {args.seed}")
    logger.info("=" * 80)
    
    # Define all experiments
    model_names = ['ffnn', 'textcnn', 'bilstm', 'bert', 'biobert', 'pubmedbert']
    experiments = []
    
    for model_name in model_names:
        hyperparams = get_default_hyperparameters(model_name)
        hyperparams['epochs'] = args.epochs  # Override with command line arg
        
        # Without features
        experiments.append(ExperimentConfig(model_name, False, hyperparams))
        
        # With features
        experiments.append(ExperimentConfig(model_name, True, hyperparams))
    
    logger.info(f"Total experiments to run: {len(experiments)}")
    
    # Run all experiments
    all_results = []
    for i, config in enumerate(experiments, 1):
        logger.info(f"\n{'='*80}")
        logger.info(f"EXPERIMENT {i}/{len(experiments)}: {config.full_model_name}")
        logger.info(f"{'='*80}\n")
        
        result = run_experiment(config, args.dataset, device, output_dir, logger)
        all_results.append(result)
        
        # Save intermediate results
        interim_path = output_dir / 'experiment_results_interim.json'
        with open(interim_path, 'w') as f:
            json.dump(all_results, f, indent=2)
    
    # Create summary table
    logger.info("\n" + "=" * 80)
    logger.info("CREATING SUMMARY TABLE")
    logger.info("=" * 80)
    
    summary_df, csv_path, json_path = create_summary_table(all_results, output_dir)
    
    logger.info(f"\nResults saved to:")
    logger.info(f"  - Summary CSV: {csv_path}")
    logger.info(f"  - Detailed JSON: {json_path}")
    
    logger.info("\n" + "=" * 80)
    logger.info("EXPERIMENT SUMMARY TABLE")
    logger.info("=" * 80)
    print("\n" + summary_df.to_string(index=False))
    
    logger.info("\n" + "=" * 80)
    logger.info("ALL EXPERIMENTS COMPLETED!")
    logger.info("=" * 80)


if __name__ == '__main__':
    main()
