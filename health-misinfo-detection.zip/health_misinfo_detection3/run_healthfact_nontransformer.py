"""
Run non-transformer experiments on HealthFact dataset.
Standalone script that doesn't import transformers library.
"""
import argparse
import json
import time
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, random_split
from pathlib import Path
import numpy as np
import pandas as pd
from datetime import datetime
import logging

# Import project modules (non-transformer only)
from src.utils.config import setup_logging, set_seed
from src.data.loaders import load_coaid_dataset, load_healthfact_dataset
from src.data.preprocessors import clean_text, build_vocabulary, text_to_sequences, pad_sequences
from src.data.datasets import TextWithFeaturesDataset, TextOnlyDataset
from src.features.sentiment import batch_extract_sentiment_features
from src.features.linguistic import batch_extract_linguistic_features
from src.models.ffnn import FFNNClassifier, FFNNWithFeatures
from src.models.textcnn import TextCNN, TextCNNWithFeatures
from src.models.bilstm_attention import BiLSTMAttention, BiLSTMAttentionWithFeatures
from src.training.trainer import Trainer
from src.training.callbacks import EarlyStopping, ModelCheckpoint, MetricsLogger
from src.evaluation.metrics import evaluate_model


class ExperimentConfig:
    """Configuration for a single experiment"""
    def __init__(self, name, model_name, use_features=False, epochs=10, batch_size=32,
                 learning_rate=0.001, dropout=0.3, hidden_dim=256, num_filters=100,
                 filter_sizes=[3,4,5], num_layers=2, bidirectional=True):
        self.name = name
        self.model_name = model_name
        self.use_features = use_features
        self.epochs = epochs
        self.batch_size = batch_size
        self.learning_rate = learning_rate
        self.dropout = dropout
        self.hidden_dim = hidden_dim
        self.num_filters = num_filters
        self.filter_sizes = filter_sizes
        self.num_layers = num_layers
        self.bidirectional = bidirectional


def prepare_data(dataset_name, max_vocab_size=10000, min_word_freq=2, max_length=200):
    """Load and prepare dataset for non-transformer models"""
    print(f"Loading {dataset_name} dataset...")
    
    # Load dataset
    if dataset_name == 'coaid':
        df = load_coaid_dataset()
    else:
        df = load_healthfact_dataset()
    
    texts = df['text'].tolist()
    labels = df['label'].tolist()
    
    # Clean texts
    print("Cleaning texts...")
    cleaned_texts = [clean_text(text) for text in texts]
    
    # Build vocabulary
    print("Building vocabulary...")
    word2idx = build_vocabulary(
        cleaned_texts, 
        min_freq=min_word_freq,
        max_vocab_size=max_vocab_size
    )
    vocab_size = len(word2idx)
    
    # Convert to sequences
    print("Converting texts to sequences...")
    sequences = text_to_sequences(cleaned_texts, word2idx)
    sequences = pad_sequences(sequences, max_length=max_length)
    
    # Extract features
    print("Extracting features...")
    sentiment_features = batch_extract_sentiment_features(texts)
    linguistic_features = batch_extract_linguistic_features(texts)
    features = np.concatenate([sentiment_features, linguistic_features], axis=1)
    
    return sequences, labels, features, vocab_size


def create_data_loaders(sequences, labels, features, batch_size, val_split=0.15):
    """Create train and validation data loaders"""
    # Convert to lists for dataset (datasets expect lists not tensors)
    sequences_list = sequences.tolist() if hasattr(sequences, 'tolist') else sequences
    labels_list = labels if isinstance(labels, list) else labels
    features_list = features.tolist() if hasattr(features, 'tolist') else features
    
    # Create dataset
    dataset_with_features = TextWithFeaturesDataset(sequences_list, features_list, labels_list)
    dataset_no_features = TextOnlyDataset(sequences_list, labels_list)
    
    # Split into train/val
    val_size = int(len(dataset_with_features) * val_split)
    train_size = len(dataset_with_features) - val_size
    
    train_dataset_with_features, val_dataset_with_features = random_split(
        dataset_with_features, [train_size, val_size]
    )
    train_dataset_no_features, val_dataset_no_features = random_split(
        dataset_no_features, [train_size, val_size]
    )
    
    # Create data loaders
    train_loader_with_features = DataLoader(
        train_dataset_with_features, batch_size=batch_size, shuffle=True
    )
    val_loader_with_features = DataLoader(
        val_dataset_with_features, batch_size=batch_size
    )
    train_loader_no_features = DataLoader(
        train_dataset_no_features, batch_size=batch_size, shuffle=True
    )
    val_loader_no_features = DataLoader(
        val_dataset_no_features, batch_size=batch_size
    )
    
    return {
        'with_features': (train_loader_with_features, val_loader_with_features),
        'no_features': (train_loader_no_features, val_loader_no_features)
    }


def create_model(config, vocab_size, feature_dim):
    """Create model based on configuration"""
    if config.model_name == 'ffnn':
        if config.use_features:
            model = FFNNWithFeatures(
                vocab_size=vocab_size,
                embedding_dim=100,
                hidden_dims=[config.hidden_dim],
                feature_dim=feature_dim,
                dropout=config.dropout
            )
        else:
            model = FFNNClassifier(
                vocab_size=vocab_size,
                embedding_dim=100,
                hidden_dims=[config.hidden_dim],
                dropout=config.dropout
            )
    
    elif config.model_name == 'textcnn':
        if config.use_features:
            model = TextCNNWithFeatures(
                vocab_size=vocab_size,
                embedding_dim=100,
                num_filters=config.num_filters,
                filter_sizes=config.filter_sizes,
                feature_dim=feature_dim,
                dropout=config.dropout
            )
        else:
            model = TextCNN(
                vocab_size=vocab_size,
                embedding_dim=100,
                num_filters=config.num_filters,
                filter_sizes=config.filter_sizes,
                dropout=config.dropout
            )
    
    elif config.model_name == 'bilstm':
        if config.use_features:
            model = BiLSTMAttentionWithFeatures(
                vocab_size=vocab_size,
                embedding_dim=100,
                hidden_dim=config.hidden_dim,
                num_layers=config.num_layers,
                feature_dim=feature_dim,
                dropout=config.dropout,
                bidirectional=config.bidirectional
            )
        else:
            model = BiLSTMAttention(
                vocab_size=vocab_size,
                embedding_dim=100,
                hidden_dim=config.hidden_dim,
                num_layers=config.num_layers,
                dropout=config.dropout,
                bidirectional=config.bidirectional
            )
    
    else:
        raise ValueError(f"Unknown model: {config.model_name}")
    
    return model


def get_default_hyperparameters(model_name):
    """Get default hyperparameters for each model"""
    defaults = {
        'ffnn': {
            'batch_size': 32,
            'learning_rate': 0.001,
            'dropout': 0.3,
            'hidden_dim': 256
        },
        'textcnn': {
            'batch_size': 32,
            'learning_rate': 0.001,
            'dropout': 0.3,
            'num_filters': 100,
            'filter_sizes': [3, 4, 5]
        },
        'bilstm': {
            'batch_size': 32,
            'learning_rate': 0.001,
            'dropout': 0.3,
            'hidden_dim': 128,
            'num_layers': 2,
            'bidirectional': True
        }
    }
    return defaults.get(model_name, {})


def run_experiment(config, dataset_name, device, sequences, labels, features, vocab_size, loaders):
    """Run a single experiment"""
    print(f"\nExperiment: {config.name}")
    print(f"Model: {config.model_name}, Use features: {config.use_features}")
    print(f"Epochs: {config.epochs}, Batch size: {config.batch_size}")
    
    # Get appropriate data loaders
    loader_key = 'with_features' if config.use_features else 'no_features'
    train_loader, val_loader = loaders[loader_key]
    
    # Create model
    print("Creating model...")
    feature_dim = features.shape[1] if config.use_features else 0
    model = create_model(config, vocab_size, feature_dim)
    model = model.to(device)
    
    num_params = sum(p.numel() for p in model.parameters())
    print(f"Model parameters: {num_params:,}")
    
    # Training setup
    criterion = nn.BCEWithLogitsLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=config.learning_rate)
    
    # Train
    print(f"Training for {config.epochs} epochs...")
    start_time = time.time()
    
    best_val_loss = float('inf')
    for epoch in range(config.epochs):
        model.train()
        train_loss = 0
        for batch in train_loader:
            if config.use_features:
                sequences_batch = batch['input_ids'].to(device)
                features_batch = batch['features'].to(device)
                labels_batch = batch['label'].to(device).float()
                
                optimizer.zero_grad()
                outputs = model(sequences_batch, features_batch)
            else:
                sequences_batch = batch['input_ids'].to(device)
                labels_batch = batch['label'].to(device).float()
                
                optimizer.zero_grad()
                outputs = model(sequences_batch)
            
            loss = criterion(outputs, labels_batch)
            loss.backward()
            optimizer.step()
            train_loss += loss.item()
        
        # Validation
        model.eval()
        val_loss = 0
        with torch.no_grad():
            for batch in val_loader:
                if config.use_features:
                    sequences_batch = batch['input_ids'].to(device)
                    features_batch = batch['features'].to(device)
                    labels_batch = batch['label'].to(device).float()
                    outputs = model(sequences_batch, features_batch)
                else:
                    sequences_batch = batch['input_ids'].to(device)
                    labels_batch = batch['label'].to(device).float()
                    outputs = model(sequences_batch)
                
                loss = criterion(outputs, labels_batch)
                val_loss += loss.item()
        
        avg_train_loss = train_loss / len(train_loader)
        avg_val_loss = val_loss / len(val_loader)
        
        print(f"Epoch {epoch+1}/{config.epochs} - Train Loss: {avg_train_loss:.4f}, Val Loss: {avg_val_loss:.4f}")
        
        if avg_val_loss < best_val_loss:
            best_val_loss = avg_val_loss
    
    train_time = (time.time() - start_time) / 60
    print(f"Training completed in {train_time:.2f} minutes")
    
    # Evaluate
    print("Evaluating...")
    metrics = evaluate_model(model, val_loader, device)
    
    # Store results
    result = {
        'experiment': config.name,
        'model': config.model_name,
        'use_features': config.use_features,
        'dataset': dataset_name,
        'epochs': config.epochs,
        'batch_size': config.batch_size,
        'learning_rate': config.learning_rate,
        'num_parameters': num_params,
        'train_time_min': train_time,
        **metrics
    }
    
    print(f"Accuracy: {metrics['accuracy']:.4f}, F1: {metrics['f1']:.4f}")
    
    return result


def create_summary_table(results, output_dir):
    """Create summary CSV table"""
    df = pd.DataFrame(results)
    
    # Reorder columns
    cols = ['Model', 'Uses Features', 'Parameters', 'Training Time', 
            'Val Accuracy', 'Precision', 'Recall', 'F1 Score', 'ROC AUC',
            'TP', 'TN', 'FP', 'FN']
    
    summary = pd.DataFrame({
        'Model': df['model'],
        'Uses Features': df['use_features'].map({False: 'No', True: 'Yes'}),
        'Parameters': df['num_parameters'].apply(lambda x: f"{x:,}"),
        'Training Time': df['train_time_min'].apply(lambda x: f"{x:.2f} min"),
        'Val Accuracy': df['accuracy'].apply(lambda x: f"{x:.4f}"),
        'Precision': df['precision'].apply(lambda x: f"{x:.4f}"),
        'Recall': df['recall'].apply(lambda x: f"{x:.4f}"),
        'F1 Score': df['f1'].apply(lambda x: f"{x:.4f}"),
        'ROC AUC': df['roc_auc'].apply(lambda x: f"{x:.4f}"),
        'TP': df['true_positives'],
        'TN': df['true_negatives'],
        'FP': df['false_positives'],
        'FN': df['false_negatives']
    })
    
    summary_file = output_dir / 'experiment_summary.csv'
    summary.to_csv(summary_file, index=False)
    print(f"\nSummary table:\n{summary.to_string(index=False)}")
    
    return summary


def main():
    parser = argparse.ArgumentParser(description='Run non-transformer experiments on HealthFact')
    parser.add_argument('--dataset', type=str, default='healthfact',
                       choices=['coaid', 'healthfact'],
                       help='Dataset to use')
    parser.add_argument('--output-dir', type=str, default='experiment_results_healthfact',
                       help='Output directory for results')
    parser.add_argument('--device', type=str, default='cpu',
                       choices=['cpu', 'cuda'],
                       help='Device to use')
    parser.add_argument('--seed', type=int, default=42,
                       help='Random seed')
    parser.add_argument('--epochs', type=str, default='10',
                       help='Number of epochs (single value or 3 comma-separated for ffnn,textcnn,bilstm)')
    
    args = parser.parse_args()
    
    # Parse epochs
    epoch_list = [int(x.strip()) for x in args.epochs.split(',')]
    if len(epoch_list) == 1:
        # Use 2 epochs for BiLSTM to make it faster on CPU
        epochs_dict = {'ffnn': epoch_list[0], 'textcnn': epoch_list[0], 'bilstm': 2}
    elif len(epoch_list) == 3:
        epochs_dict = {'ffnn': epoch_list[0], 'textcnn': epoch_list[1], 'bilstm': epoch_list[2]}
    else:
        raise ValueError("Epochs must be single value or 3 comma-separated values")
    
    # Set seeds
    set_seed(args.seed)
    
    # Create output directory
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    print("="*80)
    print(f"Non-Transformer Experiments - {args.dataset.upper()} Dataset")
    print("="*80)
    print(f"Output: {output_dir}")
    print(f"Device: {args.device}")
    print(f"Epochs: {epochs_dict}")
    print("="*80)
    
    # Prepare data once
    sequences, labels, features, vocab_size = prepare_data(args.dataset)
    feature_dim = features.shape[1]
    print(f"\nDataset size: {len(sequences)}")
    print(f"Vocabulary size: {vocab_size}")
    print(f"Feature dimensions: {feature_dim}")
    
    # Create data loaders once
    print("\nCreating data loaders...")
    loaders = create_data_loaders(sequences, labels, features, batch_size=32)
    
    # Define experiments
    model_names = ['ffnn', 'textcnn', 'bilstm']
    configs = []
    
    for model_name in model_names:
        hp = get_default_hyperparameters(model_name)
        for use_features in [False, True]:
            config = ExperimentConfig(
                name=f"{model_name}_features" if use_features else model_name,
                model_name=model_name,
                use_features=use_features,
                epochs=epochs_dict[model_name],
                **hp
            )
            configs.append(config)
    
    print(f"\nRunning {len(configs)} experiments:")
    for i, config in enumerate(configs, 1):
        feat_str = "with features" if config.use_features else "without features"
        print(f"  {i}. {config.model_name} {feat_str} ({config.epochs} epochs)")
    
    # Run experiments
    results = []
    for i, config in enumerate(configs, 1):
        print(f"\n{'='*80}")
        print(f"Experiment {i}/{len(configs)}")
        print(f"{'='*80}")
        
        try:
            result = run_experiment(
                config, args.dataset, args.device,
                sequences, labels, features, vocab_size, loaders
            )
            results.append(result)
            
            # Save interim results
            interim_file = output_dir / 'experiment_results_interim.json'
            with open(interim_file, 'w') as f:
                json.dump(results, f, indent=2)
            
        except Exception as e:
            print(f"ERROR: {str(e)}")
            import traceback
            traceback.print_exc()
            continue
    
    # Save final results
    print(f"\n{'='*80}")
    print("All Experiments Completed!")
    print(f"{'='*80}")
    
    results_file = output_dir / 'experiment_results_detailed.json'
    with open(results_file, 'w') as f:
        json.dump(results, f, indent=2)
    print(f"\nResults saved to {results_file}")
    
    # Create summary
    create_summary_table(results, output_dir)
    print(f"{'='*80}")


if __name__ == '__main__':
    main()
