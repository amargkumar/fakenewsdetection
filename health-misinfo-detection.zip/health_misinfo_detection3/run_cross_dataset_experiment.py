"""
Cross-Dataset Experiment for Health Misinformation Detection
Tests model generalization by training on one dataset and testing on another

Train on CoAID (COVID) → Test on HealthFact (general health)
Train on HealthFact → Test on CoAID
"""

import argparse
import json
import time
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, random_split
from pathlib import Path
import numpy as np
import pandas as pd
from datetime import datetime
import logging

from src.utils.config import setup_logging, set_seed
from src.data.loaders import load_coaid_dataset, load_healthfact_dataset
from src.data.preprocessors import clean_text
from src.features.sentiment import batch_extract_sentiment_features
from src.features.linguistic import batch_extract_linguistic_features
from src.models.transformer_models import BERTClassifier, BERTWithFeatures, get_transformer_tokenizer
from src.data.datasets import TransformerDataset
from src.training.trainer import Trainer
from src.training.callbacks import EarlyStopping, ModelCheckpoint
from src.evaluation.metrics import evaluate_model


def load_dataset(dataset_name):
    """Load and return dataset."""
    if dataset_name == 'coaid':
        df = load_coaid_dataset(use_sample=False)
    else:
        df = load_healthfact_dataset(split='train', use_sample=False)
    
    texts = [clean_text(text) for text in df['text'].tolist()]
    labels = df['label'].tolist()
    
    return texts, labels


def prepare_transformer_data(texts, labels, model_name='bert', max_length=200, extract_features=False):
    """Prepare data for transformer models with optional features."""
    # Get tokenizer
    tokenizer = get_transformer_tokenizer(model_name)
    
    # Tokenize
    encodings = tokenizer(
        texts,
        truncation=True,
        padding='max_length',
        max_length=max_length,
        return_tensors='pt',
        return_attention_mask=True
    )
    
    # Extract features if needed
    features = None
    if extract_features:
        sentiment_features = batch_extract_sentiment_features(texts)
        linguistic_features = batch_extract_linguistic_features(texts)
        features = np.hstack([sentiment_features, linguistic_features])
    
    return encodings, features


def create_data_loaders(encodings, labels, features, batch_size, val_split=0.15, is_test=False):
    """Create data loaders."""
    dataset = TransformerDataset(encodings, labels, features)
    
    if is_test:
        # For test set, don't split
        loader = DataLoader(dataset, batch_size=batch_size, shuffle=False, num_workers=0)
        return loader
    else:
        # For train set, split into train/val
        val_size = int(val_split * len(dataset))
        train_size = len(dataset) - val_size
        train_dataset, val_dataset = random_split(dataset, [train_size, val_size])
        
        train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True, num_workers=0)
        val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False, num_workers=0)
        
        return train_loader, val_loader


def run_cross_dataset_experiment(train_dataset, test_dataset, use_features, device, output_dir, logger):
    """
    Run a single cross-dataset experiment.
    
    Args:
        train_dataset: Name of training dataset ('coaid' or 'healthfact')
        test_dataset: Name of test dataset ('coaid' or 'healthfact')
        use_features: Whether to use additional features
        device: Device to use for training
        output_dir: Directory to save results
        logger: Logger instance
    """
    experiment_name = f"train_{train_dataset}_test_{test_dataset}{'_features' if use_features else ''}"
    
    logger.info("=" * 80)
    logger.info(f"CROSS-DATASET EXPERIMENT: {experiment_name}")
    logger.info("=" * 80)
    logger.info(f"Training dataset: {train_dataset}")
    logger.info(f"Test dataset: {test_dataset}")
    logger.info(f"Using features: {use_features}")
    
    results = {
        'experiment': experiment_name,
        'train_dataset': train_dataset,
        'test_dataset': test_dataset,
        'uses_features': use_features,
        'model': 'BERT' + ('_features' if use_features else ''),
    }
    
    start_time = time.time()
    
    try:
        # Load datasets
        logger.info(f"\nLoading {train_dataset} dataset for training...")
        train_texts, train_labels = load_dataset(train_dataset)
        logger.info(f"Training samples: {len(train_texts)}")
        logger.info(f"Training label distribution: {dict(pd.Series(train_labels).value_counts())}")
        
        logger.info(f"\nLoading {test_dataset} dataset for testing...")
        test_texts, test_labels = load_dataset(test_dataset)
        logger.info(f"Test samples: {len(test_texts)}")
        logger.info(f"Test label distribution: {dict(pd.Series(test_labels).value_counts())}")
        
        # Prepare training data
        logger.info("\nPreparing training data...")
        train_encodings, train_features = prepare_transformer_data(
            train_texts, train_labels, 'bert', extract_features=use_features
        )
        
        # Prepare test data
        logger.info("Preparing test data...")
        test_encodings, test_features = prepare_transformer_data(
            test_texts, test_labels, 'bert', extract_features=use_features
        )
        
        if use_features:
            logger.info(f"Feature shape: {train_features.shape}")
        
        # Create data loaders
        batch_size = 8
        train_loader, val_loader = create_data_loaders(
            train_encodings, train_labels, train_features, batch_size, is_test=False
        )
        test_loader = create_data_loaders(
            test_encodings, test_labels, test_features, batch_size, is_test=True
        )
        
        logger.info(f"Train batches: {len(train_loader)}, Val batches: {len(val_loader)}, Test batches: {len(test_loader)}")
        
        # Create model
        feature_dim = train_features.shape[1] if use_features else None
        if use_features:
            model = BERTWithFeatures(feature_dim=feature_dim, dropout=0.3)
        else:
            model = BERTClassifier(dropout=0.3)
        
        num_params = model.count_parameters()
        results['num_parameters'] = num_params
        logger.info(f"\nModel created with {num_params:,} parameters")
        
        # Setup training
        lr = 2e-5
        optimizer = torch.optim.Adam(model.parameters(), lr=lr)
        
        # Compute class weights for training set
        train_labels_array = np.array(train_labels)
        class_counts = np.bincount(train_labels_array)
        total_samples = len(train_labels_array)
        class_weights = total_samples / (len(class_counts) * class_counts)
        pos_weight = torch.tensor([class_weights[1] / class_weights[0]], device=device)
        
        logger.info(f"Training class weights - pos_weight: {pos_weight.item():.4f}")
        criterion = nn.BCEWithLogitsLoss(pos_weight=pos_weight)
        
        # Setup callbacks
        checkpoint_dir = output_dir / "checkpoints"
        checkpoint_dir.mkdir(parents=True, exist_ok=True)
        
        callbacks = [
            EarlyStopping(monitor='val_loss', patience=5, mode='min', verbose=True),
            ModelCheckpoint(
                filepath=str(checkpoint_dir / f"{experiment_name}_best.pt"),
                monitor='val_loss',
                save_best_only=True,
                mode='min',
                verbose=True
            )
        ]
        
        # Train model
        trainer = Trainer(
            model=model,
            train_loader=train_loader,
            val_loader=val_loader,
            optimizer=optimizer,
            criterion=criterion,
            device=device,
            callbacks=callbacks,
            log_interval=50,
            checkpoint_dir=str(checkpoint_dir)
        )
        
        epochs = 5
        logger.info(f"\nStarting training for {epochs} epochs...")
        train_start = time.time()
        
        history = trainer.train(num_epochs=epochs)
        
        train_time = time.time() - train_start
        results['training_time_seconds'] = train_time
        results['training_time_formatted'] = f"{train_time/60:.2f} min"
        logger.info(f"Training completed in {train_time/60:.2f} minutes")
        
        # Evaluate on validation set (same domain)
        logger.info("\n" + "=" * 80)
        logger.info(f"Evaluating on VALIDATION set ({train_dataset})...")
        logger.info("=" * 80)
        val_metrics = evaluate_model(model, val_loader, device)
        
        results['val_accuracy'] = val_metrics['accuracy']
        results['val_precision'] = val_metrics['precision']
        results['val_recall'] = val_metrics['recall']
        results['val_f1'] = val_metrics['f1']
        results['val_roc_auc'] = val_metrics['roc_auc']
        
        logger.info(f"Validation (same-domain) Accuracy: {val_metrics['accuracy']:.4f}")
        logger.info(f"Validation Precision: {val_metrics['precision']:.4f}, Recall: {val_metrics['recall']:.4f}")
        logger.info(f"Validation F1: {val_metrics['f1']:.4f}, ROC AUC: {val_metrics['roc_auc']:.4f}")
        
        # Evaluate on test set (cross-domain)
        logger.info("\n" + "=" * 80)
        logger.info(f"Evaluating on TEST set ({test_dataset}) - CROSS-DOMAIN")
        logger.info("=" * 80)
        test_metrics = evaluate_model(model, test_loader, device)
        
        results['test_accuracy'] = test_metrics['accuracy']
        results['test_precision'] = test_metrics['precision']
        results['test_recall'] = test_metrics['recall']
        results['test_f1'] = test_metrics['f1']
        results['test_roc_auc'] = test_metrics['roc_auc']
        results['test_avg_precision'] = test_metrics['avg_precision']
        results['test_true_positives'] = test_metrics['true_positives']
        results['test_true_negatives'] = test_metrics['true_negatives']
        results['test_false_positives'] = test_metrics['false_positives']
        results['test_false_negatives'] = test_metrics['false_negatives']
        results['test_specificity'] = test_metrics['specificity']
        results['test_sensitivity'] = test_metrics['sensitivity']
        
        logger.info(f"\nCross-Domain Test Results:")
        logger.info(f"  Accuracy: {test_metrics['accuracy']:.4f}")
        logger.info(f"  Precision: {test_metrics['precision']:.4f}")
        logger.info(f"  Recall: {test_metrics['recall']:.4f}")
        logger.info(f"  F1 Score: {test_metrics['f1']:.4f}")
        logger.info(f"  ROC AUC: {test_metrics['roc_auc']:.4f}")
        logger.info(f"  True Positives: {int(test_metrics['true_positives'])}")
        logger.info(f"  True Negatives: {int(test_metrics['true_negatives'])}")
        logger.info(f"  False Positives: {int(test_metrics['false_positives'])}")
        logger.info(f"  False Negatives: {int(test_metrics['false_negatives'])}")
        
        # Calculate performance drop
        performance_drop = val_metrics['accuracy'] - test_metrics['accuracy']
        results['accuracy_drop'] = performance_drop
        results['generalization_ratio'] = test_metrics['accuracy'] / val_metrics['accuracy'] if val_metrics['accuracy'] > 0 else 0
        
        logger.info(f"\nGeneralization Analysis:")
        logger.info(f"  Accuracy drop (val→test): {performance_drop:.4f} ({performance_drop*100:.2f}%)")
        logger.info(f"  Generalization ratio: {results['generalization_ratio']:.4f}")
        
        results['status'] = 'SUCCESS'
        
    except Exception as e:
        logger.error(f"Experiment failed: {str(e)}")
        import traceback
        logger.error(traceback.format_exc())
        results['status'] = 'FAILED'
        results['error'] = str(e)
    
    total_time = time.time() - start_time
    results['total_time_seconds'] = total_time
    results['total_time_formatted'] = f"{total_time/60:.2f} min"
    
    return results


def create_summary_table(results_list, output_dir):
    """Create summary table of cross-dataset experiments."""
    
    summary_data = []
    for result in results_list:
        if result['status'] == 'SUCCESS':
            row = {
                'Experiment': result['experiment'],
                'Train Dataset': result['train_dataset'],
                'Test Dataset': result['test_dataset'],
                'Features': 'Yes' if result['uses_features'] else 'No',
                'Val Acc (same-domain)': f"{result['val_accuracy']:.4f}",
                'Test Acc (cross-domain)': f"{result['test_accuracy']:.4f}",
                'Acc Drop': f"{result['accuracy_drop']:.4f}",
                'Gen Ratio': f"{result['generalization_ratio']:.4f}",
                'Test Precision': f"{result['test_precision']:.4f}",
                'Test Recall': f"{result['test_recall']:.4f}",
                'Test F1': f"{result['test_f1']:.4f}",
                'Test ROC AUC': f"{result['test_roc_auc']:.4f}",
                'TP': int(result['test_true_positives']),
                'TN': int(result['test_true_negatives']),
                'FP': int(result['test_false_positives']),
                'FN': int(result['test_false_negatives']),
                'Training Time': result['training_time_formatted'],
            }
        else:
            row = {
                'Experiment': result['experiment'],
                'Train Dataset': result['train_dataset'],
                'Test Dataset': result['test_dataset'],
                'Features': 'Yes' if result['uses_features'] else 'No',
                'Val Acc (same-domain)': 'FAILED',
                'Test Acc (cross-domain)': 'FAILED',
                'Acc Drop': 'N/A',
                'Gen Ratio': 'N/A',
                'Test Precision': 'N/A',
                'Test Recall': 'N/A',
                'Test F1': 'N/A',
                'Test ROC AUC': 'N/A',
                'TP': 'N/A',
                'TN': 'N/A',
                'FP': 'N/A',
                'FN': 'N/A',
                'Training Time': 'N/A',
            }
        summary_data.append(row)
    
    df = pd.DataFrame(summary_data)
    
    # Save to CSV
    csv_path = output_dir / 'cross_dataset_summary.csv'
    df.to_csv(csv_path, index=False)
    
    # Save detailed results to JSON
    json_path = output_dir / 'cross_dataset_results_detailed.json'
    with open(json_path, 'w') as f:
        json.dump(results_list, f, indent=2)
    
    return df, csv_path, json_path


def main():
    parser = argparse.ArgumentParser(description='Run cross-dataset experiments')
    parser.add_argument('--output-dir', type=str, default='cross_dataset_results',
                       help='Output directory for results')
    parser.add_argument('--device', type=str, default='cpu',
                       choices=['cpu', 'cuda'],
                       help='Device to use for training')
    parser.add_argument('--seed', type=int, default=42,
                       help='Random seed')
    parser.add_argument('--with-features', action='store_true',
                       help='Run experiments with features as well')
    
    args = parser.parse_args()
    
    # Setup
    set_seed(args.seed)
    logger = setup_logging()
    device = torch.device(args.device)
    
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    logger.info("=" * 80)
    logger.info("CROSS-DATASET GENERALIZATION EXPERIMENTS")
    logger.info("=" * 80)
    logger.info(f"Model: BERT")
    logger.info(f"Device: {device}")
    logger.info(f"Output directory: {output_dir}")
    logger.info(f"Random seed: {args.seed}")
    logger.info("=" * 80)
    
    # Define experiments
    experiments = [
        ('coaid', 'healthfact', False),      # Train CoAID → Test HealthFact
        ('healthfact', 'coaid', False),      # Train HealthFact → Test CoAID
    ]
    
    # Add feature experiments if requested
    if args.with_features:
        experiments.extend([
            ('coaid', 'healthfact', True),   # Train CoAID → Test HealthFact (with features)
            ('healthfact', 'coaid', True),   # Train HealthFact → Test CoAID (with features)
        ])
    
    logger.info(f"\nTotal experiments to run: {len(experiments)}")
    logger.info("Experiments:")
    for i, (train_ds, test_ds, use_feat) in enumerate(experiments, 1):
        feat_str = " (with features)" if use_feat else ""
        logger.info(f"  {i}. Train on {train_ds} → Test on {test_ds}{feat_str}")
    
    # Run all experiments
    all_results = []
    for i, (train_ds, test_ds, use_feat) in enumerate(experiments, 1):
        logger.info(f"\n{'='*80}")
        logger.info(f"RUNNING EXPERIMENT {i}/{len(experiments)}")
        logger.info(f"{'='*80}\n")
        
        result = run_cross_dataset_experiment(
            train_ds, test_ds, use_feat, device, output_dir, logger
        )
        all_results.append(result)
        
        # Save intermediate results
        interim_path = output_dir / 'cross_dataset_results_interim.json'
        with open(interim_path, 'w') as f:
            json.dump(all_results, f, indent=2)
    
    # Create summary table
    logger.info("\n" + "=" * 80)
    logger.info("CREATING SUMMARY TABLE")
    logger.info("=" * 80)
    
    summary_df, csv_path, json_path = create_summary_table(all_results, output_dir)
    
    logger.info(f"\nResults saved to:")
    logger.info(f"  - Summary CSV: {csv_path}")
    logger.info(f"  - Detailed JSON: {json_path}")
    
    logger.info("\n" + "=" * 80)
    logger.info("CROSS-DATASET EXPERIMENT SUMMARY")
    logger.info("=" * 80)
    print("\n" + summary_df.to_string(index=False))
    
    logger.info("\n" + "=" * 80)
    logger.info("KEY INSIGHTS")
    logger.info("=" * 80)
    
    # Analyze results
    if len([r for r in all_results if r['status'] == 'SUCCESS']) > 0:
        for result in all_results:
            if result['status'] == 'SUCCESS':
                logger.info(f"\n{result['experiment']}:")
                logger.info(f"  Same-domain accuracy: {result['val_accuracy']:.4f}")
                logger.info(f"  Cross-domain accuracy: {result['test_accuracy']:.4f}")
                logger.info(f"  Generalization ratio: {result['generalization_ratio']:.4f}")
                
                if result['generalization_ratio'] > 0.9:
                    logger.info(f"  ✓ Excellent generalization (>90%)")
                elif result['generalization_ratio'] > 0.8:
                    logger.info(f"  ✓ Good generalization (>80%)")
                elif result['generalization_ratio'] > 0.7:
                    logger.info(f"  ~ Moderate generalization (>70%)")
                else:
                    logger.info(f"  ✗ Poor generalization (<70%)")
    
    logger.info("\n" + "=" * 80)
    logger.info("ALL CROSS-DATASET EXPERIMENTS COMPLETED!")
    logger.info("=" * 80)


if __name__ == '__main__':
    main()
