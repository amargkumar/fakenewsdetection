"""
Confusion Matrix Visualization - Healthcare Misinformation Detection Models
Exact recreation of the provided visualization
"""

import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Data extracted from image: (Model Name, TP, TN, FP, FN)
models_data = [
    ('FFN (No Features)', 229, 72, 11, 12),
    ('FFN (With Features)', 222, 77, 10, 15),
    ('TextCNN (No Features)', 229, 62, 18, 15),
    ('TextCNN (With Features)', 232, 64, 14, 14),
    ('BiLSTM (No Features)', 228, 69, 12, 15),
    ('BiLSTM (With Features)', 232, 67, 19, 6),
    ('BERT (No Features)', 230, 92, 2, 0),
    ('BERT (With Features)', 241, 80, 3, 0)
]

def create_confusion_matrix(tp, tn, fp, fn):
    """Create confusion matrix: [[TN, FP], [FN, TP]]"""
    return np.array([[tn, fp], [fn, tp]])

def calculate_metrics(tp, tn, fp, fn):
    """Calculate accuracy, precision, recall, F1"""
    total = tp + tn + fp + fn
    accuracy = (tp + tn) / total
    precision = tp / (tp + fp) if (tp + fp) > 0 else 0
    recall = tp / (tp + fn) if (tp + fn) > 0 else 0
    f1 = 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0
    return accuracy, precision, recall, f1

# Create figure with 3x3 grid (8 models + 1 legend)
fig = plt.figure(figsize=(20, 12))
gs = fig.add_gridspec(3, 3, hspace=0.4, wspace=0.3)

# Main title
fig.suptitle('Confusion Matrices - Health Misinformation Detection Models', 
             fontsize=24, fontweight='bold', y=0.98)

# Plot each model
for idx, (model_name, tp, tn, fp, fn) in enumerate(models_data):
    row = idx // 3
    col = idx % 3
    ax = fig.add_subplot(gs[row, col])
    
    cm = create_confusion_matrix(tp, tn, fp, fn)
    acc, prec, rec, f1 = calculate_metrics(tp, tn, fp, fn)
    
    # Plot heatmap
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
                cbar=True, square=True, ax=ax,
                annot_kws={'size': 16, 'weight': 'bold'},
                vmin=0, vmax=250)
    
    # Labels
    ax.set_xlabel('Predicted Label', fontsize=12, fontweight='bold')
    ax.set_ylabel('Actual Label', fontsize=12, fontweight='bold')
    ax.set_xticklabels(['Real (0)', 'Fake (1)'], fontsize=11)
    ax.set_yticklabels(['Real (0)', 'Fake (1)'], fontsize=11, rotation=0)
    
    # Title with metrics
    title = f'{model_name}\n'
    title += f'Acc: {acc:.3f} | Prec: {prec:.3f} | Rec: {rec:.3f} | F1: {f1:.3f}'
    ax.set_title(title, fontsize=13, fontweight='bold', pad=10)

# Add legend in bottom-right position
legend_ax = fig.add_subplot(gs[2, 2])
legend_ax.axis('off')

legend_text = """Confusion Matrix Legend:

       Predicted
       Real  Fake
Actual ┌─────┬─────┐
 Real  │ TN  │ FP  │
       ├─────┼─────┤
 Fake  │ FN  │ TP  │
       └─────┴─────┘

TN = True Negative (Correctly predicted Real)
FP = False Positive (Real predicted as Fake)
FN = False Negative (Fake predicted as Real)
TP = True Positive (Correctly predicted Fake)"""

legend_ax.text(0.1, 0.5, legend_text, 
              fontsize=11, family='monospace',
              verticalalignment='center',
              bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.3))

plt.savefig('confusion_matrices.png', dpi=300, bbox_inches='tight', facecolor='white')
print("✅ Saved: confusion_matrices.png")

# Print arrays
print("\n" + "="*80)
print("CONFUSION MATRIX ARRAYS")
print("="*80)

for model_name, tp, tn, fp, fn in models_data:
    cm = create_confusion_matrix(tp, tn, fp, fn)
    print(f"\n{model_name}:")
    print(f"np.array({cm.tolist()})")
    print(f"# [[TN={tn}, FP={fp}], [FN={fn}, TP={tp}]]")

# Print metrics table
print("\n" + "="*80)
print("PERFORMANCE METRICS")
print("="*80)
print(f"\n{'Model':<30} {'Acc':>8} {'Prec':>8} {'Rec':>8} {'F1':>8} | {'TP':>4} {'TN':>4} {'FP':>4} {'FN':>4}")
print("-"*80)

for model_name, tp, tn, fp, fn in models_data:
    acc, prec, rec, f1 = calculate_metrics(tp, tn, fp, fn)
    print(f"{model_name:<30} {acc:>8.3f} {prec:>8.3f} {rec:>8.3f} {f1:>8.3f} | {tp:>4} {tn:>4} {fp:>4} {fn:>4}")

print("="*80)

# Best models
print("\n" + "="*80)
print("BEST MODELS BY METRIC")
print("="*80)

metrics_list = []
for model_name, tp, tn, fp, fn in models_data:
    acc, prec, rec, f1 = calculate_metrics(tp, tn, fp, fn)
    metrics_list.append((model_name, acc, prec, rec, f1))

best_acc = max(metrics_list, key=lambda x: x[1])
best_prec = max(metrics_list, key=lambda x: x[2])
best_rec = max(metrics_list, key=lambda x: x[3])
best_f1 = max(metrics_list, key=lambda x: x[4])

print(f"\nBest Accuracy:  {best_acc[0]:<35} {best_acc[1]:.4f}")
print(f"Best Precision: {best_prec[0]:<35} {best_prec[2]:.4f}")
print(f"Best Recall:    {best_rec[0]:<35} {best_rec[3]:.4f}")
print(f"Best F1-Score:  {best_f1[0]:<35} {best_f1[4]:.4f}")

print("\n" + "="*80)
print("KEY FINDINGS")
print("="*80)
print("🏆 BERT (No Features) - Best overall performer (99.4% accuracy, 99.6% F1)")
print("🎯 Both BERT models achieved perfect recall (100%) - Zero false negatives!")
print("⚠️  BiLSTM (With Features) has highest FP (19) - Over-aggressive flagging")
print("="*80)

plt.show()