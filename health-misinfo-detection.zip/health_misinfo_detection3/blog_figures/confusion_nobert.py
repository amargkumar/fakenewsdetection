"""
Confusion Matrix Analysis - Healthcare Misinformation Detection
Single script to generate confusion matrices and visualizations
"""

import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Data: (Model Name, TP, TN, FP, FN)
models_data = [
    ('FFN (No Features)', 703, 646, 234, 254),
    ('FFN (With Features)', 657, 665, 245, 270),
    ('TextCNN (No Features)', 713, 592, 288, 244),
    ('TextCNN (With Features)', 676, 580, 330, 251),
    ('BiLSTM (No Features)', 662, 713, 167, 295),
    ('BiLSTM (With Features)', 564, 788, 122, 363)
]

def create_confusion_matrix(tp, tn, fp, fn):
    """Create confusion matrix: [[TN, FP], [FN, TP]]"""
    return np.array([[tn, fp], [fn, tp]])

def calculate_metrics(tp, tn, fp, fn):
    """Calculate accuracy, precision, recall, F1"""
    total = tp + tn + fp + fn
    accuracy = (tp + tn) / total
    precision = tp / (tp + fp) if (tp + fp) > 0 else 0
    recall = tp / (tp + fn) if (tp + fn) > 0 else 0
    f1 = 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0
    return accuracy, precision, recall, f1

# Create visualization
fig, axes = plt.subplots(2, 3, figsize=(18, 12))
fig.suptitle('Confusion Matrices', fontsize=24, fontweight='bold')

for idx, (model_name, tp, tn, fp, fn) in enumerate(models_data):
    row = idx // 3
    col = idx % 3
    ax = axes[row, col]
    
    cm = create_confusion_matrix(tp, tn, fp, fn)
    acc, prec, rec, f1 = calculate_metrics(tp, tn, fp, fn)
    
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
                cbar=True, square=True, ax=ax,
                annot_kws={'size': 16, 'weight': 'bold'},
                vmin=0, vmax=800)
    
    ax.set_xlabel('Predicted Label', fontsize=12, fontweight='bold')
    ax.set_ylabel('Actual Label', fontsize=12, fontweight='bold')
    ax.set_xticklabels(['Real (0)', 'Fake (1)'], fontsize=11)
    ax.set_yticklabels(['Real (0)', 'Fake (1)'], fontsize=11, rotation=0)
    
    title = f'{model_name}\nAcc: {acc:.3f} | Prec: {prec:.3f} | Rec: {rec:.3f} | F1: {f1:.3f}'
    ax.set_title(title, fontsize=12, fontweight='bold', pad=10)

plt.tight_layout()
plt.savefig('confusion_matrices.png', dpi=300, bbox_inches='tight', facecolor='white')
print("✅ Saved: confusion_matrices.png")

# Print arrays
print("\n" + "="*80)
print("CONFUSION MATRIX ARRAYS")
print("="*80)

for model_name, tp, tn, fp, fn in models_data:
    cm = create_confusion_matrix(tp, tn, fp, fn)
    print(f"\n{model_name}:")
    print(f"np.array({cm.tolist()})")

# Print metrics
print("\n" + "="*80)
print("PERFORMANCE METRICS")
print("="*80)
print(f"\n{'Model':<30} {'Acc':>8} {'Prec':>8} {'Rec':>8} {'F1':>8}")
print("-"*80)

for model_name, tp, tn, fp, fn in models_data:
    acc, prec, rec, f1 = calculate_metrics(tp, tn, fp, fn)
    print(f"{model_name:<30} {acc:>8.4f} {prec:>8.4f} {rec:>8.4f} {f1:>8.4f}")

print("="*80)
plt.show()