"""
Feature Importance Analysis for Health Misinformation Detection
Analyzes which of the 16 engineered features have the best predictive value
"""

import argparse
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.feature_selection import mutual_info_classif, f_classif
from sklearn.preprocessing import StandardScaler
from scipy.stats import pointbiserialr, spearmanr
import logging

from src.utils.config import setup_logging, set_seed
from src.data.loaders import load_coaid_dataset, load_healthfact_dataset
from src.data.preprocessors import clean_text
from src.features.sentiment import batch_extract_sentiment_features
from src.features.linguistic import batch_extract_linguistic_features


# Feature names for the 16 features
SENTIMENT_FEATURES = [
    'compound_score',
    'positive_score',
    'negative_score',
    'neutral_score',
    'subjectivity',
    'polarity'
]

LINGUISTIC_FEATURES = [
    'num_words',
    'num_chars',
    'avg_word_length',
    'num_uppercase',
    'num_exclamation',
    'num_question',
    'flesch_reading_ease',
    'flesch_kincaid_grade',
    'automated_readability_index',
    'num_sentences'
]

ALL_FEATURE_NAMES = SENTIMENT_FEATURES + LINGUISTIC_FEATURES


def load_and_prepare_data(dataset_name, logger):
    """Load dataset and extract features."""
    logger.info(f"Loading {dataset_name} dataset...")
    
    if dataset_name == 'coaid':
        df = load_coaid_dataset(use_sample=False)
    else:
        df = load_healthfact_dataset(split='train', use_sample=False)
    
    logger.info(f"Loaded {len(df)} samples")
    
    # Clean text
    texts = [clean_text(text) for text in df['text'].tolist()]
    labels = np.array(df['label'].tolist())
    
    # Extract features
    logger.info("Extracting sentiment features...")
    sentiment_features = batch_extract_sentiment_features(texts)
    
    logger.info("Extracting linguistic features...")
    linguistic_features = batch_extract_linguistic_features(texts)
    
    # Combine features
    features = np.hstack([sentiment_features, linguistic_features])
    logger.info(f"Feature matrix shape: {features.shape}")
    
    return features, labels, texts


def correlation_analysis(features, labels, feature_names, logger):
    """Compute point-biserial correlation for binary labels."""
    logger.info("\n" + "="*80)
    logger.info("CORRELATION ANALYSIS (Point-Biserial)")
    logger.info("="*80)
    
    correlations = []
    p_values = []
    
    for i, name in enumerate(feature_names):
        # Point-biserial correlation for binary target
        corr, p_val = pointbiserialr(labels, features[:, i])
        correlations.append(abs(corr))  # Use absolute value
        p_values.append(p_val)
        
        sig = "***" if p_val < 0.001 else "**" if p_val < 0.01 else "*" if p_val < 0.05 else ""
        logger.info(f"{name:35s}: corr={corr:7.4f} (|corr|={abs(corr):.4f}), p={p_val:.4e} {sig}")
    
    results = pd.DataFrame({
        'feature': feature_names,
        'correlation': correlations,
        'p_value': p_values
    }).sort_values('correlation', ascending=False)
    
    return results


def mutual_information_analysis(features, labels, feature_names, logger):
    """Compute mutual information scores."""
    logger.info("\n" + "="*80)
    logger.info("MUTUAL INFORMATION ANALYSIS")
    logger.info("="*80)
    
    mi_scores = mutual_info_classif(features, labels, random_state=42)
    
    for name, score in zip(feature_names, mi_scores):
        logger.info(f"{name:35s}: MI={score:.4f}")
    
    results = pd.DataFrame({
        'feature': feature_names,
        'mutual_information': mi_scores
    }).sort_values('mutual_information', ascending=False)
    
    return results


def anova_f_test(features, labels, feature_names, logger):
    """Compute ANOVA F-statistic for feature selection."""
    logger.info("\n" + "="*80)
    logger.info("ANOVA F-TEST")
    logger.info("="*80)
    
    f_scores, p_values = f_classif(features, labels)
    
    for name, f_score, p_val in zip(feature_names, f_scores, p_values):
        sig = "***" if p_val < 0.001 else "**" if p_val < 0.01 else "*" if p_val < 0.05 else ""
        logger.info(f"{name:35s}: F={f_score:8.2f}, p={p_val:.4e} {sig}")
    
    results = pd.DataFrame({
        'feature': feature_names,
        'f_score': f_scores,
        'p_value': p_values
    }).sort_values('f_score', ascending=False)
    
    return results


def random_forest_importance(features, labels, feature_names, logger):
    """Train Random Forest and extract feature importances."""
    logger.info("\n" + "="*80)
    logger.info("RANDOM FOREST FEATURE IMPORTANCE")
    logger.info("="*80)
    
    # Standardize features
    scaler = StandardScaler()
    features_scaled = scaler.fit_transform(features)
    
    # Train Random Forest
    rf = RandomForestClassifier(n_estimators=100, random_state=42, max_depth=10, n_jobs=-1)
    rf.fit(features_scaled, labels)
    
    importances = rf.feature_importances_
    
    logger.info(f"Random Forest Accuracy: {rf.score(features_scaled, labels):.4f}")
    logger.info("\nFeature Importances:")
    
    for name, importance in zip(feature_names, importances):
        logger.info(f"{name:35s}: {importance:.4f}")
    
    results = pd.DataFrame({
        'feature': feature_names,
        'rf_importance': importances
    }).sort_values('rf_importance', ascending=False)
    
    return results


def logistic_regression_coefficients(features, labels, feature_names, logger):
    """Train Logistic Regression and extract coefficients."""
    logger.info("\n" + "="*80)
    logger.info("LOGISTIC REGRESSION COEFFICIENTS")
    logger.info("="*80)
    
    # Standardize features (important for coefficient interpretation)
    scaler = StandardScaler()
    features_scaled = scaler.fit_transform(features)
    
    # Train Logistic Regression
    lr = LogisticRegression(random_state=42, max_iter=1000)
    lr.fit(features_scaled, labels)
    
    coefficients = lr.coef_[0]
    
    logger.info(f"Logistic Regression Accuracy: {lr.score(features_scaled, labels):.4f}")
    logger.info("\nCoefficients (positive = predicts class 1, negative = predicts class 0):")
    
    for name, coef in zip(feature_names, coefficients):
        logger.info(f"{name:35s}: {coef:7.4f}")
    
    results = pd.DataFrame({
        'feature': feature_names,
        'lr_coefficient': coefficients,
        'lr_abs_coefficient': np.abs(coefficients)
    }).sort_values('lr_abs_coefficient', ascending=False)
    
    return results


def create_summary_table(corr_results, mi_results, f_results, rf_results, lr_results):
    """Combine all results into a single summary table."""
    
    # Merge all results
    summary = corr_results[['feature', 'correlation']].copy()
    summary = summary.merge(mi_results[['feature', 'mutual_information']], on='feature')
    summary = summary.merge(f_results[['feature', 'f_score']], on='feature')
    summary = summary.merge(rf_results[['feature', 'rf_importance']], on='feature')
    summary = summary.merge(lr_results[['feature', 'lr_abs_coefficient']], on='feature')
    
    # Normalize all scores to 0-1 range for comparison
    for col in ['correlation', 'mutual_information', 'f_score', 'rf_importance', 'lr_abs_coefficient']:
        max_val = summary[col].max()
        if max_val > 0:
            summary[f'{col}_norm'] = summary[col] / max_val
    
    # Compute average normalized score
    norm_cols = [c for c in summary.columns if c.endswith('_norm')]
    summary['avg_importance'] = summary[norm_cols].mean(axis=1)
    
    # Sort by average importance
    summary = summary.sort_values('avg_importance', ascending=False)
    
    return summary


def plot_feature_importance(summary, output_dir, dataset_name):
    """Create visualization of feature importance."""
    
    # Set style
    sns.set_style("whitegrid")
    fig = plt.figure(figsize=(14, 10))
    
    # Prepare data for plotting
    plot_data = summary[['feature', 'correlation_norm', 'mutual_information_norm', 
                         'f_score_norm', 'rf_importance_norm', 'lr_abs_coefficient_norm']].copy()
    plot_data.columns = ['Feature', 'Correlation', 'Mutual Info', 'F-Score', 
                         'Random Forest', 'Log Regression']
    
    # Melt for grouped bar plot
    plot_data_melted = plot_data.melt(id_vars=['Feature'], 
                                      var_name='Method', 
                                      value_name='Normalized Importance')
    
    # Create plot
    plt.subplot(2, 1, 1)
    sns.barplot(data=plot_data_melted, x='Feature', y='Normalized Importance', 
                hue='Method', palette='Set2')
    plt.xticks(rotation=45, ha='right')
    plt.title(f'Feature Importance - {dataset_name.upper()} Dataset (Normalized)', 
              fontsize=14, fontweight='bold')
    plt.ylabel('Normalized Importance Score')
    plt.xlabel('')
    plt.legend(title='Method', bbox_to_anchor=(1.05, 1), loc='upper left')
    plt.tight_layout()
    
    # Average importance plot
    plt.subplot(2, 1, 2)
    colors = ['#1f77b4' if feat in SENTIMENT_FEATURES else '#ff7f0e' 
              for feat in summary['feature']]
    plt.barh(summary['feature'], summary['avg_importance'], color=colors)
    plt.xlabel('Average Normalized Importance', fontsize=12)
    plt.ylabel('Feature', fontsize=12)
    plt.title('Average Feature Importance (Blue=Sentiment, Orange=Linguistic)', 
              fontsize=14, fontweight='bold')
    plt.gca().invert_yaxis()
    plt.tight_layout()
    
    # Save
    output_path = output_dir / f'feature_importance_{dataset_name}.png'
    plt.savefig(output_path, dpi=300, bbox_inches='tight')
    plt.close()
    
    return output_path


def main():
    parser = argparse.ArgumentParser(description='Analyze feature importance')
    parser.add_argument('--dataset', type=str, default='coaid',
                       choices=['coaid', 'healthfact'],
                       help='Dataset to analyze')
    parser.add_argument('--output-dir', type=str, default='feature_analysis',
                       help='Output directory for results')
    parser.add_argument('--seed', type=int, default=42,
                       help='Random seed')
    
    args = parser.parse_args()
    
    # Setup
    set_seed(args.seed)
    logger = setup_logging()
    
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    logger.info("="*80)
    logger.info("FEATURE IMPORTANCE ANALYSIS")
    logger.info("="*80)
    logger.info(f"Dataset: {args.dataset}")
    logger.info(f"Output directory: {output_dir}")
    logger.info(f"Total features: 16 (6 sentiment + 10 linguistic)")
    logger.info("="*80)
    
    # Load data and extract features
    features, labels, texts = load_and_prepare_data(args.dataset, logger)
    
    # Run all analyses
    corr_results = correlation_analysis(features, labels, ALL_FEATURE_NAMES, logger)
    mi_results = mutual_information_analysis(features, labels, ALL_FEATURE_NAMES, logger)
    f_results = anova_f_test(features, labels, ALL_FEATURE_NAMES, logger)
    rf_results = random_forest_importance(features, labels, ALL_FEATURE_NAMES, logger)
    lr_results = logistic_regression_coefficients(features, labels, ALL_FEATURE_NAMES, logger)
    
    # Create summary table
    logger.info("\n" + "="*80)
    logger.info("CREATING SUMMARY TABLE")
    logger.info("="*80)
    
    summary = create_summary_table(corr_results, mi_results, f_results, rf_results, lr_results)
    
    # Save summary
    csv_path = output_dir / f'feature_importance_{args.dataset}.csv'
    summary.to_csv(csv_path, index=False)
    logger.info(f"Summary saved to: {csv_path}")
    
    # Create visualization
    plot_path = plot_feature_importance(summary, output_dir, args.dataset)
    logger.info(f"Visualization saved to: {plot_path}")
    
    # Print top features
    logger.info("\n" + "="*80)
    logger.info("TOP 10 MOST IMPORTANT FEATURES")
    logger.info("="*80)
    
    top_10 = summary.head(10)
    for idx, row in top_10.iterrows():
        feature_type = "SENTIMENT" if row['feature'] in SENTIMENT_FEATURES else "LINGUISTIC"
        logger.info(f"\n{row['feature']} ({feature_type})")
        logger.info(f"  Avg Importance: {row['avg_importance']:.4f}")
        logger.info(f"  Correlation:    {row['correlation']:.4f}")
        logger.info(f"  Mutual Info:    {row['mutual_information']:.4f}")
        logger.info(f"  F-Score:        {row['f_score']:.2f}")
        logger.info(f"  RF Importance:  {row['rf_importance']:.4f}")
        logger.info(f"  LR Coef (abs):  {row['lr_abs_coefficient']:.4f}")
    
    # Summary statistics
    logger.info("\n" + "="*80)
    logger.info("FEATURE TYPE COMPARISON")
    logger.info("="*80)
    
    sentiment_avg = summary[summary['feature'].isin(SENTIMENT_FEATURES)]['avg_importance'].mean()
    linguistic_avg = summary[summary['feature'].isin(LINGUISTIC_FEATURES)]['avg_importance'].mean()
    
    logger.info(f"Average importance of SENTIMENT features:  {sentiment_avg:.4f}")
    logger.info(f"Average importance of LINGUISTIC features: {linguistic_avg:.4f}")
    
    if sentiment_avg > linguistic_avg:
        logger.info("\n→ SENTIMENT features are more important on average")
    else:
        logger.info("\n→ LINGUISTIC features are more important on average")
    
    logger.info("\n" + "="*80)
    logger.info("ANALYSIS COMPLETE!")
    logger.info("="*80)
    logger.info(f"\nResults saved to: {output_dir}")


if __name__ == '__main__':
    main()
