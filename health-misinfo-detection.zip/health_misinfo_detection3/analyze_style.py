import pandas as pd
import numpy as np
import re

# Load CoAID dataset
df = pd.read_csv('data/raw/coaid/coaid_combined.csv')
real = df[df['label'] == 1]['text']
fake = df[df['label'] == 0]['text']

print("=" * 80)
print("REAL NEWS CHARACTERISTICS (Training Data)")
print("=" * 80)
print(f"Count: {len(real)} samples")
print(f"Average length: {real.str.len().mean():.1f} characters")
print(f"Average words: {real.str.split().str.len().mean():.1f} words")
print(f"Median length: {real.str.len().median():.0f} characters")
print(f"Length range: {real.str.len().min()}-{real.str.len().max()} characters")
print(f"\nPunctuation patterns:")
period_count = real.str.endswith('.').sum()
quote_count = real.str.contains('"').sum()
colon_count = real.str.contains(':').sum()
question_count = real.str.contains('?', regex=False).sum()
print(f"  - Ends with period: {period_count} ({period_count/len(real)*100:.1f}%)")
print(f"  - Contains quotes: {quote_count} ({quote_count/len(real)*100:.1f}%)")
print(f"  - Contains colon: {colon_count} ({colon_count/len(real)*100:.1f}%)")
print(f"  - Contains question mark: {question_count} ({question_count/len(real)*100:.1f}%)")
print(f"\nCapitalization:")
print(f"  - Contains COVID/COVID-19: {real.str.contains('COVID', case=False).sum()} ({real.str.contains('COVID', case=False).sum()/len(real)*100:.1f}%)")
print(f"  - Starts with capital letter: {real.str[0].str.isupper().sum()} ({real.str[0].str.isupper().sum()/len(real)*100:.1f}%)")

print(f"\n{'=' * 80}")
print("SAMPLE REAL NEWS HEADLINES (random 15):")
print("=" * 80)
for i, text in enumerate(real.sample(15, random_state=42).values, 1):
    print(f"{i:2d}. [{len(text):3d} chars] {text}")

print(f"\n{'=' * 80}")
print("FAKE NEWS CHARACTERISTICS (Training Data)")
print("=" * 80)
print(f"Count: {len(fake)} samples")
print(f"Average length: {fake.str.len().mean():.1f} characters")
print(f"Average words: {fake.str.split().str.len().mean():.1f} words")
print(f"Median length: {fake.str.len().median():.0f} characters")
print(f"Length range: {fake.str.len().min()}-{fake.str.len().max()} characters")
print(f"\nPunctuation patterns:")
period_count_f = fake.str.endswith('.').sum()
quote_count_f = fake.str.contains('"').sum()
colon_count_f = fake.str.contains(':').sum()
question_count_f = fake.str.contains('?', regex=False).sum()
print(f"  - Ends with period: {period_count_f} ({period_count_f/len(fake)*100:.1f}%)")
print(f"  - Contains quotes: {quote_count_f} ({quote_count_f/len(fake)*100:.1f}%)")
print(f"  - Contains colon: {colon_count_f} ({colon_count_f/len(fake)*100:.1f}%)")
print(f"  - Contains question mark: {question_count_f} ({question_count_f/len(fake)*100:.1f}%)")
print(f"\nCapitalization:")
print(f"  - Contains COVID/COVID-19: {fake.str.contains('COVID', case=False).sum()} ({fake.str.contains('COVID', case=False).sum()/len(fake)*100:.1f}%)")
print(f"  - Starts with capital letter: {fake.str[0].str.isupper().sum()} ({fake.str[0].str.isupper().sum()/len(fake)*100:.1f}%)")

print(f"\n{'=' * 80}")
print("SAMPLE FAKE NEWS HEADLINES (random 15):")
print("=" * 80)
for i, text in enumerate(fake.sample(15, random_state=42).values, 1):
    print(f"{i:2d}. [{len(text):3d} chars] {text}")

print(f"\n{'=' * 80}")
print("KEY STYLISTIC GUIDELINES FOR TESTING:")
print("=" * 80)
print("""
✅ REAL NEWS typically:
   - Short headlines (average 58-95 characters)
   - Formal news title style (capitalizes key words)
   - Often includes source/organization names (WHO, CDC, GMC, etc.)
   - Factual, neutral tone
   - Common formats:
     * "COVID-19: [Specific Event/Announcement]"
     * "Organization statement on [topic]"
     * "Experts [action/opinion] about [topic]"
   - May or may NOT end with period (both common)
   - Often contains colons or quotes

❌ FAKE NEWS typically:
   - Complete sentences (average 94-139 characters)  
   - Makes bold claims or assertions
   - Ends with period (97.9% of training data)
   - More sensational/emotional language
   - Common formats:
     * "[Claim] protects/cures/causes [disease]"
     * "Video/Post shows [dramatic event]"
     * "[Authority figure] is doing [controversial action]"
   - More likely to have lowercase starts

⚠️ CRITICAL: Your input should match the HEADLINE/SHORT TITLE style, NOT full article text!
   The model was trained on news TITLES, not descriptions or full sentences.
""")

print(f"\n{'=' * 80}")
print("LENGTH DISTRIBUTION COMPARISON:")
print("=" * 80)
print(f"Real news lengths: {real.str.len().quantile([0.25, 0.5, 0.75]).values}")
print(f"Fake news lengths: {fake.str.len().quantile([0.25, 0.5, 0.75]).values}")
