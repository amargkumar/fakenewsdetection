"""
Main entry point for Health Misinformation Detection System
"""
import argparse
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, random_split
from pathlib import Path
import numpy as np

from src.utils.config import load_config, setup_logging, set_seed
from src.data.loaders import load_coaid_dataset, load_healthfact_dataset
from src.data.preprocessors import clean_text, build_vocabulary, text_to_sequences, pad_sequences
from src.data.datasets import TextWithFeaturesDataset, TextOnlyDataset
from src.features.sentiment import batch_extract_sentiment_features
from src.features.linguistic import batch_extract_linguistic_features
from src.models.ffnn import FFNNClassifier, FFNNWithFeatures
from src.models.textcnn import TextCNN, TextCNNWithFeatures
from src.models.bilstm_attention import BiLSTMAttention, BiLSTMAttentionWithFeatures
from src.models.transformer_models import (
    BERTClassifier, BioBERTClassifier, PubMedBERTClassifier,
    BERTWithFeatures, BioBERTWithFeatures, PubMedBERTWithFeatures,
    get_transformer_tokenizer
)
from src.data.datasets import TransformerDataset
from src.training.trainer import Trainer
from src.training.callbacks import EarlyStopping, ModelCheckpoint, MetricsLogger
from src.evaluation.metrics import evaluate_model, print_classification_report, get_confusion_matrix
from src.evaluation.visualization import (
    plot_training_history,
    plot_confusion_matrix,
    create_evaluation_report
)


def parse_args():
    parser = argparse.ArgumentParser(description='Health Misinformation Detection')
    
    # Model arguments
    parser.add_argument('--model', type=str, required=True,
                        choices=['ffnn', 'ffnn_features', 'textcnn', 'textcnn_features',
                                'bilstm', 'bilstm_features', 'bert', 'bert_features',
                                'biobert', 'biobert_features', 'pubmedbert', 'pubmedbert_features'],
                        help='Model architecture to use')
    
    # Data arguments
    parser.add_argument('--dataset', type=str, default='coaid',
                        choices=['coaid', 'healthfact'],
                        help='Dataset to use for training')
    parser.add_argument('--train-data', type=str, default=None,
                        help='Training dataset (for cross-dataset evaluation)')
    parser.add_argument('--test-data', type=str, default=None,
                        help='Test dataset (for cross-dataset evaluation)')
    parser.add_argument('--val-split', type=float, default=0.15,
                        help='Validation split ratio')
    
    # Preprocessing arguments
    parser.add_argument('--max-vocab-size', type=int, default=10000,
                        help='Maximum vocabulary size')
    parser.add_argument('--min-word-freq', type=int, default=2,
                        help='Minimum word frequency for vocabulary')
    parser.add_argument('--max-length', type=int, default=200,
                        help='Maximum sequence length')
    
    # Model hyperparameters
    parser.add_argument('--embedding-dim', type=int, default=128,
                        help='Word embedding dimension')
    parser.add_argument('--hidden-dims', type=int, nargs='+', default=[256, 128],
                        help='Hidden layer dimensions')
    parser.add_argument('--dropout', type=float, default=0.3,
                        help='Dropout rate')
    
    # Training arguments
    parser.add_argument('--batch-size', type=int, default=32,
                        help='Batch size for training')
    parser.add_argument('--epochs', type=int, default=20,
                        help='Number of training epochs')
    parser.add_argument('--lr', type=float, default=0.001,
                        help='Learning rate')
    parser.add_argument('--patience', type=int, default=5,
                        help='Patience for early stopping')
    
    # Experiment arguments
    parser.add_argument('--config', type=str, default=None,
                        help='Path to config file')
    parser.add_argument('--seed', type=int, default=42,
                        help='Random seed for reproducibility')
    parser.add_argument('--device', type=str, default='cuda' if torch.cuda.is_available() else 'cpu',
                        help='Device to use for training')
    
    # Output arguments
    parser.add_argument('--output-dir', type=str, default='results',
                        help='Directory to save results')
    parser.add_argument('--checkpoint-dir', type=str, default='checkpoints',
                        help='Directory to save model checkpoints')
    parser.add_argument('--save-model', action='store_true',
                        help='Save trained model')
    
    return parser.parse_args()


def is_transformer_model(model_name):
    """Check if model is a transformer-based model."""
    return any(x in model_name for x in ['bert', 'biobert', 'pubmedbert'])


def prepare_data(args, logger):
    """Load and preprocess data."""
    # Load dataset
    logger.info(f"Loading dataset: {args.dataset}")
    if args.dataset == 'coaid':
        df = load_coaid_dataset(use_sample=False)
    else:
        df = load_healthfact_dataset(split='train', use_sample=False)

    logger.info(f"Loaded {len(df)} samples")
    logger.info(f"Label distribution: {df['label'].value_counts().to_dict()}")

    # Clean text
    logger.info("Cleaning text...")
    texts = [clean_text(text) for text in df['text'].tolist()]
    labels = df['label'].tolist()

    # Build vocabulary
    logger.info("Building vocabulary...")
    word_to_idx = build_vocabulary(
        texts,
        max_vocab_size=args.max_vocab_size,
        min_freq=args.min_word_freq
    )
    vocab_size = len(word_to_idx)
    logger.info(f"Vocabulary size: {vocab_size}")

    # Convert text to sequences
    logger.info("Converting text to sequences...")
    sequences = text_to_sequences(texts, word_to_idx)
    sequences = pad_sequences(sequences, max_length=args.max_length)

    # Extract features if using models with features
    features = None
    if 'features' in args.model:
        logger.info("Extracting sentiment and linguistic features...")
        sentiment_features = batch_extract_sentiment_features(texts)
        linguistic_features = batch_extract_linguistic_features(texts)
        features = np.hstack([sentiment_features, linguistic_features])
        logger.info(f"Feature shape: {features.shape}")

    return sequences, labels, features, vocab_size, word_to_idx, texts


def prepare_transformer_data(args, logger):
    """Load and preprocess data for transformer models with proper tokenization."""
    # Load dataset
    logger.info(f"Loading dataset: {args.dataset}")
    if args.dataset == 'coaid':
        df = load_coaid_dataset(use_sample=False)
    else:
        df = load_healthfact_dataset(split='train', use_sample=False)

    logger.info(f"Loaded {len(df)} samples")
    logger.info(f"Label distribution: {df['label'].value_counts().to_dict()}")

    # Clean text
    logger.info("Cleaning text...")
    texts = [clean_text(text) for text in df['text'].tolist()]
    labels = df['label'].tolist()

    # Get appropriate tokenizer for the model
    logger.info(f"Loading tokenizer for {args.model}...")
    tokenizer = get_transformer_tokenizer(args.model)

    # Tokenize texts with attention masks
    logger.info("Tokenizing texts with attention masks...")
    encodings = tokenizer(
        texts,
        truncation=True,
        padding='max_length',
        max_length=args.max_length,
        return_tensors='pt',
        return_attention_mask=True
    )
    
    logger.info(f"Tokenization complete. Input shape: {encodings['input_ids'].shape}")
    logger.info(f"Attention mask shape: {encodings['attention_mask'].shape}")

    # Extract features if using models with features
    features = None
    if 'features' in args.model:
        logger.info("Extracting sentiment and linguistic features...")
        sentiment_features = batch_extract_sentiment_features(texts)
        linguistic_features = batch_extract_linguistic_features(texts)
        features = np.hstack([sentiment_features, linguistic_features])
        logger.info(f"Feature shape: {features.shape}")

    return encodings, labels, features, texts
def create_data_loaders(sequences, labels, features, args):
    """Create train, validation, and test data loaders."""
    # Create dataset
    if features is not None:
        dataset = TextWithFeaturesDataset(sequences, features, labels)
    else:
        dataset = TextOnlyDataset(sequences, labels)

    # Split into train and validation
    val_size = int(args.val_split * len(dataset))
    train_size = len(dataset) - val_size
    train_dataset, val_dataset = random_split(dataset, [train_size, val_size])

    # Create data loaders
    train_loader = DataLoader(
        train_dataset,
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=0
    )
    val_loader = DataLoader(
        val_dataset,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=0
    )

    return train_loader, val_loader


def create_transformer_data_loaders(encodings, labels, features, args):
    """Create train, validation, and test data loaders for transformer models."""
    # Create dataset
    dataset = TransformerDataset(encodings, labels, features)

    # Split into train and validation
    val_size = int(args.val_split * len(dataset))
    train_size = len(dataset) - val_size
    train_dataset, val_dataset = random_split(dataset, [train_size, val_size])

    # Create data loaders
    train_loader = DataLoader(
        train_dataset,
        batch_size=args.batch_size,
        shuffle=True,
        num_workers=0
    )
    val_loader = DataLoader(
        val_dataset,
        batch_size=args.batch_size,
        shuffle=False,
        num_workers=0
    )

    return train_loader, val_loader
def create_model(args, vocab_size, feature_dim=None):
    """Create the model based on arguments."""
    # FFNN models
    if args.model == 'ffnn':
        model = FFNNClassifier(
            vocab_size=vocab_size,
            embedding_dim=args.embedding_dim,
            hidden_dims=args.hidden_dims,
            dropout=args.dropout
        )
    elif args.model == 'ffnn_features':
        model = FFNNWithFeatures(
            vocab_size=vocab_size,
            embedding_dim=args.embedding_dim,
            hidden_dims=args.hidden_dims,
            feature_dim=feature_dim,
            dropout=args.dropout
        )
    
    # TextCNN models
    elif args.model == 'textcnn':
        model = TextCNN(
            vocab_size=vocab_size,
            embedding_dim=args.embedding_dim,
            num_filters=100,
            filter_sizes=[3, 4, 5],
            dropout=args.dropout
        )
    elif args.model == 'textcnn_features':
        model = TextCNNWithFeatures(
            vocab_size=vocab_size,
            embedding_dim=args.embedding_dim,
            num_filters=100,
            filter_sizes=[3, 4, 5],
            feature_dim=feature_dim,
            dropout=args.dropout
        )
    
    # BiLSTM models
    elif args.model == 'bilstm':
        model = BiLSTMAttention(
            vocab_size=vocab_size,
            embedding_dim=args.embedding_dim,
            hidden_dim=args.hidden_dims[0] if args.hidden_dims else 128,
            num_layers=2,
            dropout=args.dropout
        )
    elif args.model == 'bilstm_features':
        model = BiLSTMAttentionWithFeatures(
            vocab_size=vocab_size,
            embedding_dim=args.embedding_dim,
            hidden_dim=args.hidden_dims[0] if args.hidden_dims else 128,
            num_layers=2,
            feature_dim=feature_dim,
            dropout=args.dropout
        )
    
    # BERT models
    elif args.model == 'bert':
        model = BERTClassifier(dropout=args.dropout)
    elif args.model == 'bert_features':
        model = BERTWithFeatures(feature_dim=feature_dim, dropout=args.dropout)
    
    # BioBERT models
    elif args.model == 'biobert':
        model = BioBERTClassifier(dropout=args.dropout)
    elif args.model == 'biobert_features':
        model = BioBERTWithFeatures(feature_dim=feature_dim, dropout=args.dropout)
    
    # PubMedBERT models
    elif args.model == 'pubmedbert':
        model = PubMedBERTClassifier(dropout=args.dropout)
    elif args.model == 'pubmedbert_features':
        model = PubMedBERTWithFeatures(feature_dim=feature_dim, dropout=args.dropout)
    
    else:
        raise NotImplementedError(f"Model {args.model} not yet implemented")
    
    return model


def main():
    # Parse arguments
    args = parse_args()
    
    # Setup logging
    logger = setup_logging()
    logger.info("="*80)
    logger.info("Health Misinformation Detection System")
    logger.info("="*80)
    logger.info(f"Model: {args.model}")
    logger.info(f"Dataset: {args.dataset}")
    logger.info(f"Device: {args.device}")
    
    # Set random seed
    set_seed(args.seed)
    logger.info(f"Random seed set to {args.seed}")
    
    # Create output directories
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    checkpoint_dir = Path(args.checkpoint_dir)
    checkpoint_dir.mkdir(parents=True, exist_ok=True)

    # Prepare data (different for transformer vs non-transformer models)
    if is_transformer_model(args.model):
        logger.info("Using transformer-specific data preparation with attention masks...")
        encodings, labels, features, texts = prepare_transformer_data(args, logger)
        train_loader, val_loader = create_transformer_data_loaders(encodings, labels, features, args)
        vocab_size = None  # Not used for transformers
    else:
        logger.info("Using standard data preparation...")
        sequences, labels, features, vocab_size, word_to_idx, texts = prepare_data(args, logger)
        train_loader, val_loader = create_data_loaders(sequences, labels, features, args)
    
    logger.info(f"Train batches: {len(train_loader)}, Val batches: {len(val_loader)}")

    # Create model
    feature_dim = features.shape[1] if features is not None else None
    model = create_model(args, vocab_size, feature_dim)
    logger.info(f"Model created with {model.count_parameters():,} parameters")
    
    # Setup training
    device = torch.device(args.device)
    
    # Use lower learning rate for transformer models
    if is_transformer_model(args.model) and args.lr == 0.001:
        # Override default LR for transformers
        effective_lr = 2e-5
        logger.info(f"Using transformer-optimized learning rate: {effective_lr}")
    else:
        effective_lr = args.lr
    
    optimizer = torch.optim.Adam(model.parameters(), lr=effective_lr)
    
    # Compute class weights to handle imbalance
    labels_array = np.array(labels)
    class_counts = np.bincount(labels_array)
    total_samples = len(labels_array)
    class_weights = total_samples / (len(class_counts) * class_counts)
    
    # For binary classification with BCEWithLogitsLoss, we need pos_weight
    # pos_weight is the ratio of negative to positive samples
    pos_weight = torch.tensor([class_weights[1] / class_weights[0]], device=device)
    logger.info(f"Class distribution: {dict(enumerate(class_counts))}")
    logger.info(f"Using pos_weight: {pos_weight.item():.4f} to handle class imbalance")
    
    criterion = nn.BCEWithLogitsLoss(pos_weight=pos_weight)
    
    # Setup callbacks
    callbacks = [
        EarlyStopping(monitor='val_loss', patience=args.patience, mode='min', verbose=True),
        ModelCheckpoint(
            filepath=str(checkpoint_dir / f"{args.model}_best.pt"),
            monitor='val_loss',
            save_best_only=True,
            mode='min',
            verbose=True
        ),
        MetricsLogger(log_dir=str(output_dir / 'logs'), use_tensorboard=True)
    ]
    
    # Create trainer
    trainer = Trainer(
        model=model,
        train_loader=train_loader,
        val_loader=val_loader,
        optimizer=optimizer,
        criterion=criterion,
        device=device,
        callbacks=callbacks,
        log_interval=10,
        checkpoint_dir=str(checkpoint_dir)
    )
    
    # Train model
    logger.info("Starting training...")
    history = trainer.train(num_epochs=args.epochs)
    
    # Plot training history
    logger.info("Plotting training history...")
    plot_training_history(
        history,
        save_path=str(output_dir / f"{args.model}_training_history.png"),
        show=False
    )
    
    # Evaluate on validation set
    logger.info("Evaluating on validation set...")
    val_metrics = evaluate_model(model, val_loader, device, return_predictions=True)
    
    # Print results
    logger.info("\n" + "="*80)
    logger.info("VALIDATION RESULTS")
    logger.info("="*80)
    for metric, value in val_metrics.items():
        if metric != 'predictions':
            logger.info(f"{metric}: {value:.4f}")
    
    # Print classification report
    preds_data = val_metrics['predictions']
    report = print_classification_report(preds_data['y_true'], preds_data['y_pred'])
    logger.info("\n" + report)
    
    # Create confusion matrix
    cm = get_confusion_matrix(preds_data['y_true'], preds_data['y_pred'])
    plot_confusion_matrix(
        cm,
        save_path=str(output_dir / f"{args.model}_confusion_matrix.png"),
        show=False,
        title=f'{args.model.upper()} - Confusion Matrix'
    )
    
    # Create evaluation report
    from src.evaluation.metrics import get_roc_curve_data, get_precision_recall_curve_data
    fpr, tpr, _ = get_roc_curve_data(preds_data['y_true'], preds_data['y_prob'])
    precision, recall, _ = get_precision_recall_curve_data(preds_data['y_true'], preds_data['y_prob'])
    
    create_evaluation_report(
        model_name=args.model,
        metrics=val_metrics,
        save_dir=str(output_dir),
        cm=cm,
        roc_data=(fpr, tpr, val_metrics['roc_auc']),
        pr_data=(precision, recall, val_metrics['avg_precision'])
    )
    
    logger.info(f"\nResults saved to {output_dir}")
    logger.info("Training complete!")


if __name__ == '__main__':
    main()
