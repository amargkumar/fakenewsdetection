"""
Run Flask app - this version ensures the server stays running
"""
import os
import sys
from pathlib import Path

# Change to project directory
project_dir = Path(__file__).parent
os.chdir(project_dir)

# Set environment variables for offline mode
os.environ['TRANSFORMERS_OFFLINE'] = '1'
os.environ['HF_DATASETS_OFFLINE'] = '1'

# Add to path
sys.path.insert(0, str(project_dir))

# Import and run
from web_app.app import app, init_model

if __name__ == '__main__':
    try:
        # Initialize model
        init_model()
        
        # Run Flask app - threaded=True allows concurrent requests
        print("\nStarting Flask server... Press CTRL+C to stop\n")
        app.run(
            debug=False,
            host='127.0.0.1',
            port=5000,
            threaded=True,
            use_reloader=False  # Disable reloader to avoid import issues
        )
    except KeyboardInterrupt:
        print("\n\nShutting down server...")
    except Exception as e:
        print(f"\nError: {e}")
        import traceback
        traceback.print_exc()
