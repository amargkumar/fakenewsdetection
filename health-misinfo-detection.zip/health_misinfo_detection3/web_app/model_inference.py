"""
Model inference module for health misinformation detection
Loads the trained BERT model and provides prediction functionality
"""

import torch
import numpy as np
from pathlib import Path
import sys

# Add parent directory to path to import project modules
sys.path.append(str(Path(__file__).parent.parent))

from src.models.transformer_models import BERTClassifier, get_transformer_tokenizer
from src.data.preprocessors import clean_text


class HealthMisinfoDetector:
    """Wrapper class for health misinformation detection"""
    
    def __init__(self, model_path, device='cpu'):
        """
        Initialize the detector with a trained model.
        
        Args:
            model_path: Path to the saved model checkpoint (.pt file)
            device: Device to run inference on ('cpu' or 'cuda')
        """
        self.device = torch.device(device)
        self.model_path = Path(model_path)
        
        # Initialize model
        print(f"Loading BERT model from {self.model_path}...")
        self.model = BERTClassifier(dropout=0.3)
        
        # Load checkpoint
        checkpoint = torch.load(self.model_path, map_location=self.device)
        self.model.load_state_dict(checkpoint['model_state_dict'])
        self.model.to(self.device)
        self.model.eval()
        
        # Load tokenizer
        self.tokenizer = get_transformer_tokenizer('bert')
        
        print("✓ Model loaded successfully!")
        print(f"  - Parameters: {self.model.count_parameters():,}")
        print(f"  - Device: {self.device}")
    
    def predict(self, text, max_length=200):
        """
        Predict whether a health article/claim is real or fake.
        
        Args:
            text: The health article or claim to analyze
            max_length: Maximum sequence length for tokenization
            
        Returns:
            dict with:
                - prediction: 'Real' or 'Fake'
                - confidence: Confidence score (0-100%)
                - probabilities: Dict with probabilities for each class
        """
        # Clean text
        cleaned_text = clean_text(text)
        
        # Tokenize
        encoding = self.tokenizer(
            cleaned_text,
            truncation=True,
            padding='max_length',
            max_length=max_length,
            return_tensors='pt',
            return_attention_mask=True
        )
        
        # Move to device
        input_ids = encoding['input_ids'].to(self.device)
        attention_mask = encoding['attention_mask'].to(self.device)
        
        # Get prediction
        with torch.no_grad():
            outputs = self.model(input_ids=input_ids, attention_mask=attention_mask)
            probabilities = torch.sigmoid(outputs)
            prediction = (probabilities > 0.5).long()
        
        # Extract values
        prob_fake = (1 - probabilities[0].item()) * 100  # Class 0 = Fake
        prob_real = probabilities[0].item() * 100         # Class 1 = Real
        predicted_class = prediction[0].item()
        
        # Determine label and confidence
        if predicted_class == 1:
            label = "Real"
            confidence = prob_real
        else:
            label = "Fake"
            confidence = prob_fake
        
        return {
            'prediction': label,
            'confidence': confidence,
            'probabilities': {
                'Real': prob_real,
                'Fake': prob_fake
            },
            'raw_output': probabilities[0].item()
        }
    
    def predict_batch(self, texts, max_length=200):
        """
        Predict multiple texts at once.
        
        Args:
            texts: List of health articles/claims
            max_length: Maximum sequence length
            
        Returns:
            List of prediction dictionaries
        """
        return [self.predict(text, max_length) for text in texts]


def get_example_texts():
    """Get example texts for testing (from actual CoAID dataset)"""
    return {
        'fake_covid': "Video from China shows people fleeing from coronavirus quarantine.",
        'real_covid': "COVID-19: GMC Invites More Doctors Back to Work",
        'fake_vaccine': "India is suing Microsoft founder Bill Gates because of his vaccine against coronavirus that killed 77,000 girls.",
        'real_vaccine': "Experts draw attention to the 'hidden sorrows' of COVID-19 and Parkinson's",
        'fake_health': "Alkaline diet protects against the coronavirus.",
        'real_health': "WHO statement on cases of COVID-19 surpassing 100 000"
    }


if __name__ == '__main__':
    # Test the detector
    model_path = Path(__file__).parent.parent / 'checkpoints' / 'bert_best.pt'
    
    if not model_path.exists():
        print(f"Error: Model file not found at {model_path}")
        print("Please train a BERT model first using main.py")
        sys.exit(1)
    
    # Initialize detector
    detector = HealthMisinfoDetector(model_path)
    
    # Test with examples
    print("\n" + "="*80)
    print("Testing Health Misinformation Detector")
    print("="*80)
    
    examples = get_example_texts()
    
    for name, text in examples.items():
        print(f"\n[{name}]")
        print(f"Text: {text[:100]}...")
        
        result = detector.predict(text)
        
        print(f"Prediction: {result['prediction']}")
        print(f"Confidence: {result['confidence']:.2f}%")
        print(f"Probabilities: Real={result['probabilities']['Real']:.2f}%, Fake={result['probabilities']['Fake']:.2f}%")
