"""
Flask Web Application for Health Misinformation Detection
Simple web interface for testing the BERT model
"""

from flask import Flask, render_template, request, jsonify
from pathlib import Path
import sys

# Add parent directory to path
sys.path.append(str(Path(__file__).parent.parent))

from web_app.model_inference import HealthMisinfoDetector, get_example_texts

app = Flask(__name__)

# Initialize model (load once at startup)
MODEL_PATH = Path(__file__).parent.parent / 'checkpoints' / 'bert_best.pt'
detector = None

def init_model():
    """Initialize the model at app startup"""
    global detector
    try:
        print("\n" + "="*80)
        print("Initializing Health Misinformation Detection App")
        print("="*80)
        detector = HealthMisinfoDetector(MODEL_PATH)
        print("="*80)
        print("✓ App ready! Open http://127.0.0.1:5000 in your browser")
        print("="*80 + "\n")
    except Exception as e:
        print(f"Error loading model: {e}")
        print(f"Make sure the model exists at: {MODEL_PATH}")
        sys.exit(1)


@app.route('/')
def index():
    """Render the main page"""
    examples = get_example_texts()
    return render_template('index.html', examples=examples)


@app.route('/predict', methods=['POST'])
def predict():
    """Handle prediction requests"""
    try:
        # Get text from request
        data = request.get_json()
        text = data.get('text', '').strip()
        
        # Validate input
        if not text:
            return jsonify({
                'error': 'Please enter some text to analyze'
            }), 400
        
        if len(text) < 10:
            return jsonify({
                'error': 'Text is too short. Please enter at least 10 characters.'
            }), 400
        
        # Get prediction
        result = detector.predict(text)
        
        # Return result
        return jsonify({
            'success': True,
            'prediction': result['prediction'],
            'confidence': round(result['confidence'], 2),
            'probabilities': {
                'Real': round(result['probabilities']['Real'], 2),
                'Fake': round(result['probabilities']['Fake'], 2)
            }
        })
    
    except Exception as e:
        return jsonify({
            'error': f'An error occurred: {str(e)}'
        }), 500


@app.route('/health')
def health():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'model_loaded': detector is not None
    })


if __name__ == '__main__':
    init_model()
    app.run(debug=True, host='127.0.0.1', port=5000)
