"""
Simple script to run the Flask web app
Usage: python run.py
"""

import sys
import os
from pathlib import Path

# Set HuggingFace to offline mode to use cached models
os.environ['TRANSFORMERS_OFFLINE'] = '1'
os.environ['HF_DATASETS_OFFLINE'] = '1'

# Add parent directory to path
sys.path.append(str(Path(__file__).parent.parent))

from web_app.app import app, init_model

if __name__ == '__main__':
    # Initialize model
    init_model()
    
    # Run Flask app (debug=False to avoid reloader issues with large imports)
    app.run(debug=False, host='127.0.0.1', port=5000)
