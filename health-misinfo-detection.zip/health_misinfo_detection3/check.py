import sys
import torch
import transformers
import os

print("=" * 50)
print("ENVIRONMENT DIAGNOSTIC")
print("=" * 50)

print(f"\nPython executable: {sys.executable}")
print(f"Python version: {sys.version}")
print(f"Python prefix: {sys.prefix}")

print(f"\nIn virtual env: {hasattr(sys, 'real_prefix') or (hasattr(sys, 'base_prefix') and sys.base_prefix != sys.prefix)}")

print(f"\nVIRTUAL_ENV: {os.environ.get('VIRTUAL_ENV', 'Not set')}")

print(f"\nPyTorch version: {torch.__version__}")
print(f"PyTorch location: {torch.__file__}")

print(f"\nTransformers version: {transformers.__version__}")
print(f"Transformers location: {transformers.__file__}")

print(f"\nCUDA available: {torch.cuda.is_available()}")
print(f"MPS available (Mac): {torch.backends.mps.is_available() if hasattr(torch.backends, 'mps') else 'N/A'}")

print("\n" + "=" * 50)