"""
Pre-trained word embeddings management
"""
import numpy as np
from pathlib import Path
from typing import Dict, Optional
import torch
import torch.nn as nn


def load_glove_embeddings(glove_path: str, vocab: Dict[str, int], 
                          embedding_dim: int = 300) -> np.ndarray:
    """
    Loads GloVe 300d vectors into embedding matrix
    
    Args:
        glove_path: Path to GloVe file (e.g., glove.6B.300d.txt)
        vocab: Word to index mapping
        embedding_dim: Embedding dimension
        
    Returns:
        NumPy array of shape (vocab_size, embedding_dim)
    """
    embeddings = np.random.randn(len(vocab), embedding_dim) * 0.01
    
    if not Path(glove_path).exists():
        print(f"Warning: GloVe file not found at {glove_path}. Using random embeddings.")
        return embeddings
    
    found = 0
    with open(glove_path, 'r', encoding='utf-8') as f:
        for line in f:
            parts = line.strip().split()
            word = parts[0]
            
            if word in vocab:
                vector = np.array([float(x) for x in parts[1:]])
                embeddings[vocab[word]] = vector
                found += 1
    
    print(f"Loaded {found}/{len(vocab)} word vectors from GloVe")
    
    return embeddings


def load_word2vec_embeddings(w2v_path: str, vocab: Dict[str, int],
                             embedding_dim: int = 300) -> np.ndarray:
    """
    Loads Word2Vec vectors
    
    Args:
        w2v_path: Path to Word2Vec file
        vocab: Word to index mapping
        embedding_dim: Embedding dimension
        
    Returns:
        NumPy array of shape (vocab_size, embedding_dim)
    """
    # Similar implementation to GloVe
    # Can use gensim.models.KeyedVectors.load_word2vec_format()
    embeddings = np.random.randn(len(vocab), embedding_dim) * 0.01
    
    print(f"Word2Vec loader not fully implemented. Using random embeddings.")
    
    return embeddings


def create_embedding_matrix(vocab: Dict[str, int], embedding_path: Optional[str] = None,
                           embedding_dim: int = 300, embedding_type: str = 'glove') -> np.ndarray:
    """
    Creates embedding matrix from vocabulary
    
    Args:
        vocab: Word to index mapping
        embedding_path: Path to pre-trained embeddings
        embedding_dim: Embedding dimension
        embedding_type: Type of embeddings ('glove' or 'word2vec')
        
    Returns:
        NumPy array of embeddings
    """
    if embedding_path is None:
        # Random embeddings
        embeddings = np.random.randn(len(vocab), embedding_dim) * 0.01
    elif embedding_type == 'glove':
        embeddings = load_glove_embeddings(embedding_path, vocab, embedding_dim)
    elif embedding_type == 'word2vec':
        embeddings = load_word2vec_embeddings(embedding_path, vocab, embedding_dim)
    else:
        raise ValueError(f"Unknown embedding type: {embedding_type}")
    
    return embeddings


def create_embedding_layer(embedding_matrix: np.ndarray, trainable: bool = False) -> nn.Embedding:
    """
    Creates PyTorch embedding layer from pre-trained matrix
    
    Args:
        embedding_matrix: Pre-trained embeddings
        trainable: Whether to fine-tune embeddings
        
    Returns:
        PyTorch Embedding layer
    """
    vocab_size, embedding_dim = embedding_matrix.shape
    
    embedding_layer = nn.Embedding(vocab_size, embedding_dim)
    embedding_layer.weight = nn.Parameter(torch.tensor(embedding_matrix, dtype=torch.float32))
    embedding_layer.weight.requires_grad = trainable
    
    return embedding_layer
