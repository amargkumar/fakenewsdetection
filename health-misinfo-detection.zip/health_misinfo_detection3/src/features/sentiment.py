"""
Sentiment and emotional feature extraction
"""
from typing import List, Dict
import numpy as np

try:
    from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
    VADER_AVAILABLE = True
except ImportError:
    VADER_AVAILABLE = False

try:
    from textblob import TextBlob
    TEXTBLOB_AVAILABLE = True
except ImportError:
    TEXTBLOB_AVAILABLE = False


def compute_vader_sentiment(text: str) -> Dict[str, float]:
    """
    Returns polarity scores (pos, neg, neu, compound)
    
    Args:
        text: Input text string
        
    Returns:
        Dictionary with sentiment scores
    """
    if not VADER_AVAILABLE:
        return {'pos': 0.0, 'neg': 0.0, 'neu': 1.0, 'compound': 0.0}
    
    analyzer = SentimentIntensityAnalyzer()
    scores = analyzer.polarity_scores(text)
    
    return scores


def compute_textblob_sentiment(text: str) -> Dict[str, float]:
    """
    Returns polarity and subjectivity
    
    Args:
        text: Input text string
        
    Returns:
        Dictionary with polarity and subjectivity scores
    """
    if not TEXTBLOB_AVAILABLE:
        return {'polarity': 0.0, 'subjectivity': 0.0}
    
    blob = TextBlob(text)
    
    return {
        'polarity': blob.sentiment.polarity,
        'subjectivity': blob.sentiment.subjectivity
    }


def extract_emotion_lexicon(text: str) -> int:
    """
    Counts fear/anger words from emotion lexicons
    
    Args:
        text: Input text string
        
    Returns:
        Count of emotion words
    """
    # Simple emotion word lists (can be expanded with NRC Emotion Lexicon)
    fear_words = {'afraid', 'scared', 'fear', 'terror', 'panic', 'anxiety', 'worried', 'frightened'}
    anger_words = {'angry', 'rage', 'furious', 'mad', 'outraged', 'irritated', 'annoyed'}
    
    emotion_words = fear_words | anger_words
    
    tokens = text.lower().split()
    count = sum(1 for token in tokens if token in emotion_words)
    
    return count


def extract_sentiment_features(text: str) -> np.ndarray:
    """
    Extracts all sentiment features as a vector
    
    Output: 6-dimensional vector [compound, polarity, subjectivity, pos, neg, emotion_count]
    
    Args:
        text: Input text string
        
    Returns:
        NumPy array of sentiment features
    """
    vader_scores = compute_vader_sentiment(text)
    textblob_scores = compute_textblob_sentiment(text)
    emotion_count = extract_emotion_lexicon(text)
    
    features = np.array([
        vader_scores['compound'],
        textblob_scores['polarity'],
        textblob_scores['subjectivity'],
        vader_scores['pos'],
        vader_scores['neg'],
        emotion_count
    ], dtype=np.float32)
    
    return features


def batch_extract_sentiment_features(texts: List[str]) -> np.ndarray:
    """
    Extract sentiment features for a batch of texts
    
    Args:
        texts: List of text strings
        
    Returns:
        NumPy array of shape (n_texts, 6)
    """
    features = [extract_sentiment_features(text) for text in texts]
    return np.array(features)
