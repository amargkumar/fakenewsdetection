"""Features module initialization"""
