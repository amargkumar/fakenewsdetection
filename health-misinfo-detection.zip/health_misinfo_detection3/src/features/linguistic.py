"""
Linguistic and stylistic feature extraction
"""
import re
from typing import List
import numpy as np


def compute_basic_stats(text: str) -> dict:
    """
    Word count, sentence count, avg word length
    
    Args:
        text: Input text string
        
    Returns:
        Dictionary with basic statistics
    """
    words = text.split()
    word_count = len(words)
    
    # Sentence count (simple heuristic)
    sentences = re.split(r'[.!?]+', text)
    sentence_count = len([s for s in sentences if s.strip()])
    
    # Average word length
    avg_word_length = sum(len(word) for word in words) / max(word_count, 1)
    
    return {
        'word_count': word_count,
        'sentence_count': sentence_count,
        'avg_word_length': avg_word_length
    }


def compute_stylistic_features(text: str) -> dict:
    """
    Exclamation/question marks, ALL CAPS ratio
    
    Args:
        text: Input text string
        
    Returns:
        Dictionary with stylistic features
    """
    exclamation_count = text.count('!')
    question_count = text.count('?')
    
    # ALL CAPS ratio
    words = text.split()
    caps_count = sum(1 for word in words if word.isupper() and len(word) > 1)
    caps_ratio = caps_count / max(len(words), 1)
    
    return {
        'exclamation_count': exclamation_count,
        'question_count': question_count,
        'caps_ratio': caps_ratio
    }


def compute_readability_score(text: str) -> float:
    """
    Flesch Reading Ease score
    
    Args:
        text: Input text string
        
    Returns:
        Readability score
    """
    words = text.split()
    sentences = re.split(r'[.!?]+', text)
    sentences = [s for s in sentences if s.strip()]
    
    # Count syllables (simple heuristic)
    def count_syllables(word):
        word = word.lower()
        vowels = 'aeiou'
        syllable_count = 0
        previous_was_vowel = False
        
        for char in word:
            is_vowel = char in vowels
            if is_vowel and not previous_was_vowel:
                syllable_count += 1
            previous_was_vowel = is_vowel
        
        # Adjust for silent e
        if word.endswith('e'):
            syllable_count -= 1
        
        return max(syllable_count, 1)
    
    total_syllables = sum(count_syllables(word) for word in words)
    
    # Flesch Reading Ease formula
    if len(words) > 0 and len(sentences) > 0:
        score = 206.835 - 1.015 * (len(words) / len(sentences)) - 84.6 * (total_syllables / len(words))
    else:
        score = 0.0
    
    return score


def compute_jargon_density(text: str) -> float:
    """
    Ratio of medical/scientific terms using domain dictionary
    
    Args:
        text: Input text string
        
    Returns:
        Jargon density ratio
    """
    # Medical/scientific terms (can be expanded with a comprehensive dictionary)
    medical_terms = {
        'vaccine', 'symptom', 'treatment', 'diagnosis', 'patient', 'clinical',
        'therapy', 'medication', 'disease', 'virus', 'infection', 'antibody',
        'pandemic', 'epidemic', 'immune', 'covid', 'coronavirus', 'sars',
        'respiratory', 'pneumonia', 'efficacy', 'trial', 'study', 'research'
    }
    
    words = text.lower().split()
    jargon_count = sum(1 for word in words if word in medical_terms)
    jargon_ratio = jargon_count / max(len(words), 1)
    
    return jargon_ratio


def count_hedging_words(text: str) -> int:
    """
    Frequency of uncertainty markers (may, could, suggest)
    
    Args:
        text: Input text string
        
    Returns:
        Count of hedging words
    """
    hedging_words = {
        'may', 'might', 'could', 'possibly', 'probably', 'perhaps',
        'suggest', 'suggests', 'indicated', 'appears', 'seems',
        'likely', 'unlikely', 'potential', 'potentially'
    }
    
    words = text.lower().split()
    count = sum(1 for word in words if word in hedging_words)
    
    return count


def detect_clickbait_patterns(text: str) -> int:
    """
    Matches against clickbait phrase patterns
    
    Args:
        text: Input text string
        
    Returns:
        Count of clickbait patterns
    """
    clickbait_patterns = [
        r'you won\'t believe',
        r'shocking',
        r'this one trick',
        r'doctors hate',
        r'what happened next',
        r'the truth about',
        r'they don\'t want you to know',
        r'number \d+ will shock you'
    ]
    
    count = 0
    text_lower = text.lower()
    
    for pattern in clickbait_patterns:
        if re.search(pattern, text_lower):
            count += 1
    
    return count


def extract_linguistic_features(text: str) -> np.ndarray:
    """
    Extracts all linguistic features as a vector
    
    Output: 10-dimensional vector combining all linguistic features
    
    Args:
        text: Input text string
        
    Returns:
        NumPy array of linguistic features
    """
    basic_stats = compute_basic_stats(text)
    stylistic = compute_stylistic_features(text)
    readability = compute_readability_score(text)
    jargon = compute_jargon_density(text)
    hedging = count_hedging_words(text)
    clickbait = detect_clickbait_patterns(text)
    
    features = np.array([
        basic_stats['word_count'],
        basic_stats['sentence_count'],
        basic_stats['avg_word_length'],
        stylistic['exclamation_count'],
        stylistic['question_count'],
        stylistic['caps_ratio'],
        readability,
        jargon,
        hedging,
        clickbait
    ], dtype=np.float32)
    
    return features


def batch_extract_linguistic_features(texts: List[str]) -> np.ndarray:
    """
    Extract linguistic features for a batch of texts
    
    Args:
        texts: List of text strings
        
    Returns:
        NumPy array of shape (n_texts, 10)
    """
    features = [extract_linguistic_features(text) for text in texts]
    return np.array(features)
