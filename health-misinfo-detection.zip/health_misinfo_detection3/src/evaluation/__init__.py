"""Evaluation module initialization"""
