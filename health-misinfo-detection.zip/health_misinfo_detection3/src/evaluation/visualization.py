"""
Visualization utilities for training and evaluation.
Includes plots for training curves, confusion matrices, ROC curves, etc.
"""

import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
from pathlib import Path
from typing import Dict, List, Optional, Tuple
import logging

logger = logging.getLogger(__name__)

# Set style
sns.set_style("whitegrid")
plt.rcParams['figure.figsize'] = (10, 6)


def plot_training_history(
    history: Dict[str, List[float]],
    save_path: Optional[str] = None,
    show: bool = True
):
    """
    Plot training and validation loss/accuracy curves.
    
    Args:
        history: Dictionary with 'train_loss', 'val_loss', 'train_acc', 'val_acc'
        save_path: Path to save the plot (optional)
        show: Whether to display the plot
    """
    fig, axes = plt.subplots(1, 2, figsize=(15, 5))
    
    epochs = range(1, len(history['train_loss']) + 1)
    
    # Plot loss
    axes[0].plot(epochs, history['train_loss'], 'b-', label='Training Loss', linewidth=2)
    if 'val_loss' in history and history['val_loss']:
        axes[0].plot(epochs, history['val_loss'], 'r-', label='Validation Loss', linewidth=2)
    axes[0].set_xlabel('Epoch', fontsize=12)
    axes[0].set_ylabel('Loss', fontsize=12)
    axes[0].set_title('Training and Validation Loss', fontsize=14, fontweight='bold')
    axes[0].legend(fontsize=10)
    axes[0].grid(True, alpha=0.3)
    
    # Plot accuracy
    axes[1].plot(epochs, history['train_acc'], 'b-', label='Training Accuracy', linewidth=2)
    if 'val_acc' in history and history['val_acc']:
        axes[1].plot(epochs, history['val_acc'], 'r-', label='Validation Accuracy', linewidth=2)
    axes[1].set_xlabel('Epoch', fontsize=12)
    axes[1].set_ylabel('Accuracy (%)', fontsize=12)
    axes[1].set_title('Training and Validation Accuracy', fontsize=14, fontweight='bold')
    axes[1].legend(fontsize=10)
    axes[1].grid(True, alpha=0.3)
    
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        logger.info(f"Training history plot saved to {save_path}")
    
    if show:
        plt.show()
    else:
        plt.close()


def plot_confusion_matrix(
    cm: np.ndarray,
    class_names: Optional[List[str]] = None,
    normalize: bool = False,
    save_path: Optional[str] = None,
    show: bool = True,
    title: str = 'Confusion Matrix'
):
    """
    Plot confusion matrix as a heatmap.
    
    Args:
        cm: Confusion matrix
        class_names: Names of classes
        normalize: Whether to normalize the matrix
        save_path: Path to save the plot (optional)
        show: Whether to display the plot
        title: Plot title
    """
    if class_names is None:
        class_names = ['Fake/False', 'Real/True']
    
    if normalize:
        cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
        fmt = '.2%'
    else:
        fmt = 'd'
    
    plt.figure(figsize=(8, 6))
    sns.heatmap(
        cm,
        annot=True,
        fmt=fmt,
        cmap='Blues',
        xticklabels=class_names,
        yticklabels=class_names,
        cbar_kws={'label': 'Count' if not normalize else 'Proportion'}
    )
    
    plt.ylabel('True Label', fontsize=12)
    plt.xlabel('Predicted Label', fontsize=12)
    plt.title(title, fontsize=14, fontweight='bold')
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        logger.info(f"Confusion matrix plot saved to {save_path}")
    
    if show:
        plt.show()
    else:
        plt.close()


def plot_roc_curve(
    fpr: np.ndarray,
    tpr: np.ndarray,
    roc_auc: float,
    save_path: Optional[str] = None,
    show: bool = True,
    title: str = 'ROC Curve'
):
    """
    Plot ROC curve.
    
    Args:
        fpr: False positive rate
        tpr: True positive rate
        roc_auc: ROC-AUC score
        save_path: Path to save the plot (optional)
        show: Whether to display the plot
        title: Plot title
    """
    plt.figure(figsize=(8, 6))
    plt.plot(fpr, tpr, 'b-', linewidth=2, label=f'ROC Curve (AUC = {roc_auc:.4f})')
    plt.plot([0, 1], [0, 1], 'r--', linewidth=2, label='Random Classifier')
    
    plt.xlabel('False Positive Rate', fontsize=12)
    plt.ylabel('True Positive Rate', fontsize=12)
    plt.title(title, fontsize=14, fontweight='bold')
    plt.legend(fontsize=10)
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        logger.info(f"ROC curve plot saved to {save_path}")
    
    if show:
        plt.show()
    else:
        plt.close()


def plot_precision_recall_curve(
    precision: np.ndarray,
    recall: np.ndarray,
    avg_precision: float,
    save_path: Optional[str] = None,
    show: bool = True,
    title: str = 'Precision-Recall Curve'
):
    """
    Plot precision-recall curve.
    
    Args:
        precision: Precision values
        recall: Recall values
        avg_precision: Average precision score
        save_path: Path to save the plot (optional)
        show: Whether to display the plot
        title: Plot title
    """
    plt.figure(figsize=(8, 6))
    plt.plot(recall, precision, 'b-', linewidth=2, label=f'PR Curve (AP = {avg_precision:.4f})')
    
    plt.xlabel('Recall', fontsize=12)
    plt.ylabel('Precision', fontsize=12)
    plt.title(title, fontsize=14, fontweight='bold')
    plt.legend(fontsize=10)
    plt.grid(True, alpha=0.3)
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        logger.info(f"Precision-Recall curve plot saved to {save_path}")
    
    if show:
        plt.show()
    else:
        plt.close()


def plot_model_comparison(
    results: Dict[str, Dict[str, float]],
    metrics: Optional[List[str]] = None,
    save_path: Optional[str] = None,
    show: bool = True,
    title: str = 'Model Comparison'
):
    """
    Plot comparison of multiple models.
    
    Args:
        results: Dictionary mapping model names to their metrics
        metrics: List of metrics to plot
        save_path: Path to save the plot (optional)
        show: Whether to display the plot
        title: Plot title
    """
    if metrics is None:
        metrics = ['accuracy', 'precision', 'recall', 'f1']
    
    # Prepare data
    model_names = list(results.keys())
    num_metrics = len(metrics)
    num_models = len(model_names)
    
    # Create grouped bar chart
    fig, ax = plt.subplots(figsize=(12, 6))
    
    x = np.arange(num_metrics)
    width = 0.8 / num_models
    
    for i, model_name in enumerate(model_names):
        values = [results[model_name].get(metric, 0.0) for metric in metrics]
        offset = (i - num_models / 2) * width + width / 2
        ax.bar(x + offset, values, width, label=model_name)
    
    ax.set_xlabel('Metrics', fontsize=12)
    ax.set_ylabel('Score', fontsize=12)
    ax.set_title(title, fontsize=14, fontweight='bold')
    ax.set_xticks(x)
    ax.set_xticklabels([m.replace('_', ' ').title() for m in metrics])
    ax.legend(fontsize=10)
    ax.grid(True, alpha=0.3, axis='y')
    ax.set_ylim([0, 1.0])
    
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        logger.info(f"Model comparison plot saved to {save_path}")
    
    if show:
        plt.show()
    else:
        plt.close()


def plot_cross_dataset_heatmap(
    results: Dict[str, Dict[str, float]],
    metric: str = 'f1',
    save_path: Optional[str] = None,
    show: bool = True,
    title: str = 'Cross-Dataset Performance'
):
    """
    Plot heatmap of cross-dataset evaluation results.
    
    Args:
        results: Dictionary with keys like 'coaid_to_coaid', 'coaid_to_healthfact'
        metric: Metric to display
        save_path: Path to save the plot (optional)
        show: Whether to display the plot
        title: Plot title
    """
    # Extract dataset names
    datasets = set()
    for key in results.keys():
        if '_to_' in key:
            source, target = key.split('_to_')
            datasets.add(source)
            datasets.add(target)
    
    datasets = sorted(list(datasets))
    
    # Build matrix
    matrix = np.zeros((len(datasets), len(datasets)))
    for i, source in enumerate(datasets):
        for j, target in enumerate(datasets):
            key = f"{source}_to_{target}"
            if key in results:
                matrix[i, j] = results[key].get(metric, 0.0)
    
    # Plot heatmap
    plt.figure(figsize=(10, 8))
    sns.heatmap(
        matrix,
        annot=True,
        fmt='.3f',
        cmap='RdYlGn',
        xticklabels=[d.upper() for d in datasets],
        yticklabels=[d.upper() for d in datasets],
        vmin=0,
        vmax=1,
        cbar_kws={'label': metric.replace('_', ' ').title()}
    )
    
    plt.ylabel('Training Dataset', fontsize=12)
    plt.xlabel('Testing Dataset', fontsize=12)
    plt.title(f'{title} ({metric.replace("_", " ").title()})', fontsize=14, fontweight='bold')
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        logger.info(f"Cross-dataset heatmap saved to {save_path}")
    
    if show:
        plt.show()
    else:
        plt.close()


def plot_feature_importance(
    feature_names: List[str],
    importance_scores: np.ndarray,
    top_n: int = 20,
    save_path: Optional[str] = None,
    show: bool = True,
    title: str = 'Feature Importance'
):
    """
    Plot feature importance scores.
    
    Args:
        feature_names: Names of features
        importance_scores: Importance scores for each feature
        top_n: Number of top features to display
        save_path: Path to save the plot (optional)
        show: Whether to display the plot
        title: Plot title
    """
    # Sort by importance
    indices = np.argsort(importance_scores)[::-1][:top_n]
    top_features = [feature_names[i] for i in indices]
    top_scores = importance_scores[indices]
    
    # Plot
    plt.figure(figsize=(10, 8))
    plt.barh(range(len(top_features)), top_scores, color='steelblue')
    plt.yticks(range(len(top_features)), top_features)
    plt.xlabel('Importance Score', fontsize=12)
    plt.ylabel('Feature', fontsize=12)
    plt.title(title, fontsize=14, fontweight='bold')
    plt.gca().invert_yaxis()
    plt.grid(True, alpha=0.3, axis='x')
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=300, bbox_inches='tight')
        logger.info(f"Feature importance plot saved to {save_path}")
    
    if show:
        plt.show()
    else:
        plt.close()


def create_evaluation_report(
    model_name: str,
    metrics: Dict[str, float],
    save_dir: str,
    cm: Optional[np.ndarray] = None,
    roc_data: Optional[Tuple[np.ndarray, np.ndarray, float]] = None,
    pr_data: Optional[Tuple[np.ndarray, np.ndarray, float]] = None
):
    """
    Create a comprehensive evaluation report with all visualizations.
    
    Args:
        model_name: Name of the model
        metrics: Dictionary of evaluation metrics
        save_dir: Directory to save plots
        cm: Confusion matrix (optional)
        roc_data: Tuple of (fpr, tpr, roc_auc) for ROC curve
        pr_data: Tuple of (precision, recall, avg_precision) for PR curve
    """
    save_dir = Path(save_dir)
    save_dir.mkdir(parents=True, exist_ok=True)
    
    logger.info(f"Creating evaluation report for {model_name}")
    
    # Plot confusion matrix
    if cm is not None:
        plot_confusion_matrix(
            cm,
            save_path=str(save_dir / f"{model_name}_confusion_matrix.png"),
            show=False,
            title=f'{model_name} - Confusion Matrix'
        )
    
    # Plot ROC curve
    if roc_data is not None:
        fpr, tpr, roc_auc = roc_data
        plot_roc_curve(
            fpr,
            tpr,
            roc_auc,
            save_path=str(save_dir / f"{model_name}_roc_curve.png"),
            show=False,
            title=f'{model_name} - ROC Curve'
        )
    
    # Plot PR curve
    if pr_data is not None:
        precision, recall, avg_precision = pr_data
        plot_precision_recall_curve(
            precision,
            recall,
            avg_precision,
            save_path=str(save_dir / f"{model_name}_pr_curve.png"),
            show=False,
            title=f'{model_name} - Precision-Recall Curve'
        )
    
    logger.info(f"Evaluation report saved to {save_dir}")
