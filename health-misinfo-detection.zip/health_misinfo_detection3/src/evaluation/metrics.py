"""
Evaluation metrics for health misinformation detection.
Includes accuracy, precision, recall, F1, ROC-AUC, and confusion matrix.
"""

import torch
import numpy as np
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    confusion_matrix,
    classification_report,
    roc_curve,
    precision_recall_curve,
    average_precision_score
)
from typing import Dict, Tuple, List, Optional
import logging

logger = logging.getLogger(__name__)


def compute_metrics(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    y_prob: Optional[np.ndarray] = None,
    average: str = 'binary'
) -> Dict[str, float]:
    """
    Compute comprehensive evaluation metrics.
    
    Args:
        y_true: True labels (0 or 1)
        y_pred: Predicted labels (0 or 1)
        y_prob: Predicted probabilities (optional, for ROC-AUC)
        average: Averaging method ('binary', 'macro', 'weighted')
    
    Returns:
        Dictionary with all metrics
    """
    metrics = {}
    
    # Basic metrics
    metrics['accuracy'] = accuracy_score(y_true, y_pred)
    metrics['precision'] = precision_score(y_true, y_pred, average=average, zero_division=0)
    metrics['recall'] = recall_score(y_true, y_pred, average=average, zero_division=0)
    metrics['f1'] = f1_score(y_true, y_pred, average=average, zero_division=0)
    
    # ROC-AUC (requires probabilities)
    if y_prob is not None:
        try:
            metrics['roc_auc'] = roc_auc_score(y_true, y_prob)
            metrics['avg_precision'] = average_precision_score(y_true, y_prob)
        except ValueError as e:
            logger.warning(f"Could not compute ROC-AUC: {e}")
            metrics['roc_auc'] = 0.0
            metrics['avg_precision'] = 0.0
    
    # Confusion matrix components
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred).ravel()
    metrics['true_positives'] = int(tp)
    metrics['true_negatives'] = int(tn)
    metrics['false_positives'] = int(fp)
    metrics['false_negatives'] = int(fn)
    
    # Specificity and sensitivity
    metrics['specificity'] = tn / (tn + fp) if (tn + fp) > 0 else 0.0
    metrics['sensitivity'] = tp / (tp + fn) if (tp + fn) > 0 else 0.0  # Same as recall
    
    return metrics


def evaluate_model(
    model: torch.nn.Module,
    data_loader: torch.utils.data.DataLoader,
    device: torch.device,
    return_predictions: bool = False
) -> Dict[str, float]:
    """
    Evaluate a model on a dataset.
    
    Args:
        model: The model to evaluate
        data_loader: DataLoader for evaluation data
        device: Device to run evaluation on
        return_predictions: Whether to return predictions and probabilities
    
    Returns:
        Dictionary with evaluation metrics (and optionally predictions)
    """
    model.eval()
    
    all_labels = []
    all_preds = []
    all_probs = []
    
    with torch.no_grad():
        for batch in data_loader:
            # Move batch to device
            if isinstance(batch, dict):
                label_key = 'labels' if 'labels' in batch else 'label'
                inputs = {k: v.to(device) for k, v in batch.items() if k not in ['labels', 'label']}
                labels = batch[label_key].to(device)
            else:
                inputs, labels = batch
                if isinstance(inputs, dict):
                    inputs = {k: v.to(device) for k, v in inputs.items()}
                else:
                    inputs = inputs.to(device)
                labels = labels.to(device)
            
            # Forward pass
            if isinstance(inputs, dict):
                outputs = model(**inputs)
            else:
                outputs = model(inputs)
            
            # Get predictions
            if outputs.dim() > 1 and outputs.size(1) == 1:
                outputs = outputs.squeeze(1)
            
            probs = torch.sigmoid(outputs)
            preds = (probs > 0.5).long()
            
            # Collect results
            all_labels.extend(labels.cpu().numpy())
            all_preds.extend(preds.cpu().numpy())
            all_probs.extend(probs.cpu().numpy())
    
    # Convert to numpy arrays
    y_true = np.array(all_labels)
    y_pred = np.array(all_preds)
    y_prob = np.array(all_probs)
    
    # Compute metrics
    metrics = compute_metrics(y_true, y_pred, y_prob)
    
    if return_predictions:
        metrics['predictions'] = {
            'y_true': y_true,
            'y_pred': y_pred,
            'y_prob': y_prob
        }
    
    return metrics


def print_classification_report(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    target_names: Optional[List[str]] = None
) -> str:
    """
    Generate and print a classification report.
    
    Args:
        y_true: True labels
        y_pred: Predicted labels
        target_names: Names of target classes
    
    Returns:
        Classification report as string
    """
    if target_names is None:
        target_names = ['Fake/False', 'Real/True']
    
    report = classification_report(
        y_true,
        y_pred,
        target_names=target_names,
        digits=4
    )
    
    return report


def get_confusion_matrix(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    normalize: Optional[str] = None
) -> np.ndarray:
    """
    Compute confusion matrix.
    
    Args:
        y_true: True labels
        y_pred: Predicted labels
        normalize: Whether to normalize ('true', 'pred', 'all', or None)
    
    Returns:
        Confusion matrix
    """
    cm = confusion_matrix(y_true, y_pred)
    
    if normalize == 'true':
        cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
    elif normalize == 'pred':
        cm = cm.astype('float') / cm.sum(axis=0)[np.newaxis, :]
    elif normalize == 'all':
        cm = cm.astype('float') / cm.sum()
    
    return cm


def get_roc_curve_data(
    y_true: np.ndarray,
    y_prob: np.ndarray
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Compute ROC curve data.
    
    Args:
        y_true: True labels
        y_prob: Predicted probabilities
    
    Returns:
        Tuple of (fpr, tpr, thresholds)
    """
    fpr, tpr, thresholds = roc_curve(y_true, y_prob)
    return fpr, tpr, thresholds


def get_precision_recall_curve_data(
    y_true: np.ndarray,
    y_prob: np.ndarray
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Compute precision-recall curve data.
    
    Args:
        y_true: True labels
        y_prob: Predicted probabilities
    
    Returns:
        Tuple of (precision, recall, thresholds)
    """
    precision, recall, thresholds = precision_recall_curve(y_true, y_prob)
    return precision, recall, thresholds


def compare_models(
    results: Dict[str, Dict[str, float]],
    metrics: Optional[List[str]] = None
) -> str:
    """
    Compare multiple models based on their evaluation results.
    
    Args:
        results: Dictionary mapping model names to their metrics
        metrics: List of metrics to compare (defaults to key metrics)
    
    Returns:
        Formatted comparison string
    """
    if metrics is None:
        metrics = ['accuracy', 'precision', 'recall', 'f1', 'roc_auc']
    
    # Build comparison table
    lines = []
    lines.append("=" * 80)
    lines.append("MODEL COMPARISON")
    lines.append("=" * 80)
    
    # Header
    header = f"{'Model':<20}"
    for metric in metrics:
        header += f"{metric:>12}"
    lines.append(header)
    lines.append("-" * 80)
    
    # Rows
    for model_name, model_metrics in results.items():
        row = f"{model_name:<20}"
        for metric in metrics:
            value = model_metrics.get(metric, 0.0)
            row += f"{value:12.4f}"
        lines.append(row)
    
    lines.append("=" * 80)
    
    # Find best model for each metric
    lines.append("\nBest Performance:")
    for metric in metrics:
        best_model = max(results.items(), key=lambda x: x[1].get(metric, 0.0))
        lines.append(f"  {metric}: {best_model[0]} ({best_model[1].get(metric, 0.0):.4f})")
    
    return "\n".join(lines)


def compute_cross_dataset_metrics(
    results_dict: Dict[str, Dict[str, float]]
) -> Dict[str, float]:
    """
    Compute metrics for cross-dataset evaluation.
    
    Args:
        results_dict: Dictionary with keys like 'coaid_to_coaid', 'coaid_to_healthfact', etc.
    
    Returns:
        Dictionary with generalization metrics
    """
    metrics = {}
    
    # Within-dataset performance (average)
    within_dataset = []
    for key, results in results_dict.items():
        if 'to' in key:
            source, target = key.split('_to_')
            if source == target:
                within_dataset.append(results.get('f1', 0.0))
    
    if within_dataset:
        metrics['avg_within_dataset_f1'] = np.mean(within_dataset)
    
    # Cross-dataset performance (average)
    cross_dataset = []
    for key, results in results_dict.items():
        if 'to' in key:
            source, target = key.split('_to_')
            if source != target:
                cross_dataset.append(results.get('f1', 0.0))
    
    if cross_dataset:
        metrics['avg_cross_dataset_f1'] = np.mean(cross_dataset)
    
    # Generalization gap
    if within_dataset and cross_dataset:
        metrics['generalization_gap'] = metrics['avg_within_dataset_f1'] - metrics['avg_cross_dataset_f1']
    
    return metrics
