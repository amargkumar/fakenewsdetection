"""Models module initialization"""
