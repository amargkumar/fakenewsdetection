"""
Feed-Forward Neural Network models
"""
import torch
import torch.nn as nn
from typing import Dict, Any, Optional
from .base_model import BaseClassifier


class FFNNClassifier(BaseClassifier):
    """
    Feed-Forward Neural Network baseline model with embedding layer
    
    Architecture:
    - Input: Token sequences
    - Embedding Layer: Learnable word embeddings  
    - Pooling: Average pooling over sequence
    - Hidden Layers: 2-3 FC layers with ReLU and dropout
    - Output: Binary classification (sigmoid)
    """
    
    def __init__(self, vocab_size: int, embedding_dim: int = 128,
                 hidden_dims: list = [256, 128], 
                 dropout: float = 0.3, num_classes: int = 1,
                 padding_idx: int = 0):
        """
        Args:
            vocab_size: Size of vocabulary
            embedding_dim: Dimension of word embeddings
            hidden_dims: List of hidden layer dimensions
            dropout: Dropout probability
            num_classes: Number of output classes (1 for binary)
            padding_idx: Index for padding token
        """
        super().__init__()
        
        self.vocab_size = vocab_size
        self.embedding_dim = embedding_dim
        self.hidden_dims = hidden_dims
        self.dropout = dropout
        self.num_classes = num_classes
        
        # Embedding layer
        self.embedding = nn.Embedding(vocab_size, embedding_dim, padding_idx=padding_idx)
        
        # Build hidden layers
        layers = []
        prev_dim = embedding_dim
        
        for hidden_dim in hidden_dims:
            layers.append(nn.Linear(prev_dim, hidden_dim))
            layers.append(nn.ReLU())
            layers.append(nn.Dropout(dropout))
            prev_dim = hidden_dim
        
        self.hidden_layers = nn.Sequential(*layers)
        self.output_layer = nn.Linear(prev_dim, num_classes)
    
    def forward(self, input_ids: torch.Tensor, **kwargs) -> torch.Tensor:
        """
        Forward pass
        
        Args:
            input_ids: Input tensor of token indices, shape (batch_size, seq_len)
            
        Returns:
            Logits of shape (batch_size,)
        """
        # Embed tokens: (batch_size, seq_len, embedding_dim)
        embedded = self.embedding(input_ids)
        
        # Average pooling: (batch_size, embedding_dim)
        pooled = embedded.mean(dim=1)
        
        # Forward through hidden layers
        h = self.hidden_layers(pooled)
        logits = self.output_layer(h)
        return logits.squeeze(-1)  # (batch_size,)
    
    def get_config(self) -> Dict[str, Any]:
        return {
            'model_type': 'FFNN',
            'vocab_size': self.vocab_size,
            'embedding_dim': self.embedding_dim,
            'hidden_dims': self.hidden_dims,
            'dropout': self.dropout,
            'num_classes': self.num_classes
        }


class FFNNWithFeatures(BaseClassifier):
    """
    FFNN with engineered features (text + features)
    
    Architecture:
    - Text branch: Embedding + pooling + FC layers
    - Feature branch: FC layer for engineered features
    - Fusion: Concatenate before final layer
    - Output: Binary classification
    """
    
    def __init__(self, vocab_size: int, embedding_dim: int = 128,
                 feature_dim: int = 16, 
                 hidden_dims: list = [256, 128], dropout: float = 0.3,
                 num_classes: int = 1, padding_idx: int = 0):
        """
        Args:
            vocab_size: Size of vocabulary
            embedding_dim: Dimension of word embeddings
            feature_dim: Engineered features dimension (e.g., 16 for sentiment+linguistic)
            hidden_dims: List of hidden layer dimensions
            dropout: Dropout probability
            num_classes: Number of output classes
            padding_idx: Index for padding token
        """
        super().__init__()
        
        self.vocab_size = vocab_size
        self.embedding_dim = embedding_dim
        self.feature_dim = feature_dim
        self.hidden_dims = hidden_dims
        self.dropout = dropout
        self.num_classes = num_classes
        
        # Embedding layer
        self.embedding = nn.Embedding(vocab_size, embedding_dim, padding_idx=padding_idx)
        
        # Text processing branch
        text_layers = []
        prev_dim = embedding_dim
        
        for hidden_dim in hidden_dims[:-1]:  # All but last hidden layer
            text_layers.append(nn.Linear(prev_dim, hidden_dim))
            text_layers.append(nn.ReLU())
            text_layers.append(nn.Dropout(dropout))
            prev_dim = hidden_dim
        
        self.text_branch = nn.Sequential(*text_layers) if text_layers else nn.Identity()
        
        # Feature processing (light transformation)
        self.feature_transform = nn.Linear(feature_dim, feature_dim)
        
        # Fusion layer
        fusion_input_dim = prev_dim + feature_dim
        self.fusion_layer = nn.Sequential(
            nn.Linear(fusion_input_dim, hidden_dims[-1]),
            nn.ReLU(),
            nn.Dropout(dropout)
        )
        
        # Output layer
        self.output_layer = nn.Linear(hidden_dims[-1], num_classes)
    
    def forward(self, input_ids: torch.Tensor, features: Optional[torch.Tensor] = None, **kwargs) -> torch.Tensor:
        """
        Forward pass
        
        Args:
            input_ids: Token indices tensor of shape (batch_size, seq_len)
            features: Features tensor of shape (batch_size, feature_dim)
            
        Returns:
            Logits of shape (batch_size,)
        """
        # Embed and pool text: (batch_size, embedding_dim)
        embedded = self.embedding(input_ids)
        pooled = embedded.mean(dim=1)
        
        # Process text
        text_repr = self.text_branch(pooled)
        
        # Process features
        feature_repr = torch.relu(self.feature_transform(features))
        
        # Concatenate
        fused = torch.cat([text_repr, feature_repr], dim=1)
        
        # Final layers
        h = self.fusion_layer(fused)
        logits = self.output_layer(h)
        return logits.squeeze(-1)  # (batch_size,)
    
    def get_config(self) -> Dict[str, Any]:
        return {
            'model_type': 'FFNN_Features',
            'vocab_size': self.vocab_size,
            'embedding_dim': self.embedding_dim,
            'feature_dim': self.feature_dim,
            'hidden_dims': self.hidden_dims,
            'dropout': self.dropout,
            'num_classes': self.num_classes
        }
        combined = torch.cat([text_repr, feature_repr], dim=1)
        
        # Fusion and output
        fused = self.fusion_layer(combined)
        logits = self.output_layer(fused)
        
        return logits.squeeze(-1)
    
    def get_config(self) -> Dict[str, Any]:
        return {
            'model_type': 'FFNN_with_features',
            'text_dim': self.text_dim,
            'feature_dim': self.feature_dim,
            'hidden_dims': self.hidden_dims,
            'dropout': self.dropout,
            'num_classes': self.num_classes
        }
