"""
Transformer Models: BERT, BioBERT, and PubMedBERT for Health Misinformation Detection
Uses HuggingFace Transformers library
"""

import torch
import torch.nn as nn
from transformers import (
    AutoModel,
    AutoTokenizer,
    BertModel,
    BertTokenizer
)
from typing import Dict, Any, Optional
from .base_model import BaseClassifier


class TransformerClassifier(BaseClassifier):
    """
    Base class for transformer-based classifiers.
    Supports BERT, BioBERT, PubMedBERT, and other HuggingFace models.
    """
    
    def __init__(
        self,
        model_name: str = 'bert-base-uncased',
        num_classes: int = 1,
        dropout: float = 0.1,
        freeze_encoder: bool = False
    ):
        """
        Initialize transformer classifier.
        
        Args:
            model_name: Name of pre-trained model from HuggingFace
                - 'bert-base-uncased': BERT base
                - 'dmis-lab/biobert-v1.1': BioBERT
                - 'microsoft/BiomedNLP-PubMedBERT-base-uncased-abstract-fulltext': PubMedBERT
            num_classes: Number of output classes (1 for binary)
            dropout: Dropout rate
            freeze_encoder: Whether to freeze encoder weights
        """
        super().__init__()
        
        self.model_name = model_name
        self.num_classes = num_classes
        self.dropout = dropout
        self.freeze_encoder = freeze_encoder
        
        # Load pre-trained transformer
        self.encoder = AutoModel.from_pretrained(model_name)
        
        # Freeze encoder if specified
        if freeze_encoder:
            for param in self.encoder.parameters():
                param.requires_grad = False
        
        # Get hidden size from encoder config
        self.hidden_size = self.encoder.config.hidden_size
        
        # Classification head
        self.dropout_layer = nn.Dropout(dropout)
        self.classifier = nn.Linear(self.hidden_size, num_classes)
    
    def forward(
        self,
        input_ids: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        token_type_ids: Optional[torch.Tensor] = None
    ) -> torch.Tensor:
        """
        Forward pass.
        
        Args:
            input_ids: Input token IDs, shape (batch_size, seq_len)
            attention_mask: Attention mask, shape (batch_size, seq_len)
            token_type_ids: Token type IDs for BERT, shape (batch_size, seq_len)
        
        Returns:
            Logits, shape (batch_size,)
        """
        # Pass through transformer encoder
        outputs = self.encoder(
            input_ids=input_ids,
            attention_mask=attention_mask,
            token_type_ids=token_type_ids
        )
        
        # Use [CLS] token representation (first token)
        pooled_output = outputs.last_hidden_state[:, 0, :]  # (batch_size, hidden_size)
        
        # Classification
        pooled_output = self.dropout_layer(pooled_output)
        logits = self.classifier(pooled_output)
        
        return logits.squeeze(-1) if self.num_classes == 1 else logits
    
    def get_config(self) -> Dict[str, Any]:
        return {
            'model_type': 'Transformer',
            'model_name': self.model_name,
            'num_classes': self.num_classes,
            'dropout': self.dropout,
            'freeze_encoder': self.freeze_encoder,
            'hidden_size': self.hidden_size
        }


class BERTClassifier(TransformerClassifier):
    """BERT for text classification."""
    
    def __init__(self, num_classes: int = 1, dropout: float = 0.1, freeze_encoder: bool = False):
        super().__init__(
            model_name='bert-base-uncased',
            num_classes=num_classes,
            dropout=dropout,
            freeze_encoder=freeze_encoder
        )
    
    def get_config(self) -> Dict[str, Any]:
        config = super().get_config()
        config['model_type'] = 'BERT'
        return config


class BioBERTClassifier(TransformerClassifier):
    """BioBERT for biomedical text classification."""
    
    def __init__(self, num_classes: int = 1, dropout: float = 0.1, freeze_encoder: bool = False):
        super().__init__(
            model_name='dmis-lab/biobert-v1.1',
            num_classes=num_classes,
            dropout=dropout,
            freeze_encoder=freeze_encoder
        )
    
    def get_config(self) -> Dict[str, Any]:
        config = super().get_config()
        config['model_type'] = 'BioBERT'
        return config


class PubMedBERTClassifier(TransformerClassifier):
    """PubMedBERT for biomedical text classification."""
    
    def __init__(self, num_classes: int = 1, dropout: float = 0.1, freeze_encoder: bool = False):
        super().__init__(
            model_name='microsoft/BiomedNLP-PubMedBERT-base-uncased-abstract-fulltext',
            num_classes=num_classes,
            dropout=dropout,
            freeze_encoder=freeze_encoder
        )
    
    def get_config(self) -> Dict[str, Any]:
        config = super().get_config()
        config['model_type'] = 'PubMedBERT'
        return config


class TransformerWithFeatures(BaseClassifier):
    """
    Transformer with additional engineered features.
    
    Architecture:
    - Text branch: Transformer encoder
    - Feature branch: FC layer for engineered features
    - Fusion: Concatenation + FC layers
    """
    
    def __init__(
        self,
        model_name: str = 'bert-base-uncased',
        feature_dim: int = 16,
        num_classes: int = 1,
        dropout: float = 0.1,
        freeze_encoder: bool = False
    ):
        """
        Initialize transformer with features.
        
        Args:
            model_name: Name of pre-trained transformer
            feature_dim: Dimension of engineered features
            num_classes: Number of output classes
            dropout: Dropout rate
            freeze_encoder: Whether to freeze encoder weights
        """
        super().__init__()
        
        self.model_name = model_name
        self.feature_dim = feature_dim
        self.num_classes = num_classes
        self.dropout = dropout
        self.freeze_encoder = freeze_encoder
        
        # Load pre-trained transformer
        self.encoder = AutoModel.from_pretrained(model_name)
        
        # Freeze encoder if specified
        if freeze_encoder:
            for param in self.encoder.parameters():
                param.requires_grad = False
        
        # Get hidden size
        self.hidden_size = self.encoder.config.hidden_size
        
        # Dropout
        self.dropout_layer = nn.Dropout(dropout)
        
        # Feature transformation
        self.feature_transform = nn.Linear(feature_dim, feature_dim)
        
        # Fusion layer
        fusion_input_dim = self.hidden_size + feature_dim
        self.fusion_layer = nn.Sequential(
            nn.Linear(fusion_input_dim, 256),
            nn.ReLU(),
            nn.Dropout(dropout)
        )
        
        # Output layer
        self.output_layer = nn.Linear(256, num_classes)
    
    def forward(
        self,
        input_ids: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        token_type_ids: Optional[torch.Tensor] = None,
        features: Optional[torch.Tensor] = None
    ) -> torch.Tensor:
        """
        Forward pass.
        
        Args:
            input_ids: Input token IDs, shape (batch_size, seq_len)
            attention_mask: Attention mask, shape (batch_size, seq_len)
            token_type_ids: Token type IDs, shape (batch_size, seq_len)
            features: Engineered features, shape (batch_size, feature_dim)
        
        Returns:
            Logits, shape (batch_size,)
        """
        # Pass through transformer encoder
        outputs = self.encoder(
            input_ids=input_ids,
            attention_mask=attention_mask,
            token_type_ids=token_type_ids
        )
        
        # Use [CLS] token representation
        text_repr = outputs.last_hidden_state[:, 0, :]
        text_repr = self.dropout_layer(text_repr)
        
        # Process features
        feature_repr = torch.relu(self.feature_transform(features))
        
        # Concatenate text and features
        fused = torch.cat([text_repr, feature_repr], dim=1)
        
        # Fusion and output
        h = self.fusion_layer(fused)
        logits = self.output_layer(h)
        
        return logits.squeeze(-1) if self.num_classes == 1 else logits
    
    def get_config(self) -> Dict[str, Any]:
        return {
            'model_type': 'Transformer_Features',
            'model_name': self.model_name,
            'feature_dim': self.feature_dim,
            'num_classes': self.num_classes,
            'dropout': self.dropout,
            'freeze_encoder': self.freeze_encoder,
            'hidden_size': self.hidden_size
        }


class BERTWithFeatures(TransformerWithFeatures):
    """BERT with engineered features."""
    
    def __init__(self, feature_dim: int = 16, num_classes: int = 1, dropout: float = 0.1, freeze_encoder: bool = False):
        super().__init__(
            model_name='bert-base-uncased',
            feature_dim=feature_dim,
            num_classes=num_classes,
            dropout=dropout,
            freeze_encoder=freeze_encoder
        )


class BioBERTWithFeatures(TransformerWithFeatures):
    """BioBERT with engineered features."""
    
    def __init__(self, feature_dim: int = 16, num_classes: int = 1, dropout: float = 0.1, freeze_encoder: bool = False):
        super().__init__(
            model_name='dmis-lab/biobert-v1.1',
            feature_dim=feature_dim,
            num_classes=num_classes,
            dropout=dropout,
            freeze_encoder=freeze_encoder
        )


class PubMedBERTWithFeatures(TransformerWithFeatures):
    """PubMedBERT with engineered features."""
    
    def __init__(self, feature_dim: int = 16, num_classes: int = 1, dropout: float = 0.1, freeze_encoder: bool = False):
        super().__init__(
            model_name='microsoft/BiomedNLP-PubMedBERT-base-uncased-abstract-fulltext',
            feature_dim=feature_dim,
            num_classes=num_classes,
            dropout=dropout,
            freeze_encoder=freeze_encoder
        )


# Helper function to get tokenizer for transformer models
def get_transformer_tokenizer(model_name: str):
    """
    Get appropriate tokenizer for a transformer model.
    
    Args:
        model_name: Name of the model or model type
    
    Returns:
        HuggingFace tokenizer
    """
    model_map = {
        'bert': 'bert-base-uncased',
        'biobert': 'dmis-lab/biobert-v1.1',
        'pubmedbert': 'microsoft/BiomedNLP-PubMedBERT-base-uncased-abstract-fulltext'
    }
    
    # Map model type to actual model name if needed
    actual_model_name = model_map.get(model_name.lower(), model_name)
    
    return AutoTokenizer.from_pretrained(actual_model_name)
