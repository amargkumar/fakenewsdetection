"""
Abstract base class for all models
"""
from abc import ABC, abstractmethod
import torch
import torch.nn as nn
from pathlib import Path
from typing import Dict, Any


class BaseClassifier(nn.Module, ABC):
    """
    Abstract base class defining common model interface
    """
    
    def __init__(self):
        super().__init__()
    
    @abstractmethod
    def forward(self, **kwargs) -> torch.Tensor:
        """
        Forward pass through the model
        
        Returns:
            Logits or probabilities
        """
        pass
    
    def predict(self, **kwargs) -> torch.Tensor:
        """
        Make predictions (binary classification)
        
        Returns:
            Predicted class labels
        """
        self.eval()
        with torch.no_grad():
            logits = self.forward(**kwargs)
            predictions = (torch.sigmoid(logits) > 0.5).long()
        return predictions
    
    def save(self, path: str):
        """
        Save model checkpoint
        
        Args:
            path: Path to save model
        """
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        torch.save({
            'model_state_dict': self.state_dict(),
            'model_config': self.get_config()
        }, path)
        print(f"Model saved to {path}")
    
    def load(self, path: str):
        """
        Load model checkpoint
        
        Args:
            path: Path to load model from
        """
        checkpoint = torch.load(path)
        self.load_state_dict(checkpoint['model_state_dict'])
        print(f"Model loaded from {path}")
    
    @abstractmethod
    def get_config(self) -> Dict[str, Any]:
        """
        Get model configuration
        
        Returns:
            Dictionary with model hyperparameters
        """
        pass
    
    def count_parameters(self) -> int:
        """
        Count trainable parameters
        
        Returns:
            Number of trainable parameters
        """
        return sum(p.numel() for p in self.parameters() if p.requires_grad)
