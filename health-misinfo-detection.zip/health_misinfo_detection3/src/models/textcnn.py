"""
TextCNN: Convolutional Neural Network for Text Classification
Based on "Convolutional Neural Networks for Sentence Classification" (Kim, 2014)
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict, Any, List, Optional
from .base_model import BaseClassifier


class TextCNN(BaseClassifier):
    """
    TextCNN model for text classification.
    
    Architecture:
    - Embedding layer
    - Multiple parallel convolutional layers with different filter sizes
    - Max-over-time pooling
    - Fully connected layers
    - Dropout for regularization
    """
    
    def __init__(
        self,
        vocab_size: int,
        embedding_dim: int = 128,
        num_filters: int = 100,
        filter_sizes: List[int] = [3, 4, 5],
        dropout: float = 0.5,
        num_classes: int = 1,
        padding_idx: int = 0
    ):
        """
        Initialize TextCNN model.
        
        Args:
            vocab_size: Size of vocabulary
            embedding_dim: Dimension of word embeddings
            num_filters: Number of filters for each filter size
            filter_sizes: List of filter window sizes (e.g., [3, 4, 5])
            dropout: Dropout rate
            num_classes: Number of output classes (1 for binary)
            padding_idx: Index for padding token
        """
        super().__init__()
        
        self.vocab_size = vocab_size
        self.embedding_dim = embedding_dim
        self.num_filters = num_filters
        self.filter_sizes = filter_sizes
        self.dropout = dropout
        self.num_classes = num_classes
        
        # Embedding layer
        self.embedding = nn.Embedding(vocab_size, embedding_dim, padding_idx=padding_idx)
        
        # Convolutional layers - one for each filter size
        self.convs = nn.ModuleList([
            nn.Conv1d(
                in_channels=embedding_dim,
                out_channels=num_filters,
                kernel_size=fs
            )
            for fs in filter_sizes
        ])
        
        # Dropout layer
        self.dropout_layer = nn.Dropout(dropout)
        
        # Fully connected layer
        # Input: num_filters * len(filter_sizes) (concatenated outputs from all convolutions)
        self.fc = nn.Linear(num_filters * len(filter_sizes), num_classes)
    
    def forward(self, input_ids: torch.Tensor) -> torch.Tensor:
        """
        Forward pass.
        
        Args:
            input_ids: Input token IDs, shape (batch_size, seq_len)
        
        Returns:
            Logits, shape (batch_size,) for binary classification
        """
        # Embedding: (batch_size, seq_len) -> (batch_size, seq_len, embedding_dim)
        embedded = self.embedding(input_ids)
        
        # Transpose for conv1d: (batch_size, embedding_dim, seq_len)
        # Conv1d expects (batch_size, channels, length)
        embedded = embedded.transpose(1, 2)
        
        # Apply convolutions and max pooling
        conv_outputs = []
        for conv in self.convs:
            # Convolution: (batch_size, num_filters, seq_len - kernel_size + 1)
            conv_out = F.relu(conv(embedded))
            
            # Max-over-time pooling: (batch_size, num_filters)
            pooled = F.max_pool1d(conv_out, conv_out.size(2)).squeeze(2)
            conv_outputs.append(pooled)
        
        # Concatenate outputs from all filter sizes: (batch_size, num_filters * len(filter_sizes))
        concatenated = torch.cat(conv_outputs, dim=1)
        
        # Apply dropout
        dropped = self.dropout_layer(concatenated)
        
        # Fully connected layer: (batch_size, num_classes)
        logits = self.fc(dropped)
        
        # Squeeze for binary classification
        return logits.squeeze(-1) if self.num_classes == 1 else logits
    
    def get_config(self) -> Dict[str, Any]:
        return {
            'model_type': 'TextCNN',
            'vocab_size': self.vocab_size,
            'embedding_dim': self.embedding_dim,
            'num_filters': self.num_filters,
            'filter_sizes': self.filter_sizes,
            'dropout': self.dropout,
            'num_classes': self.num_classes
        }


class TextCNNWithFeatures(BaseClassifier):
    """
    TextCNN with additional engineered features.
    
    Architecture:
    - Text branch: TextCNN processing
    - Feature branch: FC layer for engineered features
    - Fusion: Concatenation + FC layers
    """
    
    def __init__(
        self,
        vocab_size: int,
        embedding_dim: int = 128,
        num_filters: int = 100,
        filter_sizes: List[int] = [3, 4, 5],
        feature_dim: int = 16,
        dropout: float = 0.5,
        num_classes: int = 1,
        padding_idx: int = 0
    ):
        """
        Initialize TextCNN with features.
        
        Args:
            vocab_size: Size of vocabulary
            embedding_dim: Dimension of word embeddings
            num_filters: Number of filters for each filter size
            filter_sizes: List of filter window sizes
            feature_dim: Dimension of engineered features
            dropout: Dropout rate
            num_classes: Number of output classes
            padding_idx: Index for padding token
        """
        super().__init__()
        
        self.vocab_size = vocab_size
        self.embedding_dim = embedding_dim
        self.num_filters = num_filters
        self.filter_sizes = filter_sizes
        self.feature_dim = feature_dim
        self.dropout = dropout
        self.num_classes = num_classes
        
        # Embedding layer
        self.embedding = nn.Embedding(vocab_size, embedding_dim, padding_idx=padding_idx)
        
        # Convolutional layers
        self.convs = nn.ModuleList([
            nn.Conv1d(
                in_channels=embedding_dim,
                out_channels=num_filters,
                kernel_size=fs
            )
            for fs in filter_sizes
        ])
        
        # Feature transformation
        self.feature_transform = nn.Linear(feature_dim, feature_dim)
        
        # Fusion layer
        cnn_output_dim = num_filters * len(filter_sizes)
        fusion_input_dim = cnn_output_dim + feature_dim
        
        self.fusion_layer = nn.Sequential(
            nn.Linear(fusion_input_dim, 128),
            nn.ReLU(),
            nn.Dropout(dropout)
        )
        
        # Output layer
        self.output_layer = nn.Linear(128, num_classes)
    
    def forward(self, input_ids: torch.Tensor, features: Optional[torch.Tensor] = None) -> torch.Tensor:
        """
        Forward pass.
        
        Args:
            input_ids: Input token IDs, shape (batch_size, seq_len)
            features: Engineered features, shape (batch_size, feature_dim)
        
        Returns:
            Logits, shape (batch_size,)
        """
        # Embedding and transpose
        embedded = self.embedding(input_ids).transpose(1, 2)
        
        # Apply convolutions and pooling
        conv_outputs = []
        for conv in self.convs:
            conv_out = F.relu(conv(embedded))
            pooled = F.max_pool1d(conv_out, conv_out.size(2)).squeeze(2)
            conv_outputs.append(pooled)
        
        # Concatenate CNN outputs
        text_repr = torch.cat(conv_outputs, dim=1)
        
        # Process features
        feature_repr = F.relu(self.feature_transform(features))
        
        # Concatenate text and features
        fused = torch.cat([text_repr, feature_repr], dim=1)
        
        # Fusion and output
        h = self.fusion_layer(fused)
        logits = self.output_layer(h)
        
        return logits.squeeze(-1) if self.num_classes == 1 else logits
    
    def get_config(self) -> Dict[str, Any]:
        return {
            'model_type': 'TextCNN_Features',
            'vocab_size': self.vocab_size,
            'embedding_dim': self.embedding_dim,
            'num_filters': self.num_filters,
            'filter_sizes': self.filter_sizes,
            'feature_dim': self.feature_dim,
            'dropout': self.dropout,
            'num_classes': self.num_classes
        }
