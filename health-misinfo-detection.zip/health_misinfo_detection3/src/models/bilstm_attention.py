"""
BiLSTM with Attention: Bidirectional LSTM with Attention Mechanism
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict, Any, Optional, Tuple
from .base_model import BaseClassifier


class Attention(nn.Module):
    """
    Attention mechanism for sequence models.
    Computes attention weights and context vector.
    """
    
    def __init__(self, hidden_dim: int):
        """
        Initialize attention layer.
        
        Args:
            hidden_dim: Hidden dimension of the sequence encoder
        """
        super().__init__()
        self.hidden_dim = hidden_dim
        
        # Attention weight computation
        self.attention = nn.Linear(hidden_dim, 1, bias=False)
    
    def forward(self, encoder_outputs: torch.Tensor, mask: Optional[torch.Tensor] = None) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Compute attention weights and context vector.
        
        Args:
            encoder_outputs: Encoder outputs, shape (batch_size, seq_len, hidden_dim)
            mask: Optional padding mask, shape (batch_size, seq_len)
        
        Returns:
            context: Context vector, shape (batch_size, hidden_dim)
            attention_weights: Attention weights, shape (batch_size, seq_len)
        """
        # Compute attention scores: (batch_size, seq_len, 1)
        scores = self.attention(encoder_outputs)
        
        # Squeeze to (batch_size, seq_len)
        scores = scores.squeeze(-1)
        
        # Apply mask if provided (set padding positions to very negative value)
        if mask is not None:
            scores = scores.masked_fill(mask == 0, -1e9)
        
        # Compute attention weights using softmax: (batch_size, seq_len)
        attention_weights = F.softmax(scores, dim=1)
        
        # Compute context vector: (batch_size, hidden_dim)
        # attention_weights: (batch_size, seq_len) -> (batch_size, 1, seq_len)
        # encoder_outputs: (batch_size, seq_len, hidden_dim)
        # context: (batch_size, 1, hidden_dim) -> (batch_size, hidden_dim)
        context = torch.bmm(attention_weights.unsqueeze(1), encoder_outputs).squeeze(1)
        
        return context, attention_weights


class BiLSTMAttention(BaseClassifier):
    """
    Bidirectional LSTM with Attention mechanism for text classification.
    
    Architecture:
    - Embedding layer
    - Bidirectional LSTM
    - Attention mechanism
    - Fully connected layers
    """
    
    def __init__(
        self,
        vocab_size: int,
        embedding_dim: int = 128,
        hidden_dim: int = 128,
        num_layers: int = 2,
        dropout: float = 0.3,
        num_classes: int = 1,
        padding_idx: int = 0,
        bidirectional: bool = True
    ):
        """
        Initialize BiLSTM with Attention.
        
        Args:
            vocab_size: Size of vocabulary
            embedding_dim: Dimension of word embeddings
            hidden_dim: Hidden dimension of LSTM
            num_layers: Number of LSTM layers
            dropout: Dropout rate
            num_classes: Number of output classes (1 for binary)
            padding_idx: Index for padding token
            bidirectional: Whether to use bidirectional LSTM
        """
        super().__init__()
        
        self.vocab_size = vocab_size
        self.embedding_dim = embedding_dim
        self.hidden_dim = hidden_dim
        self.num_layers = num_layers
        self.dropout = dropout
        self.num_classes = num_classes
        self.bidirectional = bidirectional
        
        # Embedding layer
        self.embedding = nn.Embedding(vocab_size, embedding_dim, padding_idx=padding_idx)
        
        # Bidirectional LSTM
        self.lstm = nn.LSTM(
            input_size=embedding_dim,
            hidden_size=hidden_dim,
            num_layers=num_layers,
            dropout=dropout if num_layers > 1 else 0,
            bidirectional=bidirectional,
            batch_first=True
        )
        
        # Attention mechanism
        # If bidirectional, LSTM output is 2 * hidden_dim
        lstm_output_dim = hidden_dim * 2 if bidirectional else hidden_dim
        self.attention = Attention(lstm_output_dim)
        
        # Dropout
        self.dropout_layer = nn.Dropout(dropout)
        
        # Fully connected layers
        self.fc = nn.Sequential(
            nn.Linear(lstm_output_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, num_classes)
        )
    
    def forward(self, input_ids: torch.Tensor) -> torch.Tensor:
        """
        Forward pass.
        
        Args:
            input_ids: Input token IDs, shape (batch_size, seq_len)
        
        Returns:
            Logits, shape (batch_size,)
        """
        # Create padding mask (1 for real tokens, 0 for padding)
        mask = (input_ids != 0).long()
        
        # Embedding: (batch_size, seq_len, embedding_dim)
        embedded = self.embedding(input_ids)
        embedded = self.dropout_layer(embedded)
        
        # LSTM: (batch_size, seq_len, hidden_dim * 2) if bidirectional
        lstm_out, _ = self.lstm(embedded)
        
        # Attention: (batch_size, hidden_dim * 2)
        context, attention_weights = self.attention(lstm_out, mask)
        
        # Store attention weights for visualization (optional)
        self.last_attention_weights = attention_weights
        
        # Fully connected layers: (batch_size, num_classes)
        logits = self.fc(context)
        
        return logits.squeeze(-1) if self.num_classes == 1 else logits
    
    def get_config(self) -> Dict[str, Any]:
        return {
            'model_type': 'BiLSTM_Attention',
            'vocab_size': self.vocab_size,
            'embedding_dim': self.embedding_dim,
            'hidden_dim': self.hidden_dim,
            'num_layers': self.num_layers,
            'dropout': self.dropout,
            'num_classes': self.num_classes,
            'bidirectional': self.bidirectional
        }


class BiLSTMAttentionWithFeatures(BaseClassifier):
    """
    BiLSTM with Attention and engineered features.
    
    Architecture:
    - Text branch: BiLSTM + Attention
    - Feature branch: FC layer for engineered features
    - Fusion: Concatenation + FC layers
    """
    
    def __init__(
        self,
        vocab_size: int,
        embedding_dim: int = 128,
        hidden_dim: int = 128,
        num_layers: int = 2,
        feature_dim: int = 16,
        dropout: float = 0.3,
        num_classes: int = 1,
        padding_idx: int = 0,
        bidirectional: bool = True
    ):
        """
        Initialize BiLSTM with Attention and features.
        
        Args:
            vocab_size: Size of vocabulary
            embedding_dim: Dimension of word embeddings
            hidden_dim: Hidden dimension of LSTM
            num_layers: Number of LSTM layers
            feature_dim: Dimension of engineered features
            dropout: Dropout rate
            num_classes: Number of output classes
            padding_idx: Index for padding token
            bidirectional: Whether to use bidirectional LSTM
        """
        super().__init__()
        
        self.vocab_size = vocab_size
        self.embedding_dim = embedding_dim
        self.hidden_dim = hidden_dim
        self.num_layers = num_layers
        self.feature_dim = feature_dim
        self.dropout = dropout
        self.num_classes = num_classes
        self.bidirectional = bidirectional
        
        # Embedding layer
        self.embedding = nn.Embedding(vocab_size, embedding_dim, padding_idx=padding_idx)
        
        # Bidirectional LSTM
        self.lstm = nn.LSTM(
            input_size=embedding_dim,
            hidden_size=hidden_dim,
            num_layers=num_layers,
            dropout=dropout if num_layers > 1 else 0,
            bidirectional=bidirectional,
            batch_first=True
        )
        
        # Attention mechanism
        lstm_output_dim = hidden_dim * 2 if bidirectional else hidden_dim
        self.attention = Attention(lstm_output_dim)
        
        # Dropout
        self.dropout_layer = nn.Dropout(dropout)
        
        # Feature transformation
        self.feature_transform = nn.Linear(feature_dim, feature_dim)
        
        # Fusion layer
        fusion_input_dim = lstm_output_dim + feature_dim
        self.fusion_layer = nn.Sequential(
            nn.Linear(fusion_input_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout)
        )
        
        # Output layer
        self.output_layer = nn.Linear(hidden_dim, num_classes)
    
    def forward(self, input_ids: torch.Tensor, features: Optional[torch.Tensor] = None) -> torch.Tensor:
        """
        Forward pass.
        
        Args:
            input_ids: Input token IDs, shape (batch_size, seq_len)
            features: Engineered features, shape (batch_size, feature_dim)
        
        Returns:
            Logits, shape (batch_size,)
        """
        # Create padding mask
        mask = (input_ids != 0).long()
        
        # Embedding
        embedded = self.embedding(input_ids)
        embedded = self.dropout_layer(embedded)
        
        # LSTM
        lstm_out, _ = self.lstm(embedded)
        
        # Attention
        context, attention_weights = self.attention(lstm_out, mask)
        self.last_attention_weights = attention_weights
        
        # Process features
        feature_repr = F.relu(self.feature_transform(features))
        
        # Concatenate text and features
        fused = torch.cat([context, feature_repr], dim=1)
        
        # Fusion and output
        h = self.fusion_layer(fused)
        logits = self.output_layer(h)
        
        return logits.squeeze(-1) if self.num_classes == 1 else logits
    
    def get_config(self) -> Dict[str, Any]:
        return {
            'model_type': 'BiLSTM_Attention_Features',
            'vocab_size': self.vocab_size,
            'embedding_dim': self.embedding_dim,
            'hidden_dim': self.hidden_dim,
            'num_layers': self.num_layers,
            'feature_dim': self.feature_dim,
            'dropout': self.dropout,
            'num_classes': self.num_classes,
            'bidirectional': self.bidirectional
        }
