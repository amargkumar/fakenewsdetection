"""
Trainer class for training health misinformation detection models.
Handles training loop, validation, early stopping, and checkpointing.
"""

import os
import time
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from typing import Dict, List, Optional, Callable
import logging
from pathlib import Path

logger = logging.getLogger(__name__)


class Trainer:
    """
    General-purpose trainer for health misinformation detection models.
    Works with any model inheriting from BaseClassifier.
    """
    
    def __init__(
        self,
        model: nn.Module,
        train_loader: DataLoader,
        val_loader: Optional[DataLoader] = None,
        test_loader: Optional[DataLoader] = None,
        optimizer: Optional[torch.optim.Optimizer] = None,
        criterion: Optional[nn.Module] = None,
        device: Optional[torch.device] = None,
        callbacks: Optional[List] = None,
        log_interval: int = 10,
        checkpoint_dir: str = "checkpoints"
    ):
        """
        Initialize the trainer.
        
        Args:
            model: The model to train
            train_loader: DataLoader for training data
            val_loader: DataLoader for validation data (optional)
            test_loader: DataLoader for test data (optional)
            optimizer: Optimizer (defaults to Adam)
            criterion: Loss function (defaults to BCEWithLogitsLoss)
            device: Device to train on (defaults to cuda if available)
            callbacks: List of callback objects
            log_interval: How often to log training progress (in batches)
            checkpoint_dir: Directory to save model checkpoints
        """
        self.model = model
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.test_loader = test_loader
        
        # Setup device
        if device is None:
            self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        else:
            self.device = device
        
        self.model.to(self.device)
        
        # Setup optimizer
        if optimizer is None:
            self.optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
        else:
            self.optimizer = optimizer
        
        # Setup loss function
        if criterion is None:
            self.criterion = nn.BCEWithLogitsLoss()
        else:
            self.criterion = criterion
        
        self.callbacks = callbacks or []
        self.log_interval = log_interval
        self.checkpoint_dir = Path(checkpoint_dir)
        self.checkpoint_dir.mkdir(parents=True, exist_ok=True)
        
        # Training history
        self.history = {
            'train_loss': [],
            'train_acc': [],
            'val_loss': [],
            'val_acc': [],
            'epoch_times': []
        }
        
        self.current_epoch = 0
        self.best_val_loss = float('inf')
        self.best_val_acc = 0.0
        
    def train_epoch(self) -> Dict[str, float]:
        """
        Train for one epoch.
        
        Returns:
            Dictionary with training metrics for the epoch
        """
        self.model.train()
        total_loss = 0.0
        correct = 0
        total = 0
        
        for batch_idx, batch in enumerate(self.train_loader):
            # Move batch to device
            if isinstance(batch, dict):
                # For datasets that return dictionaries
                label_key = 'labels' if 'labels' in batch else 'label'
                inputs = {k: v.to(self.device) for k, v in batch.items() if k not in ['labels', 'label']}
                labels = batch[label_key].to(self.device)
            else:
                # For datasets that return tuples
                inputs, labels = batch
                if isinstance(inputs, dict):
                    inputs = {k: v.to(self.device) for k, v in inputs.items()}
                else:
                    inputs = inputs.to(self.device)
                labels = labels.to(self.device)
            
            # Zero gradients
            self.optimizer.zero_grad()
            
            # Forward pass
            if isinstance(inputs, dict):
                outputs = self.model(**inputs)
            else:
                outputs = self.model(inputs)
            
            # Compute loss
            if outputs.dim() > 1 and outputs.size(1) == 1:
                outputs = outputs.squeeze(1)
            
            loss = self.criterion(outputs, labels.float())
            
            # Backward pass
            loss.backward()
            self.optimizer.step()
            
            # Track metrics
            total_loss += loss.item()
            
            # Calculate accuracy
            predictions = torch.sigmoid(outputs) > 0.5
            correct += (predictions == labels).sum().item()
            total += labels.size(0)
            
            # Log progress
            if (batch_idx + 1) % self.log_interval == 0:
                avg_loss = total_loss / (batch_idx + 1)
                accuracy = 100.0 * correct / total
                logger.info(
                    f"Epoch {self.current_epoch} [{batch_idx + 1}/{len(self.train_loader)}] "
                    f"Loss: {avg_loss:.4f}, Acc: {accuracy:.2f}%"
                )
        
        # Calculate epoch metrics
        epoch_loss = total_loss / len(self.train_loader)
        epoch_acc = 100.0 * correct / total
        
        return {
            'loss': epoch_loss,
            'accuracy': epoch_acc
        }
    
    def validate(self, loader: Optional[DataLoader] = None) -> Dict[str, float]:
        """
        Validate the model.
        
        Args:
            loader: DataLoader to validate on (defaults to val_loader)
        
        Returns:
            Dictionary with validation metrics
        """
        if loader is None:
            loader = self.val_loader
        
        if loader is None:
            return {}
        
        self.model.eval()
        total_loss = 0.0
        correct = 0
        total = 0
        
        with torch.no_grad():
            for batch in loader:
                # Move batch to device
                if isinstance(batch, dict):
                    label_key = 'labels' if 'labels' in batch else 'label'
                    inputs = {k: v.to(self.device) for k, v in batch.items() if k not in ['labels', 'label']}
                    labels = batch[label_key].to(self.device)
                else:
                    inputs, labels = batch
                    if isinstance(inputs, dict):
                        inputs = {k: v.to(self.device) for k, v in inputs.items()}
                    else:
                        inputs = inputs.to(self.device)
                    labels = labels.to(self.device)
                
                # Forward pass
                if isinstance(inputs, dict):
                    outputs = self.model(**inputs)
                else:
                    outputs = self.model(inputs)
                
                # Compute loss
                if outputs.dim() > 1 and outputs.size(1) == 1:
                    outputs = outputs.squeeze(1)
                
                loss = self.criterion(outputs, labels.float())
                total_loss += loss.item()
                
                # Calculate accuracy
                predictions = torch.sigmoid(outputs) > 0.5
                correct += (predictions == labels).sum().item()
                total += labels.size(0)
        
        val_loss = total_loss / len(loader)
        val_acc = 100.0 * correct / total
        
        return {
            'loss': val_loss,
            'accuracy': val_acc
        }
    
    def train(
        self,
        num_epochs: int,
        start_epoch: int = 0
    ) -> Dict[str, List[float]]:
        """
        Train the model for multiple epochs.
        
        Args:
            num_epochs: Number of epochs to train
            start_epoch: Starting epoch (for resuming training)
        
        Returns:
            Training history dictionary
        """
        logger.info(f"Starting training for {num_epochs} epochs on {self.device}")
        logger.info(f"Model has {self.model.count_parameters():,} parameters")
        
        for epoch in range(start_epoch, num_epochs):
            self.current_epoch = epoch
            epoch_start_time = time.time()
            
            # Call on_epoch_begin callbacks
            for callback in self.callbacks:
                if hasattr(callback, 'on_epoch_begin'):
                    callback.on_epoch_begin(epoch, self)
            
            # Train for one epoch
            train_metrics = self.train_epoch()
            
            # Validate
            val_metrics = self.validate()
            
            # Track history
            self.history['train_loss'].append(train_metrics['loss'])
            self.history['train_acc'].append(train_metrics['accuracy'])
            
            if val_metrics:
                self.history['val_loss'].append(val_metrics['loss'])
                self.history['val_acc'].append(val_metrics['accuracy'])
                
                # Track best metrics
                if val_metrics['loss'] < self.best_val_loss:
                    self.best_val_loss = val_metrics['loss']
                if val_metrics['accuracy'] > self.best_val_acc:
                    self.best_val_acc = val_metrics['accuracy']
            
            epoch_time = time.time() - epoch_start_time
            self.history['epoch_times'].append(epoch_time)
            
            # Log epoch summary
            log_msg = f"Epoch {epoch} completed in {epoch_time:.2f}s - "
            log_msg += f"Train Loss: {train_metrics['loss']:.4f}, Train Acc: {train_metrics['accuracy']:.2f}%"
            if val_metrics:
                log_msg += f", Val Loss: {val_metrics['loss']:.4f}, Val Acc: {val_metrics['accuracy']:.2f}%"
            logger.info(log_msg)
            
            # Call on_epoch_end callbacks
            stop_training = False
            for callback in self.callbacks:
                if hasattr(callback, 'on_epoch_end'):
                    result = callback.on_epoch_end(epoch, self, train_metrics, val_metrics)
                    if result is False:  # Callback signals to stop training
                        stop_training = True
                        break
            
            if stop_training:
                logger.info("Early stopping triggered")
                break
        
        logger.info("Training completed!")
        logger.info(f"Best validation loss: {self.best_val_loss:.4f}")
        logger.info(f"Best validation accuracy: {self.best_val_acc:.2f}%")
        
        return self.history
    
    def save_checkpoint(self, filepath: str, **kwargs):
        """
        Save a training checkpoint.
        
        Args:
            filepath: Path to save checkpoint
            **kwargs: Additional information to save
        """
        checkpoint = {
            'epoch': self.current_epoch,
            'model_state_dict': self.model.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
            'history': self.history,
            'best_val_loss': self.best_val_loss,
            'best_val_acc': self.best_val_acc,
            **kwargs
        }
        
        torch.save(checkpoint, filepath)
        logger.info(f"Checkpoint saved to {filepath}")
    
    def load_checkpoint(self, filepath: str) -> Dict:
        """
        Load a training checkpoint.
        
        Args:
            filepath: Path to checkpoint file
        
        Returns:
            Checkpoint dictionary
        """
        checkpoint = torch.load(filepath, map_location=self.device)
        
        self.model.load_state_dict(checkpoint['model_state_dict'])
        self.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        self.current_epoch = checkpoint['epoch']
        self.history = checkpoint['history']
        self.best_val_loss = checkpoint.get('best_val_loss', float('inf'))
        self.best_val_acc = checkpoint.get('best_val_acc', 0.0)
        
        logger.info(f"Checkpoint loaded from {filepath}")
        return checkpoint
