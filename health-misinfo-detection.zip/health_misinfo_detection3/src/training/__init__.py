"""Training module initialization"""
