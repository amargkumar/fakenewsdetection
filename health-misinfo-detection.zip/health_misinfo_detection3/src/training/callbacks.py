"""
Callbacks for training control and monitoring.
Includes early stopping, model checkpointing, and learning rate scheduling.
"""

import os
import torch
import logging
from pathlib import Path
from typing import Dict, Optional

logger = logging.getLogger(__name__)


class Callback:
    """Base class for callbacks."""
    
    def on_epoch_begin(self, epoch: int, trainer):
        """Called at the beginning of each epoch."""
        pass
    
    def on_epoch_end(self, epoch: int, trainer, train_metrics: Dict, val_metrics: Dict):
        """
        Called at the end of each epoch.
        
        Returns:
            False to stop training, None/True to continue
        """
        pass
    
    def on_batch_begin(self, batch_idx: int, trainer):
        """Called at the beginning of each batch."""
        pass
    
    def on_batch_end(self, batch_idx: int, trainer):
        """Called at the end of each batch."""
        pass


class EarlyStopping(Callback):
    """
    Stop training when a monitored metric has stopped improving.
    """
    
    def __init__(
        self,
        monitor: str = 'val_loss',
        patience: int = 5,
        min_delta: float = 0.0,
        mode: str = 'min',
        verbose: bool = True
    ):
        """
        Initialize early stopping callback.
        
        Args:
            monitor: Metric to monitor ('val_loss', 'val_acc', etc.)
            patience: Number of epochs with no improvement to wait
            min_delta: Minimum change to qualify as improvement
            mode: 'min' for loss, 'max' for accuracy
            verbose: Whether to print messages
        """
        self.monitor = monitor
        self.patience = patience
        self.min_delta = min_delta
        self.mode = mode
        self.verbose = verbose
        
        self.best_value = float('inf') if mode == 'min' else float('-inf')
        self.wait = 0
        self.stopped_epoch = 0
        
    def _is_improvement(self, current_value: float) -> bool:
        """Check if current value is an improvement."""
        if self.mode == 'min':
            return current_value < self.best_value - self.min_delta
        else:
            return current_value > self.best_value + self.min_delta
    
    def on_epoch_end(self, epoch: int, trainer, train_metrics: Dict, val_metrics: Dict):
        """Check if training should stop."""
        # Extract the monitored metric
        if self.monitor.startswith('val_'):
            metric_name = self.monitor.replace('val_', '')
            current_value = val_metrics.get(metric_name)
        elif self.monitor.startswith('train_'):
            metric_name = self.monitor.replace('train_', '')
            current_value = train_metrics.get(metric_name)
        else:
            current_value = val_metrics.get(self.monitor) or train_metrics.get(self.monitor)
        
        if current_value is None:
            logger.warning(f"Metric '{self.monitor}' not found, early stopping disabled")
            return None
        
        # Check for improvement
        if self._is_improvement(current_value):
            self.best_value = current_value
            self.wait = 0
            if self.verbose:
                logger.info(f"EarlyStopping: {self.monitor} improved to {current_value:.4f}")
        else:
            self.wait += 1
            if self.verbose:
                logger.info(
                    f"EarlyStopping: {self.monitor} did not improve from {self.best_value:.4f} "
                    f"({self.wait}/{self.patience})"
                )
            
            if self.wait >= self.patience:
                self.stopped_epoch = epoch
                if self.verbose:
                    logger.info(f"EarlyStopping: Stopping at epoch {epoch}")
                return False  # Stop training
        
        return None  # Continue training


class ModelCheckpoint(Callback):
    """
    Save model checkpoints during training.
    """
    
    def __init__(
        self,
        filepath: str,
        monitor: str = 'val_loss',
        save_best_only: bool = True,
        mode: str = 'min',
        verbose: bool = True,
        save_freq: int = 1
    ):
        """
        Initialize model checkpoint callback.
        
        Args:
            filepath: Path to save checkpoints (can include {epoch} placeholder)
            monitor: Metric to monitor for saving best model
            save_best_only: Only save when monitored metric improves
            mode: 'min' for loss, 'max' for accuracy
            verbose: Whether to print messages
            save_freq: Frequency (in epochs) to save checkpoints if not save_best_only
        """
        self.filepath = filepath
        self.monitor = monitor
        self.save_best_only = save_best_only
        self.mode = mode
        self.verbose = verbose
        self.save_freq = save_freq
        
        self.best_value = float('inf') if mode == 'min' else float('-inf')
        
        # Create directory if needed
        Path(filepath).parent.mkdir(parents=True, exist_ok=True)
    
    def _is_improvement(self, current_value: float) -> bool:
        """Check if current value is an improvement."""
        if self.mode == 'min':
            return current_value < self.best_value
        else:
            return current_value > self.best_value
    
    def on_epoch_end(self, epoch: int, trainer, train_metrics: Dict, val_metrics: Dict):
        """Save checkpoint if conditions are met."""
        # Extract the monitored metric
        if self.monitor.startswith('val_'):
            metric_name = self.monitor.replace('val_', '')
            current_value = val_metrics.get(metric_name)
        elif self.monitor.startswith('train_'):
            metric_name = self.monitor.replace('train_', '')
            current_value = train_metrics.get(metric_name)
        else:
            current_value = val_metrics.get(self.monitor) or train_metrics.get(self.monitor)
        
        # Format filepath with epoch number
        filepath = self.filepath.format(epoch=epoch)
        
        # Decide whether to save
        should_save = False
        
        if self.save_best_only:
            if current_value is not None and self._is_improvement(current_value):
                self.best_value = current_value
                should_save = True
                if self.verbose:
                    logger.info(
                        f"ModelCheckpoint: {self.monitor} improved to {current_value:.4f}, "
                        f"saving model to {filepath}"
                    )
        else:
            if (epoch + 1) % self.save_freq == 0:
                should_save = True
                if self.verbose:
                    logger.info(f"ModelCheckpoint: Saving model to {filepath}")
        
        if should_save:
            trainer.save_checkpoint(
                filepath,
                monitor_value=current_value,
                monitor_name=self.monitor
            )


class LearningRateScheduler(Callback):
    """
    Adjust learning rate during training.
    """
    
    def __init__(
        self,
        scheduler,
        monitor: Optional[str] = None,
        verbose: bool = True
    ):
        """
        Initialize learning rate scheduler callback.
        
        Args:
            scheduler: PyTorch learning rate scheduler
            monitor: Metric to monitor (for ReduceLROnPlateau)
            verbose: Whether to print messages
        """
        self.scheduler = scheduler
        self.monitor = monitor
        self.verbose = verbose
    
    def on_epoch_end(self, epoch: int, trainer, train_metrics: Dict, val_metrics: Dict):
        """Update learning rate."""
        # For ReduceLROnPlateau, we need to pass the metric value
        if self.monitor is not None:
            if self.monitor.startswith('val_'):
                metric_name = self.monitor.replace('val_', '')
                metric_value = val_metrics.get(metric_name)
            elif self.monitor.startswith('train_'):
                metric_name = self.monitor.replace('train_', '')
                metric_value = train_metrics.get(metric_name)
            else:
                metric_value = val_metrics.get(self.monitor) or train_metrics.get(self.monitor)
            
            if metric_value is not None:
                self.scheduler.step(metric_value)
        else:
            self.scheduler.step()
        
        # Log new learning rate
        if self.verbose:
            current_lr = trainer.optimizer.param_groups[0]['lr']
            logger.info(f"LearningRateScheduler: Learning rate = {current_lr:.6f}")


class MetricsLogger(Callback):
    """
    Log metrics to TensorBoard or other logging systems.
    """
    
    def __init__(self, log_dir: str = 'logs', use_tensorboard: bool = True):
        """
        Initialize metrics logger.
        
        Args:
            log_dir: Directory for logs
            use_tensorboard: Whether to use TensorBoard
        """
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self.use_tensorboard = use_tensorboard
        self.writer = None
        
        if use_tensorboard:
            try:
                from torch.utils.tensorboard import SummaryWriter
                self.writer = SummaryWriter(log_dir=str(self.log_dir))
                logger.info(f"TensorBoard logging to {self.log_dir}")
            except ImportError:
                logger.warning("TensorBoard not available, skipping tensorboard logging")
                self.use_tensorboard = False
    
    def on_epoch_end(self, epoch: int, trainer, train_metrics: Dict, val_metrics: Dict):
        """Log metrics."""
        if self.writer is not None:
            # Log training metrics
            for metric_name, value in train_metrics.items():
                self.writer.add_scalar(f'train/{metric_name}', value, epoch)
            
            # Log validation metrics
            for metric_name, value in val_metrics.items():
                self.writer.add_scalar(f'val/{metric_name}', value, epoch)
            
            # Log learning rate
            lr = trainer.optimizer.param_groups[0]['lr']
            self.writer.add_scalar('learning_rate', lr, epoch)
    
    def __del__(self):
        """Close TensorBoard writer."""
        if self.writer is not None:
            self.writer.close()
