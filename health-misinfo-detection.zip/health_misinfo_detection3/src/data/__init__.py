"""Data module initialization"""
