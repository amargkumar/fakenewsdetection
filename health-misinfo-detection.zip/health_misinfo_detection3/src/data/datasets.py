"""
PyTorch Dataset classes for efficient batch processing
"""
import torch
from torch.utils.data import Dataset, DataLoader
from typing import List, Dict, Optional, Tuple
import numpy as np


class HealthMisinfoDataset(Dataset):
    """
    Base dataset class handling text, labels, and features
    """
    def __init__(self, texts: List[str], labels: List[int], 
                 features: Optional[np.ndarray] = None):
        """
        Args:
            texts: List of text strings
            labels: List of binary labels (0=fake, 1=real)
            features: Optional engineered features array
        """
        self.texts = texts
        self.labels = labels
        self.features = features
        
    def __len__(self) -> int:
        return len(self.texts)
    
    def __getitem__(self, idx: int) -> Dict:
        item = {
            'text': self.texts[idx],
            'label': torch.tensor(self.labels[idx], dtype=torch.long)
        }
        
        if self.features is not None:
            item['features'] = torch.tensor(self.features[idx], dtype=torch.float32)
        
        return item


class TextOnlyDataset(Dataset):
    """
    Returns tokenized text and labels
    """
    def __init__(self, input_ids: List[List[int]], labels: List[int], 
                 attention_masks: Optional[List[List[int]]] = None):
        """
        Args:
            input_ids: Tokenized and padded sequences
            labels: Binary labels
            attention_masks: Optional attention masks for transformers
        """
        self.input_ids = input_ids
        self.labels = labels
        self.attention_masks = attention_masks
        
    def __len__(self) -> int:
        return len(self.input_ids)
    
    def __getitem__(self, idx: int) -> Dict:
        item = {
            'input_ids': torch.tensor(self.input_ids[idx], dtype=torch.long),
            'label': torch.tensor(self.labels[idx], dtype=torch.long)
        }
        
        if self.attention_masks is not None:
            item['attention_mask'] = torch.tensor(self.attention_masks[idx], dtype=torch.long)
        
        return item


class TextWithFeaturesDataset(Dataset):
    """
    Returns text + engineered features
    """
    def __init__(self, input_ids: List[List[int]], features: np.ndarray, 
                 labels: List[int], attention_masks: Optional[List[List[int]]] = None):
        """
        Args:
            input_ids: Tokenized and padded sequences
            features: Engineered features (sentiment + linguistic)
            labels: Binary labels
            attention_masks: Optional attention masks
        """
        self.input_ids = input_ids
        self.features = features
        self.labels = labels
        self.attention_masks = attention_masks
        
    def __len__(self) -> int:
        return len(self.input_ids)
    
    def __getitem__(self, idx: int) -> Dict:
        item = {
            'input_ids': torch.tensor(self.input_ids[idx], dtype=torch.long),
            'label': torch.tensor(self.labels[idx], dtype=torch.long),
            'features': torch.tensor(self.features[idx], dtype=torch.float32)
        }
        
        if self.attention_masks is not None:
            item['attention_mask'] = torch.tensor(self.attention_masks[idx], dtype=torch.long)
        
        return item


class TransformerDataset(Dataset):
    """
    Uses HuggingFace tokenizers for BERT models
    """
    def __init__(self, encodings: Dict, labels: List[int], 
                 features: Optional[np.ndarray] = None):
        """
        Args:
            encodings: HuggingFace tokenizer output
            labels: Binary labels
            features: Optional engineered features
        """
        self.encodings = encodings
        self.labels = labels
        self.features = features
        
    def __len__(self) -> int:
        return len(self.labels)
    
    def __getitem__(self, idx: int) -> Dict:
        item = {key: torch.tensor(val[idx]) for key, val in self.encodings.items()}
        item['label'] = torch.tensor(self.labels[idx], dtype=torch.long)
        
        if self.features is not None:
            item['features'] = torch.tensor(self.features[idx], dtype=torch.float32)
        
        return item


def create_dataloaders(dataset: Dataset, batch_size: int = 32, 
                       train_split: float = 0.7, val_split: float = 0.15,
                       shuffle: bool = True) -> Tuple[DataLoader, DataLoader, DataLoader]:
    """
    Create train/val/test dataloaders
    
    Args:
        dataset: PyTorch Dataset
        batch_size: Batch size
        train_split: Training set proportion
        val_split: Validation set proportion
        shuffle: Whether to shuffle training data
        
    Returns:
        Tuple of (train_loader, val_loader, test_loader)
    """
    dataset_size = len(dataset)
    train_size = int(train_split * dataset_size)
    val_size = int(val_split * dataset_size)
    test_size = dataset_size - train_size - val_size
    
    train_dataset, val_dataset, test_dataset = torch.utils.data.random_split(
        dataset, [train_size, val_size, test_size]
    )
    
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=shuffle)
    val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False)
    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)
    
    return train_loader, val_loader, test_loader
