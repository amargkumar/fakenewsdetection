"""
Data loaders for CoAID and HealthFact datasets
"""
import pandas as pd
import json
import os
import requests
from pathlib import Path
from typing import Dict, List, Tuple, Optional
import logging

logger = logging.getLogger(__name__)


def download_file(url: str, destination: Path) -> bool:
    """
    Download a file from URL to destination
    
    Args:
        url: URL to download from
        destination: Path to save file
        
    Returns:
        True if successful, False otherwise
    """
    try:
        destination.parent.mkdir(parents=True, exist_ok=True)
        response = requests.get(url, stream=True, timeout=30)
        response.raise_for_status()
        
        with open(destination, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)
        
        logger.info(f"Downloaded {url} to {destination}")
        return True
    except Exception as e:
        logger.error(f"Failed to download {url}: {e}")
        return False


def create_sample_coaid_data(save_path: Path, n_samples: int = 1000):
    """
    Create sample CoAID-like data for testing
    
    Args:
        save_path: Path to save CSV file
        n_samples: Number of samples to generate
    """
    import numpy as np
    
    # Sample COVID-related texts
    real_templates = [
        "CDC recommends wearing masks in public spaces to prevent COVID-19 transmission.",
        "Studies show that COVID-19 vaccines are effective in preventing severe illness.",
        "WHO announces new guidelines for COVID-19 testing and treatment protocols.",
        "Research indicates that social distancing reduces coronavirus spread by up to 80%.",
        "Health officials report increase in vaccination rates across multiple countries.",
    ]
    
    fake_templates = [
        "BREAKING: Drinking bleach cures coronavirus according to unnamed sources!",
        "5G towers are spreading COVID-19 - they don't want you to know!",
        "Bill Gates created coronavirus to sell vaccines - shocking truth revealed!",
        "Garlic water eliminates COVID-19 in minutes - doctors hate this trick!",
        "COVID vaccines contain microchips for government tracking - insider leaks!",
    ]
    
    data = []
    np.random.seed(42)
    
    for i in range(n_samples):
        if i % 2 == 0:  # Real news
            text = np.random.choice(real_templates) + f" Article {i}. " + "Additional context about health guidelines and medical research findings."
            label = 1  # Real
            source = "legitimate_news_source"
        else:  # Fake news
            text = np.random.choice(fake_templates) + f" Post {i}. " + "Click here for more shocking revelations!"
            label = 0  # Fake
            source = "suspicious_source"
        
        data.append({
            'text': text,
            'label': label,
            'source': source,
            'id': f'coaid_{i}'
        })
    
    df = pd.DataFrame(data)
    save_path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(save_path, index=False)
    logger.info(f"Created sample CoAID data: {len(df)} samples at {save_path}")


def create_sample_healthfact_data(save_path: Path, n_samples: int = 1000):
    """
    Create sample HealthFact-like data for testing
    
    Args:
        save_path: Path to save CSV file
        n_samples: Number of samples to generate
    """
    import numpy as np
    
    # Sample health claim templates
    true_claims = [
        "Regular exercise can reduce the risk of heart disease and improve cardiovascular health.",
        "Vitamin D deficiency has been linked to increased risk of bone fractures and osteoporosis.",
        "Smoking cessation significantly reduces the risk of lung cancer and respiratory diseases.",
        "A balanced diet rich in fruits and vegetables supports immune system function.",
        "Regular sleep of 7-9 hours per night is associated with better mental health outcomes.",
    ]
    
    false_claims = [
        "Essential oils can cure cancer and replace chemotherapy treatments entirely.",
        "Eating sugar directly causes diabetes in otherwise healthy individuals.",
        "Vaccines cause autism in children according to multiple studies.",
        "Detox teas can cleanse your liver and kidneys better than medical treatments.",
        "Cracking your knuckles will definitely cause arthritis later in life.",
    ]
    
    data = []
    np.random.seed(42)
    
    for i in range(n_samples):
        if i % 2 == 0:  # True claim
            text = np.random.choice(true_claims) + f" Claim {i}. " + "Medical research supports this finding with multiple peer-reviewed studies."
            label = 1  # True
            source = "medical_journal"
        else:  # False claim
            text = np.random.choice(false_claims) + f" Claim {i}. " + "This information is not supported by scientific evidence."
            label = 0  # False
            source = "social_media"
        
        data.append({
            'text': text,
            'label': label,
            'source': source,
            'id': f'healthfact_{i}'
        })
    
    df = pd.DataFrame(data)
    save_path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(save_path, index=False)
    logger.info(f"Created sample HealthFact data: {len(df)} samples at {save_path}")


def load_coaid_dataset(data_dir: str = 'data/raw', use_sample: bool = False) -> pd.DataFrame:
    """
    Loads COVID-19 articles and claims from CoAID JSON/CSV files
    
    Args:
        data_dir: Path to raw data directory
        use_sample: If True, creates and uses sample data for testing
        
    Returns:
        DataFrame with columns: text, label, source, metadata
    """
    data_path = Path(data_dir) / 'coaid'
    
    # Look for combined dataset first (preferred)
    combined_file = data_path / 'coaid_combined.csv'
    if combined_file.exists() and not use_sample:
        logger.info(f"Loading combined CoAID dataset from {combined_file}")
        combined_df = pd.read_csv(combined_file)
        logger.info(f"Total CoAID records loaded: {len(combined_df)}")
        logger.info(f"Label distribution: {combined_df['label'].value_counts().to_dict()}")
        return combined_df
    
    # Check for existing CSV files
    csv_files = list(data_path.glob('*.csv'))
    
    # Exclude sample file if we have real data
    if not use_sample:
        csv_files = [f for f in csv_files if 'sample' not in f.name.lower()]
    
    if use_sample or len(csv_files) == 0:
        logger.warning("No CoAID data found. Creating sample data for testing...")
        sample_path = data_path / 'sample_coaid.csv'
        create_sample_coaid_data(sample_path, n_samples=1000)
        csv_files = [sample_path]
    
    # Load and combine all CSV files
    dfs = []
    for csv_file in csv_files:
        try:
            df = pd.read_csv(csv_file)
            dfs.append(df)
            logger.info(f"Loaded {len(df)} records from {csv_file}")
        except Exception as e:
            logger.error(f"Failed to load {csv_file}: {e}")
    
    if not dfs:
        raise ValueError("No data could be loaded from CoAID dataset")
    
    # Combine all dataframes
    combined_df = pd.concat(dfs, ignore_index=True)
    
    # Ensure required columns exist
    if 'text' not in combined_df.columns:
        # Try to find text column with different names
        text_cols = ['content', 'tweet', 'news_content', 'title']
        for col in text_cols:
            if col in combined_df.columns:
                combined_df['text'] = combined_df[col]
                break
    
    if 'label' not in combined_df.columns:
        # Try to infer labels from filename or other columns
        label_cols = ['fake', 'label', 'class', 'category']
        for col in label_cols:
            if col in combined_df.columns:
                combined_df['label'] = combined_df[col]
                break
    
    # Standardize labels to binary (0=fake, 1=real)
    if 'label' in combined_df.columns:
        # Only standardize if labels are not already 0/1
        unique_labels = combined_df['label'].unique()
        if not all(label in [0, 1] for label in unique_labels):
            combined_df['label'] = standardize_labels(combined_df['label'].tolist())
    
    logger.info(f"Total CoAID records loaded: {len(combined_df)}")
    logger.info(f"Label distribution: {combined_df['label'].value_counts().to_dict()}")
    return combined_df


def load_healthfact_dataset(data_dir: str = 'data/raw', use_sample: bool = False, 
                           split: str = 'all') -> pd.DataFrame:
    """
    Loads medical claims from HealthFact TSV files
    
    Args:
        data_dir: Path to raw data directory
        use_sample: If True, creates and uses sample data for testing
        split: Which split to load ('train', 'dev', 'test', or 'all')
        
    Returns:
        DataFrame with columns: text, label, source, metadata
    """
    data_path = Path(data_dir) / 'healthfact'
    
    # Check for TSV files (real HealthFact format)
    tsv_files = list(data_path.glob('*.tsv'))
    
    if use_sample or (len(tsv_files) == 0 and split == 'all'):
        logger.warning("No HealthFact data found. Creating sample data for testing...")
        sample_path = data_path / 'sample_healthfact.csv'
        create_sample_healthfact_data(sample_path, n_samples=1000)
        df = pd.read_csv(sample_path)
        logger.info(f"Loaded {len(df)} sample records")
        return df
    
    # Load TSV files based on split
    dfs = []
    if split == 'all':
        files_to_load = tsv_files
    else:
        files_to_load = [f for f in tsv_files if f.stem == split]
    
    for tsv_file in files_to_load:
        try:
            # HealthFact TSV format: claim_id, claim, label, justification, etc.
            df = pd.read_csv(tsv_file, sep='\t')
            dfs.append(df)
            logger.info(f"Loaded {len(df)} records from {tsv_file.name}")
        except Exception as e:
            logger.error(f"Failed to load {tsv_file}: {e}")
    
    if not dfs:
        raise ValueError(f"No data could be loaded from HealthFact dataset for split: {split}")
    
    # Combine all dataframes
    combined_df = pd.concat(dfs, ignore_index=True)
    
    # Map HealthFact column names to standard format
    # HealthFact typically has: claim_id, claim, label, claim_source, etc.
    if 'text' not in combined_df.columns:
        # Try to find text column with different names
        text_cols = ['claim', 'main_text', 'statement', 'content']
        for col in text_cols:
            if col in combined_df.columns:
                combined_df['text'] = combined_df[col]
                logger.info(f"Using '{col}' column as text")
                break
    
    # Map source column
    if 'source' not in combined_df.columns:
        source_cols = ['claim_source', 'source_url', 'url']
        for col in source_cols:
            if col in combined_df.columns:
                combined_df['source'] = combined_df[col]
                break
        if 'source' not in combined_df.columns:
            combined_df['source'] = 'healthfact'
    
    # Handle label column
    if 'label' not in combined_df.columns:
        # Try to infer labels from different column names
        label_cols = ['label', 'rating', 'veracity', 'class']
        for col in label_cols:
            if col in combined_df.columns:
                combined_df['label'] = combined_df[col]
                logger.info(f"Using '{col}' column as label")
                break
    
    # Standardize labels to binary (0=false, 1=true)
    if 'label' in combined_df.columns:
        # Check current label format
        unique_labels = combined_df['label'].unique()
        logger.info(f"Original unique labels: {unique_labels[:10]}")  # Show first 10
        
        # HealthFact uses: true, false, mixture, unproven (we'll map to binary)
        label_mapping = {
            'true': 1, 'TRUE': 1, 'True': 1,
            'false': 0, 'FALSE': 0, 'False': 0,
            'mostly_true': 1, 'mostly true': 1,
            'mostly_false': 0, 'mostly false': 0,
            'mixture': 0,  # Conservative: treat mixture as false
            'unproven': 0,  # Conservative: treat unproven as false
            'half-true': 0, 'half true': 0,
            'pants-fire': 0, 'pants on fire': 0,
            1: 1, 0: 0, '1': 1, '0': 0
        }
        
        # Apply mapping
        combined_df['label'] = combined_df['label'].map(
            lambda x: label_mapping.get(str(x).lower(), label_mapping.get(x, -1))
        )
        
        # Remove unmapped labels
        original_len = len(combined_df)
        combined_df = combined_df[combined_df['label'] != -1]
        if len(combined_df) < original_len:
            logger.warning(f"Removed {original_len - len(combined_df)} records with unmapped labels")
    
    logger.info(f"Total HealthFact records loaded: {len(combined_df)}")
    logger.info(f"Label distribution: {combined_df['label'].value_counts().to_dict()}")
    
    return combined_df


def standardize_labels(labels: List) -> List[int]:
    """
    Converts different label formats to binary (0=fake, 1=real)
    
    Args:
        labels: List of label strings or integers
        
    Returns:
        List of binary labels
    """
    label_mapping = {
        'fake': 0,
        'false': 0,
        'misinformation': 0,
        '0': 0,
        0: 0,
        'real': 1,
        'true': 1,
        'factual': 1,
        '1': 1,
        1: 1
    }
    
    standardized = []
    for label in labels:
        # Try direct mapping first
        if label in label_mapping:
            standardized.append(label_mapping[label])
        # Try lowercase string
        elif isinstance(label, str) and label.lower() in label_mapping:
            standardized.append(label_mapping[label.lower()])
        # If it's already 0 or 1, keep it
        elif label in [0, 1]:
            standardized.append(label)
        else:
            # Default: unknown labels become -1
            standardized.append(-1)
    
    return standardized


def extract_metadata(df: pd.DataFrame) -> pd.DataFrame:
    """
    Extracts engagement metrics and source information
    
    Args:
        df: Input DataFrame
        
    Returns:
        DataFrame with additional metadata columns
    """
    # TODO: Extract engagement metrics (likes, shares, etc.)
    return df
