"""
Text preprocessing utilities
"""
import re
from typing import List, Dict, Tuple
from collections import Counter
import string


def clean_text(text: str) -> str:
    """
    Removes URLs, special characters, extra whitespace
    
    Args:
        text: Input text string
        
    Returns:
        Cleaned text
    """
    # Remove URLs
    text = re.sub(r'http\S+|www.\S+', '', text)
    
    # Remove HTML tags
    text = re.sub(r'<.*?>', '', text)
    
    # Remove special characters and digits (optional - keep for some features)
    # text = re.sub(r'[^a-zA-Z\s]', '', text)
    
    # Remove extra whitespace
    text = re.sub(r'\s+', ' ', text).strip()
    
    return text


def tokenize_text(text: str, lowercase: bool = True) -> List[str]:
    """
    Word-level tokenization with optional lowercasing
    
    Args:
        text: Input text string
        lowercase: Whether to lowercase tokens
        
    Returns:
        List of tokens
    """
    if lowercase:
        text = text.lower()
    
    # Simple whitespace tokenization (can be enhanced with NLTK/spaCy)
    tokens = text.split()
    
    return tokens


def build_vocabulary(texts: List[str], min_freq: int = 2, max_vocab_size: int = 50000) -> Dict[str, int]:
    """
    Creates word-to-index mappings for non-transformer models
    
    Args:
        texts: List of text strings
        min_freq: Minimum frequency for word to be included
        max_vocab_size: Maximum vocabulary size
        
    Returns:
        Dictionary mapping words to indices
    """
    # Count word frequencies
    word_counts = Counter()
    for text in texts:
        tokens = tokenize_text(text)
        word_counts.update(tokens)
    
    # Filter by frequency and limit size
    vocab = {'<PAD>': 0, '<UNK>': 1}
    
    for word, count in word_counts.most_common(max_vocab_size - 2):
        if count >= min_freq:
            vocab[word] = len(vocab)
    
    return vocab


def pad_sequences(sequences: List[List[int]], max_length: int, pad_value: int = 0) -> List[List[int]]:
    """
    Pads/truncates sequences to fixed length
    
    Args:
        sequences: List of token ID sequences
        max_length: Target sequence length
        pad_value: Value to use for padding
        
    Returns:
        List of padded sequences
    """
    padded = []
    
    for seq in sequences:
        if len(seq) < max_length:
            # Pad sequence
            padded_seq = seq + [pad_value] * (max_length - len(seq))
        else:
            # Truncate sequence
            padded_seq = seq[:max_length]
        
        padded.append(padded_seq)
    
    return padded


def text_to_sequences(texts: List[str], vocab: Dict[str, int]) -> List[List[int]]:
    """
    Convert texts to sequences of token IDs
    
    Args:
        texts: List of text strings
        vocab: Word to index mapping
        
    Returns:
        List of token ID sequences
    """
    sequences = []
    
    for text in texts:
        tokens = tokenize_text(text)
        seq = [vocab.get(token, vocab['<UNK>']) for token in tokens]
        sequences.append(seq)
    
    return sequences
