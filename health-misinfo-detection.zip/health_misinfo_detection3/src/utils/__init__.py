"""Utils module initialization"""
