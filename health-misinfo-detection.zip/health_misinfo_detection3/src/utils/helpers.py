"""
Helper utility functions
"""
import torch
import numpy as np
from typing import List, Dict, Any
from pathlib import Path


def batch_to_device(batch: Dict[str, torch.Tensor], device: torch.device) -> Dict[str, torch.Tensor]:
    """
    Move batch to device
    
    Args:
        batch: Dictionary of tensors
        device: Target device
        
    Returns:
        Batch on device
    """
    return {key: val.to(device) if isinstance(val, torch.Tensor) else val 
            for key, val in batch.items()}


def save_predictions(predictions: np.ndarray, labels: np.ndarray, 
                     save_path: str):
    """
    Save predictions to file
    
    Args:
        predictions: Model predictions
        labels: True labels
        save_path: Path to save predictions
    """
    Path(save_path).parent.mkdir(parents=True, exist_ok=True)
    
    np.savez(save_path, predictions=predictions, labels=labels)
    print(f"Predictions saved to {save_path}")


def load_predictions(load_path: str) -> tuple:
    """
    Load predictions from file
    
    Args:
        load_path: Path to load predictions from
        
    Returns:
        Tuple of (predictions, labels)
    """
    data = np.load(load_path)
    return data['predictions'], data['labels']


def create_experiment_name(model_name: str, dataset: str, 
                          use_features: bool, **kwargs) -> str:
    """
    Create experiment name from configuration
    
    Args:
        model_name: Name of model
        dataset: Dataset name
        use_features: Whether features are used
        **kwargs: Additional parameters
        
    Returns:
        Experiment name string
    """
    name = f"{model_name}_{dataset}"
    
    if use_features:
        name += "_feat"
    
    for key, val in kwargs.items():
        name += f"_{key}{val}"
    
    return name


def ensure_dir(directory: str):
    """
    Create directory if it doesn't exist
    
    Args:
        directory: Directory path
    """
    Path(directory).mkdir(parents=True, exist_ok=True)
