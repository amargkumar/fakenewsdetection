# Start Flask Web App
# This script ensures proper paths and keeps the server running

Write-Host "Starting Health Misinformation Detection Web App..." -ForegroundColor Cyan
Write-Host ""

# Set location
Set-Location C:/Users/amar_kumar/Documents/health_misinfo_detection

# Run Flask
& "C/Users/amar_kumar/Documents/health_misinfo_detection/venv/Scripts/python.exe" "C:/Users/amar_kumar/Documents/health_misinfo_detection/start_flask.py"
